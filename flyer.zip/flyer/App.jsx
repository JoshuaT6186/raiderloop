/**
 * RaiderLoop — v0.7
 * -----------------------------------------------------------
 * Expo / React Native.
 * Requires: npx expo install react-native-svg react-native-maps
 *
 * Built to the design brief. The governing rule is section 21:
 * DO NOT INNOVATE UNIFORMLY. Each destination gets the
 * interaction model that fits its purpose, and one shared
 * material language ties them together.
 *
 *   Home      conventional and calm. The front door, not a
 *             dashboard. Curated, not comprehensive.
 *   Discover  the Raider Grid. This is where we break the mold.
 *             Tiles have different internal structures by
 *             content type — not one shape recoloured.
 *   Campus    map-driven, glass floating over it.
 *   Schedule  a deliberately ordinary timeline.
 *   You       a personal control centre.
 *   Ask Red   returns real RaiderLoop content, not paragraphs.
 *
 * Material: Raider Glass (soft surfaces, real borders, quiet
 * shadow) + Raider Bleed (red diffusing up through the surface,
 * used selectively for hierarchy — strong on featured, absent
 * on utility). Red is energy, emphasis and state. Never a
 * background.
 */

import React, {
  createContext, useContext, useMemo, useState, useRef, useEffect,
} from 'react';
import {
  View, Text, ScrollView, Pressable, TextInput, StyleSheet,
  SafeAreaView, StatusBar, Platform, Modal, Animated, Easing, Dimensions, Linking, Image, ActivityIndicator,
} from 'react-native';

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');

/* ============================================================
   FIREBASE — real backend for Ask Red + schedule scanning
   ------------------------------------------------------------
   Deliberately does NOT import firebase/analytics — it depends
   on browser-only APIs (window, DOM) and will crash on a real
   device. app + functions only.
   ============================================================ */
import { initializeApp } from 'firebase/app';
import { getFunctions, httpsCallable } from 'firebase/functions';

const firebaseConfig = {
  apiKey: 'AIzaSyCdaILApsJo7KfTKfIH5W_TueYQPr6IZRw',
  authDomain: 'raiderloop-98046.firebaseapp.com',
  projectId: 'raiderloop-98046',
  storageBucket: 'raiderloop-98046.firebasestorage.app',
  messagingSenderId: '549349537291',
  appId: '1:549349537291:web:a9d31e7635ea7f9403b90e',
};

const firebaseApp = initializeApp(firebaseConfig);
const functions = getFunctions(firebaseApp);
const callAskRed = httpsCallable(functions, 'askRed');
const callParseSchedule = httpsCallable(functions, 'parseSchedule');
const callGetEvents = httpsCallable(functions, 'getEvents');
const callGetSportsSchedule = httpsCallable(functions, 'getSportsSchedule');
const callGetDiningMenus = httpsCallable(functions, 'getDiningMenus');
const callGetCampusAlerts = httpsCallable(functions, 'getCampusAlerts');
const callGetNews = httpsCallable(functions, 'getNews');
const callEnrichOrg = httpsCallable(functions, 'enrichOrg');
const callGetVenueImage = httpsCallable(functions, 'getVenueImage');
const callGetDiningHallDetail = httpsCallable(functions, 'getDiningHallDetail');

let Svg, Defs, RadialGradient, LinearGradient, Stop, Path, Circle, Rect;
try {
  const S = require('react-native-svg');
  Svg = S.default; Defs = S.Defs; RadialGradient = S.RadialGradient; LinearGradient = S.LinearGradient;
  Stop = S.Stop; Path = S.Path; Circle = S.Circle; Rect = S.Rect;
} catch (e) {}

let MapView = null, Marker = null;
if (Platform.OS !== 'web') {
  try { const M = require('react-native-maps'); MapView = M.default; Marker = M.Marker; } catch (e) {}
}

let BlurView = null;
try { BlurView = require('expo-blur').BlurView; } catch (e) {}

let ImagePicker = null;
try { ImagePicker = require('expo-image-picker'); } catch (e) {}

let Notifications = null;
try {
  Notifications = require('expo-notifications');
  Notifications.setNotificationHandler({
    handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: false, shouldSetBadge: false }),
  });
} catch (e) {}

let AsyncStorage = null;
try { AsyncStorage = require('@react-native-async-storage/async-storage').default; } catch (e) {}
const STORAGE_KEY = 'raiderloop_v1';

/* ============================================================
   THEME
   ============================================================ */

const lightTheme = {
  mode: 'light',
  canvas: '#FBF8F5',
  canvasDeep: '#F4EDE7',
  surface: '#FFFFFF',
  surfaceAlt: '#F5EFEA',
  border: 'rgba(28,20,18,0.08)',
  borderStrong: 'rgba(28,20,18,0.14)',
  text: '#1A1416',
  textMuted: '#716660',
  textFaint: '#A0968F',
  red: '#CC0000',
  redInk: '#8E0000',
  onRed: '#FFFFFF',
  bleedWarm: '#FF7A3D',
  shadow: '#2E1F1B',
  shadowOpacity: 0.10,
  ok: '#2E8B5B',
  info: '#3F6B8C',
  gold: '#B8860B',
  rim: 'rgba(255,255,255,0.85)',
};

const darkTheme = {
  mode: 'dark',
  canvas: '#121011',
  canvasDeep: '#0C0A0B',
  surface: '#1D1A1B',
  surfaceAlt: '#262223',
  border: 'rgba(255,255,255,0.09)',
  borderStrong: 'rgba(255,255,255,0.17)',
  text: '#F6F2F0',
  textMuted: '#9B918C',
  textFaint: '#6C635F',
  red: '#E3253F',
  redInk: '#FF5C74',
  onRed: '#FFFFFF',
  bleedWarm: '#FF6A4D',
  shadow: '#000000',
  shadowOpacity: 0.45,
  ok: '#4CB07C',
  info: '#6E9BC2',
  gold: '#D9A441',
  rim: 'rgba(255,255,255,0.13)',
};

/* ============================================================
   GRID METRICS — verified to sum exactly to content width
   ============================================================ */

const PAD = 20;
const GAP = 10;
const GRID_W = SCREEN_W - PAD * 2;          // 350 @ 390

// Tabular numerals so times/countdowns don't shift width as digits
// change — spread into any text style showing a clock time or count.
const NUM = { fontVariant: ['tabular-nums'] };
const HALF = (GRID_W - GAP) / 2;            // 170
const WIDE = (GRID_W - GAP) * 0.615;        // 209
const NARROW = (GRID_W - GAP) * 0.385;      // 131

/* ============================================================
   IMAGERY
   ------------------------------------------------------------
   Real photos, not color blocks — per the design feedback that
   text-only tiles read as a spec document. These four are real,
   verified Unsplash License images (free for commercial use, no
   attribution required) pulled in as stand-ins for the visual
   direction. NONE of these are Texas Tech's own photography —
   swap in real campus/game-day photos you take yourself before
   this goes anywhere near SGA or the Dean's office. Hotlinking
   someone else's stock photo in a pitch deck is a fast way to
   undercut "we built this ourselves."
   ============================================================ */
const IMG = {
  stadium: 'https://images.unsplash.com/photo-1693164586646-f3f877aec626?w=900&q=70&fit=crop&auto=format',
  rally: 'https://images.unsplash.com/photo-1766756467595-fd3f1f62d562?w=900&q=70&fit=crop&auto=format',
  dining: 'https://images.unsplash.com/photo-1666216601827-4f5f88a8c9c2?w=900&q=70&fit=crop&auto=format',
  library: 'https://images.unsplash.com/photo-1741699428220-65f37f3fbbcb?w=900&q=70&fit=crop&auto=format',
  texas: 'https://images.unsplash.com/photo-1655494393495-79b474dd2968?w=900&q=70&fit=crop&auto=format',
};

/* ============================================================
   IN THE LOOP — real headlines, not placeholder text
   ------------------------------------------------------------
   Pulled from dailytoreador.com, kcbd.com, and everythinglubbock.com
   directly — these are real, dated stories, not invented. Excerpts
   below are written fresh in our own words, not copied from any
   article body, per standard copyright practice (headlines/facts
   aren't substantially copyrightable; article text is). Each links
   out to the outlet's real site rather than reproducing the piece.

   This is a manual snapshot, not a live feed — there's no confirmed
   RSS endpoint yet (see earlier note: TownNews sites like the DT
   usually expose one, but the exact URL needs checking from a
   browser, since it's blocked from automated fetch here). Wiring a
   real feed is the next step once that URL is confirmed.
   ============================================================ */
const NEWS = [
  { id: 'dt1', headline: 'Ivey named Tech Police Chief', source: 'The Daily Toreador', official: true, byline: 'Avery Mendoza', date: 'Aug 5', excerpt: 'Texas Tech Police Department has a new chief leading campus safety operations.', url: 'https://www.dailytoreador.com/', art: IMG.library },
  { id: 'dt2', headline: 'Tech announces Summer 2026 Commencement schedule', source: 'The Daily Toreador', official: true, byline: 'Avery Mendoza', date: 'Aug 5', excerpt: 'Graduation ceremonies for summer graduates are set across two days this month.', url: 'https://www.dailytoreador.com/', art: IMG.library },
  { id: 'kcbd1', headline: 'Tommy Castellanos joins Red Raider football program', source: 'KCBD NewsChannel 11', official: false, date: 'Aug 29', excerpt: 'Head coach Joey McGuire confirmed the transfer quarterback ahead of the season opener.', url: 'https://www.kcbd.com/', art: IMG.rally },
  { id: 'dt3', headline: "Tech folds NIL operation into the Red Raider Club", source: 'The Daily Toreador', official: true, date: 'Recent', excerpt: 'Ahead of new NCAA rules taking effect, the Matador Club NIL collective now operates under the athletics booster organization.', url: 'https://www.dailytoreador.com/', art: IMG.stadium },
  { id: 'klbk1', headline: 'Donovan Atwell files suit seeking injunction ahead of season', source: 'Everything Lubbock', official: false, date: 'Sept 1', excerpt: 'The Texas Tech men\'s basketball guard filed the request in Lubbock County.', url: 'https://www.everythinglubbock.com/news/', art: IMG.stadium },
  { id: 'dt4', headline: "Big 12 releases 18-game basketball opponent matrix", source: 'The Daily Toreador', official: true, date: 'Recent', excerpt: 'The conference set its full slate of men\'s and women\'s opponents for the coming season.', url: 'https://www.dailytoreador.com/', art: IMG.stadium },
  { id: 'kcbd2', headline: 'Lubbock police investigate organized retail theft ring', source: 'KCBD NewsChannel 11', official: false, date: 'Recent', excerpt: 'Two homes and a flea market booth are linked to the operation, according to police.', url: 'https://www.kcbd.com/', art: IMG.texas },
  { id: 'dt5', headline: 'TTUHSC reaches new agreement with UnitedHealthcare', source: 'The Daily Toreador', official: true, byline: 'Avery Mendoza', date: 'Aug 5', excerpt: 'The agreement restores in-network coverage for patients at Texas Tech\'s health science center.', url: 'https://www.dailytoreador.com/', art: IMG.library },
];

/* ============================================================
   DATA
   ============================================================ */

/* ============================================================
   BUILDINGS — real OpenStreetMap data
   ------------------------------------------------------------
   213 named buildings on and around the TTU Lubbock campus,
   pulled from OpenStreetMap via Overpass (ODbL licensed).
   Coordinates are real, not estimated. `walk` is computed from
   straight-line distance to the campus core at ~1.35 m/s, so
   it's an approximation that ignores actual paths — good enough
   to be useful, not turn-by-turn accurate.

   `kind` is derived from OSM building/amenity/shop tags plus
   name heuristics. Jones AT&T Stadium and United Supermarkets
   Arena are appended manually: OSM tags them leisure=stadium
   rather than building=*, so the building query missed them.
   ============================================================ */

const BUILDINGS = [
  { id: 'chemistry-building', name: 'Chemistry Building', kind: 'Academic', lat: 33.583688, lng: -101.876247, walk: 1 },
  { id: 'mathematics-statistics', name: 'Mathematics & Statistics', kind: 'Academic', lat: 33.585007, lng: -101.876252, walk: 1 },
  { id: 'science-building', name: 'Science Building', kind: 'Academic', lat: 33.584421, lng: -101.877303, walk: 1 },
  { id: 'agricultural-education', name: 'Agricultural Education', kind: 'Academic', lat: 33.582723, lng: -101.877251, walk: 2 },
  { id: 'agricultural-sciences-building', name: 'Agricultural Sciences Building', kind: 'Academic', lat: 33.582834, lng: -101.876043, walk: 2 },
  { id: 'biology-building', name: 'Biology Building', kind: 'Academic', lat: 33.585066, lng: -101.878108, walk: 2 },
  { id: 'biology-lecture-hall', name: 'Biology Lecture Hall', kind: 'Academic', lat: 33.584675, lng: -101.877871, walk: 2 },
  { id: 'engineering-and-materials-research', name: 'Engineering and Materials Research Center', kind: 'Academic', lat: 33.585471, lng: -101.875415, walk: 2 },
  { id: 'experimental-sciences-building', name: 'Experimental Sciences Building', kind: 'Academic', lat: 33.585489, lng: -101.877435, walk: 2 },
  { id: 'food-technology', name: 'Food Technology', kind: 'Academic', lat: 33.582637, lng: -101.876375, walk: 2 },
  { id: 'national-wind-institute', name: 'National Wind Institute', kind: 'Academic', lat: 33.585622, lng: -101.876005, walk: 2 },
  { id: 'administration-building', name: 'Administration Building', kind: 'Academic', lat: 33.583238, lng: -101.874685, walk: 3 },
  { id: 'electrical-and-computer-engineerin', name: 'Electrical and Computer Engineering', kind: 'Academic', lat: 33.586684, lng: -101.875554, walk: 3, short: 'ECE' },
  { id: 'experimental-sciences-building-ii', name: 'Experimental Sciences Building II', kind: 'Academic', lat: 33.585523, lng: -101.878788, walk: 3 },
  { id: 'landscape-architecture-and-range-w', name: 'Landscape Architecture and Range Wildlife and Fisheries Management', kind: 'Academic', lat: 33.582693, lng: -101.878271, walk: 3 },
  { id: 'pulse-lab', name: 'Pulse Lab', kind: 'Academic', lat: 33.586385, lng: -101.876217, walk: 3 },
  { id: 'chemical-engineering', name: 'Chemical Engineering', kind: 'Academic', lat: 33.587611, lng: -101.87642, walk: 4, short: 'ChemE' },
  { id: 'civil-engineering', name: 'Civil Engineering', kind: 'Academic', lat: 33.586684, lng: -101.873836, walk: 4, short: 'CE' },
  { id: 'engineering-center', name: 'Engineering Center', kind: 'Academic', lat: 33.58726, lng: -101.875555, walk: 4 },
  { id: 'holden-hall', name: 'Holden Hall', kind: 'Academic', lat: 33.585591, lng: -101.873687, walk: 4 },
  { id: 'human-sciences-building', name: 'Human Sciences Building', kind: 'Academic', lat: 33.583355, lng: -101.873075, walk: 4 },
  { id: 'industrial-mechanical-systems-engi', name: 'Industrial, Mechanical & Systems Engineering', kind: 'Academic', lat: 33.587192, lng: -101.876376, walk: 4, short: 'IMSE' },
  { id: 'computer-science', name: 'Computer Science', kind: 'Academic', lat: 33.587639, lng: -101.875317, walk: 5, short: 'CS' },
  { id: 'engineering-technology-lab', name: 'Engineering & Technology Lab', kind: 'Academic', lat: 33.587196, lng: -101.8739, walk: 5 },
  { id: 'english-philosophy-building', name: 'English/Philosophy Building', kind: 'Academic', lat: 33.581412, lng: -101.879238, walk: 5 },
  { id: 'foreign-language-building', name: 'Foreign Language Building', kind: 'Academic', lat: 33.580866, lng: -101.878491, walk: 5 },
  { id: 'livermore-center', name: 'Livermore Center', kind: 'Academic', lat: 33.587693, lng: -101.876071, walk: 5 },
  { id: 'mechanical-engineering-south', name: 'Mechanical Engineering South', kind: 'Academic', lat: 33.588001, lng: -101.874706, walk: 5, short: 'MES' },
  { id: 'psychology-building', name: 'Psychology Building', kind: 'Academic', lat: 33.580556, lng: -101.877155, walk: 5 },
  { id: 'west-hall', name: 'West Hall', kind: 'Academic', lat: 33.585325, lng: -101.87244, walk: 5 },
  { id: 'art-building', name: 'Art Building', kind: 'Academic', lat: 33.580722, lng: -101.880127, walk: 6 },
  { id: 'burkhart-center-for-autism-educati', name: 'Burkhart Center for Autism Education & Research', kind: 'Academic', lat: 33.580321, lng: -101.878483, walk: 6 },
  { id: 'college-of-media-and-communication', name: 'College of Media and Communication', kind: 'Academic', lat: 33.582051, lng: -101.880618, walk: 6 },
  { id: 'drane-hall', name: 'Drane Hall', kind: 'Academic', lat: 33.581614, lng: -101.872344, walk: 6 },
  { id: 'education-building', name: 'Education Building', kind: 'Academic', lat: 33.580319, lng: -101.879245, walk: 6 },
  { id: 'mechnical-engineering-north', name: 'Mechnical Engineering North', kind: 'Academic', lat: 33.588386, lng: -101.87495, walk: 6, short: 'MEN' },
  { id: 'petroleum-engineering', name: 'Petroleum Engineering', kind: 'Academic', lat: 33.587803, lng: -101.873711, walk: 6, short: 'PE' },
  { id: 'rawls-college-of-business', name: 'Rawls College of Business', kind: 'Academic', lat: 33.587693, lng: -101.879439, walk: 6 },
  { id: 'weeks-hall', name: 'Weeks Hall', kind: 'Academic', lat: 33.583381, lng: -101.871686, walk: 6 },
  { id: 'architecture-building', name: 'Architecture Building', kind: 'Academic', lat: 33.580667, lng: -101.88068, walk: 7 },
  { id: 'cash-family-sports-nutrition-cente', name: 'Cash Family Sports Nutrition Center', kind: 'Academic', lat: 33.589662, lng: -101.875441, walk: 7 },
  { id: 'creative-motion-dance-studio', name: 'Creative Motion Dance Studio', kind: 'Academic', lat: 33.588083, lng: -101.872712, walk: 7 },
  { id: 'marsha-sharp-center-for-student-at', name: 'Marsha Sharp Center for Student Athletics', kind: 'Academic', lat: 33.58899, lng: -101.874746, walk: 7 },
  { id: 'frazier-alumni-pavilion', name: 'Frazier Alumni Pavilion', kind: 'Academic', lat: 33.589651, lng: -101.874702, walk: 8 },
  { id: 'southwest-collection-special-colle', name: 'Southwest Collection/Special Collection Library', kind: 'Library', lat: 33.581932, lng: -101.877044, walk: 3, hours: 'Mo-Fr 09:00-17:00; PH off' },
  { id: 'texas-tech-university-library', name: 'Texas Tech University Library', kind: 'Library', lat: 33.581411, lng: -101.876381, walk: 4, hours: 'Mo-Sa 06:00-02:00, Su 10:00-02:00; PH off', short: 'TTU Library' },
  { id: 'little-panda', name: 'Little Panda', kind: 'Dining', lat: 33.583676, lng: -101.870347, walk: 7, cuisine: 'chinese' },
  { id: 'one-guy', name: 'One Guy', kind: 'Dining', lat: 33.585303, lng: -101.870262, walk: 7, cuisine: 'pizza;calzone' },
  { id: 'subway', name: 'Subway', kind: 'Dining', lat: 33.585072, lng: -101.87026, walk: 7, cuisine: 'sandwich' },
  { id: 'the-commons-food-court', name: 'The Commons Food Court', kind: 'Dining', lat: 33.57956, lng: -101.874184, walk: 7 },
  { id: '7-brew-coffee', name: '7 Brew Coffee', kind: 'Dining', lat: 33.581933, lng: -101.870304, walk: 8, hours: 'Mo-Su 05:30-22:00' },
  { id: 'braum-s', name: 'Braum\'s', kind: 'Dining', lat: 33.587156, lng: -101.870156, walk: 8, hours: '06:00-02:00', cuisine: 'ice_cream;burger' },
  { id: 'chimy-s', name: 'Chimy\'s', kind: 'Dining', lat: 33.584188, lng: -101.869735, walk: 8 },
  { id: 'cricket-s-grill', name: 'Cricket\'s Grill', kind: 'Dining', lat: 33.584791, lng: -101.869686, walk: 8 },
  { id: 'dreamer-s-bistro', name: 'Dreamer\'s Bistro', kind: 'Dining', lat: 33.586198, lng: -101.870379, walk: 8 },
  { id: 'jimmy-john-s', name: 'Jimmy John\'s', kind: 'Dining', lat: 33.584238, lng: -101.869467, walk: 8, cuisine: 'sandwich' },
  { id: 'raising-cane-s', name: 'Raising Cane\'s', kind: 'Dining', lat: 33.58679, lng: -101.870053, walk: 8, cuisine: 'chicken' },
  { id: 'spanky-s', name: 'Spanky\'s', kind: 'Dining', lat: 33.587681, lng: -101.870316, walk: 8 },
  { id: 'papa-john-s', name: 'Papa John\'s', kind: 'Dining', lat: 33.587713, lng: -101.870125, walk: 9, hours: 'Mo-Th 10:00-23:00; Fr-Sa 10:00-24:00; Su 10:00-23:00', cuisine: 'pizza' },
  { id: 'tikka-shack', name: 'Tikka Shack', kind: 'Dining', lat: 33.58684, lng: -101.869327, walk: 9, cuisine: 'indian' },
  { id: 'whataburger', name: 'Whataburger', kind: 'Dining', lat: 33.587533, lng: -101.86937, walk: 9, cuisine: 'burger' },
  { id: 'chili-s', name: 'Chili\'s', kind: 'Dining', lat: 33.589315, lng: -101.870189, walk: 10, cuisine: 'tex-mex' },
  { id: 'chipotle', name: 'Chipotle', kind: 'Dining', lat: 33.588066, lng: -101.869445, walk: 10, cuisine: 'mexican' },
  { id: 'potbelly', name: 'Potbelly', kind: 'Dining', lat: 33.587526, lng: -101.868687, walk: 10, cuisine: 'sandwich' },
  { id: 'torchy-s-tacos', name: 'Torchy\'s Tacos', kind: 'Dining', lat: 33.586777, lng: -101.868749, walk: 10, hours: 'Mo-Th 07:00-22:00; Fr 07:00-23:00; Sa 08:00-23:00; Su 08:00-22:00', cuisine: 'mexican' },
  { id: 'velvet-taco', name: 'Velvet Taco', kind: 'Dining', lat: 33.588018, lng: -101.868741, walk: 10, hours: 'Mo-Su 11:00-22:00', cuisine: 'mexican' },
  { id: 'wiggins-complex-dining-hall', name: 'Wiggins Complex/Dining Hall', kind: 'Dining', lat: 33.579701, lng: -101.883685, walk: 10 },
  { id: 'ihop', name: 'IHOP', kind: 'Dining', lat: 33.578544, lng: -101.870255, walk: 11, hours: '24/7', cuisine: 'breakfast;pancake' },
  { id: 'starbucks', name: 'Starbucks', kind: 'Dining', lat: 33.590412, lng: -101.870256, walk: 11, cuisine: 'coffee_shop' },
  { id: 'tropical-smoothie-cafe', name: 'Tropical Smoothie Cafe', kind: 'Dining', lat: 33.578229, lng: -101.869836, walk: 11, cuisine: 'juice' },
  { id: 'chick-fil-a', name: 'Chick-fil-A', kind: 'Dining', lat: 33.593513, lng: -101.870896, walk: 14, hours: 'Mo-Sa 06:00-23:00', cuisine: 'chicken' },
  { id: 'little-caesars', name: 'Little Caesars', kind: 'Dining', lat: 33.57821, lng: -101.866773, walk: 14, cuisine: 'pizza' },
  { id: 'panda-express', name: 'Panda Express', kind: 'Dining', lat: 33.593515, lng: -101.869973, walk: 15, hours: 'Mo-Th 10:00-22:30; Fr-Sa 10:00-23:00; Su 10:00-22:30', cuisine: 'chinese' },
  { id: 'popeyes', name: 'Popeyes', kind: 'Dining', lat: 33.594404, lng: -101.870868, walk: 15, hours: '10:30-21:30', cuisine: 'chicken' },
  { id: 'wienerschnitzel', name: 'Wienerschnitzel', kind: 'Dining', lat: 33.594028, lng: -101.870086, walk: 15, cuisine: 'hot_dog' },
  { id: 'kfc', name: 'KFC', kind: 'Dining', lat: 33.594994, lng: -101.86998, walk: 16, cuisine: 'chicken' },
  { id: 'sonic', name: 'Sonic', kind: 'Dining', lat: 33.598058, lng: -101.870913, walk: 20, hours: 'Mo-Th 06:00-23:00; Fr-Sa 06:00-24:00; Su 08:00-23:00', cuisine: 'burger' },
  { id: 'united-supermarkets-arena', name: 'United Supermarkets Arena', kind: 'Athletics', lat: 33.58778, lng: -101.8725, walk: 7 },
  { id: 'student-recreation-center', name: 'Student Recreation Center', kind: 'Athletics', lat: 33.582749, lng: -101.884498, walk: 9, hours: 'Mo-Fr 06:00-24:00, Sa 08:00-22:00, Su 12:00-24:00' },
  { id: 'jones-att-stadium', name: 'Galaxy Stadium', kind: 'Athletics', lat: 33.59109, lng: -101.87278, walk: 10 },
  { id: 'quick-track', name: 'Quick Track', kind: 'Athletics', lat: 33.578221, lng: -101.867129, walk: 14 },
  { id: 'murray-residence-hall', name: 'Murray Residence Hall', kind: 'Housing', lat: 33.586662, lng: -101.87873, walk: 4 },
  { id: 'carpenter-wells-residential-comple', name: 'Carpenter/Wells Residential Complex', kind: 'Housing', lat: 33.585997, lng: -101.880123, walk: 5 },
  { id: 'doak-hall', name: 'Doak Hall', kind: 'Housing', lat: 33.582823, lng: -101.872431, walk: 5 },
  { id: 'honors-residence-hall', name: 'Honors Residence Hall', kind: 'Housing', lat: 33.586946, lng: -101.879776, walk: 5 },
  { id: 'stangel-murdough-residence-hall', name: 'Stangel Murdough Residence Hall', kind: 'Housing', lat: 33.583481, lng: -101.880465, walk: 5 },
  { id: 'gordon-bledsoe-residence-hall', name: 'Gordon/Bledsoe Residence Hall', kind: 'Housing', lat: 33.586372, lng: -101.87173, walk: 6 },
  { id: 'sneed-residence-hall', name: 'Sneed Residence Hall', kind: 'Housing', lat: 33.585391, lng: -101.871376, walk: 6 },
  { id: 'horn-knapp-residence-hall', name: 'Horn/Knapp Residence Hall', kind: 'Housing', lat: 33.580532, lng: -101.87278, walk: 7 },
  { id: 'wall-gates-residence-hall', name: 'Wall/Gates Residence Hall', kind: 'Housing', lat: 33.578986, lng: -101.877034, walk: 7 },
  { id: 'hulen-clement-residence-hall', name: 'Hulen/Clement Residence Hall', kind: 'Housing', lat: 33.578986, lng: -101.879702, walk: 8 },
  { id: 'j-t-and-margaret-talkington-reside', name: 'J.T. and Margaret Talkington Residence Hall', kind: 'Housing', lat: 33.578991, lng: -101.874745, walk: 8 },
  { id: 'u-lofts-apartments', name: 'U Lofts Apartments', kind: 'Housing', lat: 33.585935, lng: -101.869987, walk: 8 },
  { id: 'chitwood-weymouth-residence-hall', name: 'Chitwood Weymouth Residence Hall', kind: 'Housing', lat: 33.579841, lng: -101.88232, walk: 9 },
  { id: 'coleman-residence-hall', name: 'Coleman Residence Hall', kind: 'Housing', lat: 33.57887, lng: -101.882637, walk: 10 },
  { id: 'centre-at-overton-park', name: 'Centre at Overton Park', kind: 'Housing', lat: 33.589217, lng: -101.869052, walk: 11 },
  { id: 'the-village-at-overton-park', name: 'The VIllage at Overton Park', kind: 'Housing', lat: 33.590515, lng: -101.869135, walk: 12 },
  { id: 'the-village-at-overton-park-2', name: 'The Village at Overton Park', kind: 'Housing', lat: 33.591242, lng: -101.86914, walk: 13 },
  { id: 'raiders-pass-front-office', name: 'Raiders Pass Front Office', kind: 'Housing', lat: 33.593496, lng: -101.884367, walk: 15 },
  { id: 'biology-greenhouse', name: 'Biology Greenhouse', kind: 'Campus', lat: 33.584715, lng: -101.878534, walk: 2 },
  { id: 'agricultural-pavillion', name: 'Agricultural Pavillion', kind: 'Campus', lat: 33.58221, lng: -101.876809, walk: 3 },
  { id: 'fisheries-wildlife-research', name: 'Fisheries & Wildlife Research', kind: 'Campus', lat: 33.582819, lng: -101.878848, walk: 3 },
  { id: 'bayer-plant-science-building', name: 'Bayer Plant Science Building', kind: 'Campus', lat: 33.582042, lng: -101.878515, walk: 4 },
  { id: 'child-development-research-center', name: 'Child Development Research Center', kind: 'Campus', lat: 33.582677, lng: -101.873382, walk: 4 },
  { id: 'goddard-range-and-wildlife-managem', name: 'Goddard Range and Wildlife Management Building', kind: 'Campus', lat: 33.582111, lng: -101.878144, walk: 4 },
  { id: 'dairy-barn', name: 'Dairy Barn', kind: 'Campus', lat: 33.581308, lng: -101.878119, walk: 5 },
  { id: 'development-building', name: 'Development Building', kind: 'Campus', lat: 33.581653, lng: -101.873055, walk: 5 },
  { id: 'music-building', name: 'Music Building', kind: 'Campus', lat: 33.580915, lng: -101.874529, walk: 5 },
  { id: 'doak-conference-center', name: 'Doak Conference Center', kind: 'Campus', lat: 33.582757, lng: -101.871636, walk: 6 },
  { id: 'mcclellan-hall', name: 'McClellan Hall', kind: 'Campus', lat: 33.581359, lng: -101.873171, walk: 6 },
  { id: 'lighthouse-college-tutoring', name: 'Lighthouse College Tutoring', kind: 'Campus', lat: 33.584142, lng: -101.870345, walk: 7 },
  { id: 'marines-officer-selection-office', name: 'Marines Officer Selection Office', kind: 'Campus', lat: 33.58591, lng: -101.870378, walk: 7 },
  { id: 't-c-elli-s', name: 'T. C. Elli\'s', kind: 'Campus', lat: 33.584789, lng: -101.870132, walk: 7 },
  { id: 'bpl-plasma', name: 'BPL Plasma', kind: 'Campus', lat: 33.585194, lng: -101.869579, walk: 8 },
  { id: 'mckenzie-merket-alumni-center', name: 'McKenzie-Merket Alumni Center', kind: 'Campus', lat: 33.579504, lng: -101.87275, walk: 8 },
  { id: 'physical-plant', name: 'Physical Plant', kind: 'Campus', lat: 33.585632, lng: -101.883674, walk: 8 },
  { id: 'sports-performance-center', name: 'Sports Performance Center', kind: 'Campus', lat: 33.589501, lng: -101.873102, walk: 8 },
  { id: '21-hundred-overton-park-leasing-of', name: '21 Hundred @ Overton Park Leasing Office', kind: 'Campus', lat: 33.586705, lng: -101.869326, walk: 9 },
  { id: 'athletic-training-complex', name: 'Athletic Training Complex', kind: 'Campus', lat: 33.589727, lng: -101.871523, walk: 9 },
  { id: 'atlas-campus-fellowship', name: 'Atlas Campus Fellowship', kind: 'Campus', lat: 33.584795, lng: -101.86882, walk: 9 },
  { id: 'student-pool', name: 'Student Pool', kind: 'Campus', lat: 33.583569, lng: -101.884433, walk: 9 },
  { id: 'wildwood-lubbock-leasing-office', name: 'Wildwood Lubbock Leasing Office', kind: 'Campus', lat: 33.587959, lng: -101.870294, walk: 9 },
  { id: 'art-3d-annex', name: 'Art 3D Annex', kind: 'Campus', lat: 33.584843, lng: -101.88503, walk: 10 },
  { id: 'canterbury-campus-ministry', name: 'Canterbury Campus Ministry', kind: 'Campus', lat: 33.580319, lng: -101.869014, walk: 10 },
  { id: 'lovell-co-billiards-barstool', name: 'Lovell Co Billiards & Barstool', kind: 'Campus', lat: 33.579823, lng: -101.870217, walk: 10 },
  { id: 'physical-plant-annex', name: 'Physical Plant Annex', kind: 'Campus', lat: 33.585861, lng: -101.884899, walk: 10 },
  { id: 'heartline', name: 'HeartLine', kind: 'Campus', lat: 33.584199, lng: -101.867167, walk: 11 },
  { id: 'phillips-66', name: 'Phillips 66', kind: 'Campus', lat: 33.57814, lng: -101.870228, walk: 11 },
  { id: 'saint-elizabeth-s-catholic-center', name: 'Saint Elizabeth\'s Catholic Center', kind: 'Campus', lat: 33.584821, lng: -101.866879, walk: 11 },
  { id: 'university-parking-services-admini', name: 'University Parking Services / Administrative Support Center', kind: 'Campus', lat: 33.591752, lng: -101.880679, walk: 11 },
  { id: 'alon-2', name: 'Alon', kind: 'Campus', lat: 33.592627, lng: -101.879472, walk: 12 },
  { id: 'bodybronze', name: 'BodyBronze', kind: 'Campus', lat: 33.578154, lng: -101.868974, walk: 12 },
  { id: 'hampton-inn-suites-lubbock-univers', name: 'Hampton Inn & Suites Lubbock University', kind: 'Campus', lat: 33.592945, lng: -101.878323, walk: 12 },
  { id: 'john-saleh-catholic-student-center', name: 'John Saleh Catholic Student Center', kind: 'Campus', lat: 33.585192, lng: -101.865741, walk: 12 },
  { id: 'national-ranching-heritage-center', name: 'National Ranching Heritage Center', kind: 'Campus', lat: 33.590759, lng: -101.884096, walk: 12, hours: 'Mo-Sa 10:00-17:00; Su 13:00-17:00' },
  { id: 'state-farm', name: 'State Farm', kind: 'Campus', lat: 33.578155, lng: -101.869051, walk: 12 },
  { id: 'tarbox-law', name: 'Tarbox Law', kind: 'Campus', lat: 33.5842, lng: -101.866448, walk: 12 },
  { id: 'the-testosterhome', name: 'The Testosterhome', kind: 'Campus', lat: 33.581905, lng: -101.86639, walk: 12 },
  { id: '2216-broadway', name: '2216 Broadway', kind: 'Campus', lat: 33.584778, lng: -101.865403, walk: 13 },
  { id: 'alon', name: 'Alon', kind: 'Campus', lat: 33.592078, lng: -101.870356, walk: 13 },
  { id: 'choochai', name: 'Choochai', kind: 'Campus', lat: 33.578205, lng: -101.867442, walk: 13 },
  { id: 'combest', name: 'Combest', kind: 'Campus', lat: 33.584819, lng: -101.864905, walk: 13 },
  { id: 'hyatt-place-lubbock', name: 'Hyatt Place Lubbock', kind: 'Campus', lat: 33.589759, lng: -101.866851, walk: 13 },
  { id: 'overton-hotel-conference-center', name: 'Overton Hotel & Conference Center', kind: 'Campus', lat: 33.590908, lng: -101.867876, walk: 13 },
  { id: 'conoco', name: 'Conoco', kind: 'Campus', lat: 33.577995, lng: -101.867172, walk: 14 },
  { id: 'fiestas-del-llano', name: 'Fiestas Del Llano', kind: 'Campus', lat: 33.594503, lng: -101.869969, walk: 16 },
  { id: 'residence-inn', name: 'Residence Inn', kind: 'Campus', lat: 33.593809, lng: -101.868695, walk: 16 },
  { id: 'back-clubhouse', name: 'Back Clubhouse', kind: 'Campus', lat: 33.595426, lng: -101.884221, walk: 18 },
  { id: 'student-union', name: 'Student Union', kind: 'Services', lat: 33.581551, lng: -101.87477, walk: 4 },
  { id: 'wells-fargo', name: 'Wells Fargo', kind: 'Services', lat: 33.583802, lng: -101.870258, walk: 7 },
  { id: 'wesley-foundation', name: 'Wesley Foundation', kind: 'Services', lat: 33.581935, lng: -101.869973, walk: 8 },
  { id: 'amazon-lubbock', name: 'Amazon@Lubbock', kind: 'Services', lat: 33.586764, lng: -101.869165, walk: 9, hours: 'Mo-Su 09:00-21:00' },
  { id: 'chase', name: 'Chase', kind: 'Services', lat: 33.588076, lng: -101.870299, walk: 9, hours: 'Mo-Fr 09:00-17:00; Sa 09:00-14:00; Su closed' },
  { id: 'city-bank', name: 'City Bank', kind: 'Services', lat: 33.588614, lng: -101.87019, walk: 9, hours: 'Mo-Fr 08:30-16:00' },
  { id: 'texas-tech-police-department', name: 'Texas Tech Police Department', kind: 'Services', lat: 33.591841, lng: -101.879808, walk: 11 },
  { id: 'bank-of-america', name: 'Bank of America', kind: 'Services', lat: 33.578181, lng: -101.867604, walk: 13 },
  { id: 'student-wellness-center', name: 'Student Wellness Center', kind: 'Health', lat: 33.586075, lng: -101.881704, walk: 6 },
  { id: 'cvs-pharmacy', name: 'CVS Pharmacy', kind: 'Health', lat: 33.582375, lng: -101.870188, walk: 8, short: 'CVS' },
  { id: 'dr-william-a-shaver-md', name: 'Dr. William A. Shaver, MD', kind: 'Health', lat: 33.584201, lng: -101.86895, walk: 9 },
  { id: 'familia-dental', name: 'Familia Dental', kind: 'Health', lat: 33.578187, lng: -101.868746, walk: 12 },
  { id: 'baptist-student-center', name: 'Baptist Student Center', kind: 'Worship', lat: 33.583285, lng: -101.868631, walk: 9 },
  { id: 'kent-r-hance-chapel', name: 'Kent R. Hance Chapel', kind: 'Worship', lat: 33.579285, lng: -101.87133, walk: 9 },
  { id: 'st-john-s-united-methodist-church', name: 'St. John\'s United Methodist Church', kind: 'Worship', lat: 33.58137, lng: -101.869847, walk: 9 },
  { id: 'first-christian-church', name: 'First Christian Church', kind: 'Worship', lat: 33.584003, lng: -101.867872, walk: 10 },
  { id: 'saint-elizabeth-catholic-church', name: 'Saint Elizabeth Catholic Church', kind: 'Worship', lat: 33.584798, lng: -101.867709, walk: 10 },
  { id: 'st-paul-s-on-the-plains-episcopal-', name: 'St. Paul\'s on the Plains Episcopal Church', kind: 'Worship', lat: 33.580816, lng: -101.868682, walk: 10 },
  { id: 'saint-elizabeth-s-old-chapel', name: 'Saint Elizabeth’s Old Chapel', kind: 'Worship', lat: 33.585168, lng: -101.866804, walk: 11 },
  { id: 'first-baptist-church-lubbock', name: 'First Baptist Church Lubbock', kind: 'Worship', lat: 33.584, lng: -101.864673, walk: 14 },
  { id: 'university-theatre', name: 'University Theatre', kind: 'Arts', lat: 33.58021, lng: -101.877806, walk: 6 },
  { id: 'conference', name: 'Conference', kind: 'Arts', lat: 33.585245, lng: -101.86985, walk: 8 },
  { id: 'allsup-s', name: 'Allsup\'s', kind: 'Retail', lat: 33.584899, lng: -101.870296, walk: 7 },
  { id: 'andropolis', name: 'Andropolis', kind: 'Retail', lat: 33.58295, lng: -101.870366, walk: 7 },
  { id: 'bodega', name: 'Bodega', kind: 'Retail', lat: 33.585646, lng: -101.870377, walk: 7 },
  { id: 'cricket-wireless', name: 'Cricket Wireless', kind: 'Retail', lat: 33.584042, lng: -101.870345, walk: 7, short: 'Cricket' },
  { id: 'eclectic-people-salon', name: 'Eclectic People Salon', kind: 'Retail', lat: 33.584724, lng: -101.870226, walk: 7 },
  { id: 'locker-room', name: 'Locker Room', kind: 'Retail', lat: 33.586025, lng: -101.870378, walk: 7 },
  { id: 'next-generation-vintage', name: 'Next Generation Vintage', kind: 'Retail', lat: 33.585792, lng: -101.870378, walk: 7 },
  { id: 'sarah-belle-s-boutique', name: 'Sarah Belle\'s Boutique', kind: 'Retail', lat: 33.583745, lng: -101.870258, walk: 7 },
  { id: 'snag', name: 'Snag', kind: 'Retail', lat: 33.583677, lng: -101.870175, walk: 7, hours: 'Mo-Su 12:00-24:00' },
  { id: 'the-matador', name: 'The Matador', kind: 'Retail', lat: 33.584724, lng: -101.870354, walk: 7 },
  { id: 'varsity-bookstore', name: 'Varsity Bookstore', kind: 'Retail', lat: 33.583292, lng: -101.8702, walk: 7 },
  { id: 'varsity-jewelers', name: 'Varsity Jewelers', kind: 'Retail', lat: 33.583028, lng: -101.870336, walk: 7 },
  { id: 'paddle-tramps', name: 'Paddle Tramps', kind: 'Retail', lat: 33.582827, lng: -101.870231, walk: 8 },
  { id: 'red-raider-outfitter', name: 'Red Raider Outfitter', kind: 'Retail', lat: 33.584729, lng: -101.869851, walk: 8 },
  { id: 'copy-outlet', name: 'Copy Outlet', kind: 'Retail', lat: 33.584758, lng: -101.8686, walk: 9 },
  { id: 'fedex-office', name: 'FedEx Office', kind: 'Retail', lat: 33.587872, lng: -101.870284, walk: 9 },
  { id: 'us-nails-spa', name: 'US Nails & Spa', kind: 'Retail', lat: 33.580212, lng: -101.870091, walk: 9 },
  { id: 'california-t-s-screen-printing-emb', name: 'California T\'s Screen Printing Embroidery', kind: 'Retail', lat: 33.57963, lng: -101.870198, walk: 10 },
  { id: 'pink', name: 'Pink', kind: 'Retail', lat: 33.579068, lng: -101.870214, walk: 10 },
  { id: '7-eleven-2', name: '7-Eleven', kind: 'Retail', lat: 33.592904, lng: -101.879476, walk: 12 },
  { id: 'pj-s-barbershop', name: 'PJ\'s Barbershop', kind: 'Retail', lat: 33.592816, lng: -101.879839, walk: 12 },
  { id: 'raider-mart', name: 'Raider Mart', kind: 'Retail', lat: 33.592905, lng: -101.879624, walk: 12 },
  { id: 't-mobile', name: 'T-Mobile', kind: 'Retail', lat: 33.578156, lng: -101.869163, walk: 12, hours: 'Mo-Sa 10:00-20:00, Su 12:00-18:00' },
  { id: '7-eleven', name: '7-Eleven', kind: 'Retail', lat: 33.592022, lng: -101.870055, walk: 13 },
  { id: 'verizon', name: 'Verizon', kind: 'Retail', lat: 33.578211, lng: -101.866938, walk: 14 },
  { id: 'aaron-s', name: 'Aaron\'s', kind: 'Retail', lat: 33.57814, lng: -101.865646, walk: 15, hours: 'Mo-Th 10:00-19:00; Fr 10:00-20:00; Sa 10:00-17:00; Su closed' },
  { id: 'dollar-general', name: 'Dollar General', kind: 'Retail', lat: 33.578126, lng: -101.865172, walk: 16 },
  { id: 'flint-ave-garage', name: 'Flint Ave Garage', kind: 'Parking', lat: 33.579312, lng: -101.881015, walk: 9 },
  { id: 'raider-park-garage', name: 'Raider Park Garage', kind: 'Parking', lat: 33.593626, lng: -101.874071, walk: 13 },
];

/* ============================================================
   OSM OPENING HOURS
   ------------------------------------------------------------
   Parses the subset of the opening_hours spec that actually
   appears in this dataset — day ranges, day lists, time spans,
   overnight spans, and 24/7. Returns null when a value uses
   syntax we don't handle, so callers can fall back to showing
   nothing rather than showing something wrong.
   ============================================================ */

const OH_DAYS = { Mo: 0, Tu: 1, We: 2, Th: 3, Fr: 4, Sa: 5, Su: 6 };

function ohMinutes(hhmm) {
  const m = hhmm.match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return null;
  return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
}

function ohDaySet(token) {
  // "Mo-Th" | "Fr-Sa" | "Mo,We,Fr" | "Su"
  const days = new Set();
  for (const part of token.split(',')) {
    const range = part.match(/^([A-Za-z]{2})-([A-Za-z]{2})$/);
    if (range) {
      const a = OH_DAYS[range[1]], b = OH_DAYS[range[2]];
      if (a === undefined || b === undefined) return null;
      for (let i = 0; i < 7; i++) {
        const d = (a + i) % 7;
        days.add(d);
        if (d === b) break;
      }
    } else if (OH_DAYS[part] !== undefined) {
      days.add(OH_DAYS[part]);
    } else return null;
  }
  return days;
}

/** true | false | null (unknown/unparseable) */
function isOpenNow(spec, now = new Date()) {
  if (!spec) return null;
  const s = spec.trim();
  if (/^24\/7$/i.test(s)) return true;

  // JS getDay(): 0=Sun. OSM week starts Monday.
  const dow = (now.getDay() + 6) % 7;
  const mins = now.getHours() * 60 + now.getMinutes();

  for (const rule of s.split(';')) {
    const r = rule.trim();
    if (!r) continue;
    if (/off|closed/i.test(r)) continue;

    // Either "Mo-Fr 08:00-17:00" or a bare "06:00-02:00" (every day)
    const m = r.match(/^(?:([A-Za-z]{2}(?:[-,][A-Za-z]{2})*)\s+)?(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})$/);
    if (!m) return null; // unhandled syntax — don't guess

    const days = m[1] ? ohDaySet(m[1]) : null;
    if (m[1] && !days) return null;

    const open = ohMinutes(m[2]);
    let close = ohMinutes(m[3]);
    if (open === null || close === null) return null;

    const overnight = close <= open;
    if (overnight) close += 24 * 60;

    const applies = (d) => !days || days.has(d);

    if (applies(dow) && mins >= open && mins < close) return true;
    // An overnight span started yesterday can still cover right now.
    if (overnight) {
      const prev = (dow + 6) % 7;
      if (applies(prev) && mins + 24 * 60 >= open && mins + 24 * 60 < close) return true;
    }
  }
  return false;
}

const buildingById = (id) => BUILDINGS.find((b) => b.id === id);

const walkLabel = (b) => (b && b.walk ? `${b.walk} min walk` : '');

// Filter categories derived from what's actually in the data,
// ordered by how many buildings each has.
const CAMPUS_CATS = ['All', ...Object.entries(
  BUILDINGS.reduce((acc, b) => { acc[b.kind] = (acc[b.kind] || 0) + 1; return acc; }, {})
).sort((a, b) => b[1] - a[1]).map(([k]) => k)];

/* Display labels for filter categories. The underlying `kind`
   values come straight from OpenStreetMap's own tagging and are
   left untouched (changing them would break every buildingId
   filter), but a few of OSM's raw terms read oddly as user-facing
   labels — "Worship" in particular is narrower than the buildings
   it actually covers, which include student centers and chapels
   across several faiths. */
const CAT_LABELS = {
  Worship: 'Faith & Spiritual Life',
};
const catLabel = (c) => CAT_LABELS[c] || c;
/* Status string for a place, honest about what we actually know:
   real hours -> Open/Closed now; no hours in OSM -> just the walk. */
/* Expands an OSM opening_hours string into a real, readable
   seven-row schedule — this is what actually surfaces posted
   opening and closing times to a student rather than only a
   computed "Open now" dot. Days with no matching rule show
   "Closed", which is the honest reading of the published hours,
   not an assumption. */
const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const OH_CODES = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];

function fmt12(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  if (h === 24 || (h === 0 && m === 0)) return 'Midnight';
  const suffix = h >= 12 ? 'pm' : 'am';
  const hr = h % 12 === 0 ? 12 : h % 12;
  return m === 0 ? `${hr}${suffix}` : `${hr}:${String(m).padStart(2, '0')}${suffix}`;
}

function hoursByDay(spec) {
  const todayIdx = (new Date().getDay() + 6) % 7;
  const perDay = Array(7).fill(null);
  if (!spec) return DAY_LABELS.map((day, i) => ({ day, text: 'Hours vary', isToday: i === todayIdx }));

  // Real OSM data uses BOTH ';' and ',' as rule separators — the
  // Student Rec Center's real hours use commas. Only split on a comma
  // that FOLLOWS a completed time range, so a comma inside a day list
  // ("Mo,We,Fr 09:00-17:00") never splits the list apart.
  const rules = spec.split(/;|(?<=\d{1,2}:\d{2})\s*,/);
  for (const rule of rules) {
    const r = rule.trim();
    if (!r) continue;
    const m = r.match(/^(?:([A-Za-z]{2}(?:[-,][A-Za-z]{2})*)\s+)?(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})$/);
    if (!m) continue;
    const text = `${fmt12(m[2])} – ${fmt12(m[3])}`;
    if (!m[1]) { for (let i = 0; i < 7; i++) perDay[i] = text; continue; }
    // A day spec can be a list ("Mo,We,Fr"), a range ("Mo-Fr"), or a
    // mix ("Mo-We,Fr"). Split the list first, then expand any ranges
    // inside it — treating "Mo,We" as a range would silently skip Mo.
    for (const part of m[1].split(',')) {
      const range = part.split('-');
      const a = OH_CODES.indexOf(range[0]);
      if (a < 0) continue;
      if (range.length === 1) { perDay[a] = text; continue; }
      const b = OH_CODES.indexOf(range[1]);
      if (b < 0) continue;
      for (let i = a; ; i = (i + 1) % 7) { perDay[i] = text; if (i === b) break; }
    }
  }
  return DAY_LABELS.map((day, i) => ({ day, text: perDay[i] || 'Closed', isToday: i === todayIdx }));
}

/* Joins metadata segments with separators, dropping anything empty.
   Without this, an event missing a time or venue renders as
   "September 5, 2026 · ·" with nothing between the dots — real bug
   seen on device. Used everywhere a meta line is assembled from
   fields that may legitimately be blank. */
function metaLine(...parts) {
  return parts.filter((p) => p != null && String(p).trim() !== '').join(' · ');
}

function placeStatus(b) {
  const open = isOpenNow(b && b.hours);
  if (open === true) return 'Open now';
  if (open === false) return 'Closed';
  return walkLabel(b);
}
const CAMPUS_CENTER = { latitude: 33.58434, longitude: -101.87656 };

/* Real, verified, dated. Confirmed via texastech.com's own game
   center, KCBD, and multiple other sources: kickoff Sat Sept 5,
   2026, 6:00 PM CT, at Galaxy Stadium — the season opener under
   the stadium's new name (renamed from Jones AT&T Stadium in a
   July 2026 naming-rights deal with Galaxy).

   The rest of the events that used to live in this file (club
   meetings, career fairs, socials with specific fake times and
   rooms) have been removed rather than kept — none of them were
   real, and inventing more "real-sounding" specifics is worse
   than an honest empty state. Discover's Tonight/Happening
   sections will show 0 until real, dated events replace this,
   the same way the news feed and orgs list were built tonight:
   verified first, published second. */
const EVENTS = [];

/* FEATURED is now computed at render time from the real, dated
   FOOTBALL_SCHEDULE rather than being a frozen object. The previous
   version hardcoded `date: 'Tomorrow'`, which stayed "Tomorrow"
   permanently once that game was played — showing students a game
   that had already happened. Defined as a function (not a constant)
   because it depends on nextGame(), which is declared later. */
function featuredEvent() {
  const g = nextGame();
  if (!g) return null;
  const home = g.homeAway === 'home';
  return {
    id: 'ev-feat',
    title: `Texas Tech ${home ? 'vs.' : 'at'} ${g.opponent}`,
    org: 'Texas Tech Athletics',
    date: gameDateLabel(g.kickoff).split(' · ')[0],
    time: gameDateLabel(g.kickoff).split(' · ')[1] || '',
    endTime: '',
    buildingId: g.buildingId,
    room: g.venue,
    category: 'Campus Events',
    official: true, featured: true, live: false,
    img: IMG.stadium,
    desc: `${home ? 'Home' : 'Away'} game against ${g.opponent} at ${g.venue}.`,
  };
}

/* `days` is real recurrence data (M/T/W/Th/F), not decorative —
   Schedule filters by it so "today" actually means today, not
   every day of the week showing the same four classes regardless
   of what day it is. */
const SCHEDULE_SEED = [
  { id: 's1', time: '9:00 AM', endTime: '9:50 AM', title: 'MATH 1320', place: 'Holden Hall 00077', type: 'class', kind: 'Lecture', buildingId: 'holden-hall', days: ['M', 'W', 'F'] },
  { id: 's2', time: '11:00 AM', endTime: '11:50 AM', title: 'CARS 2300', place: 'Human Sciences 00114', type: 'class', kind: 'Lab', buildingId: 'human-sciences-building', days: ['T', 'Th'] },
  { id: 's3', time: '1:00 PM', endTime: '1:50 PM', title: 'TSI 0320', place: 'Holden Hall 00073', type: 'class', kind: 'Lecture', buildingId: 'holden-hall', days: ['M', 'W', 'F'] },
  { id: 's4', time: '3:00 PM', endTime: '4:15 PM', title: 'CS 1412', place: 'Engineering Center 00101', type: 'class', kind: 'Lecture', buildingId: 'engineering-and-materials-research', days: ['T', 'Th'] },
];

const WEEK_DAYS = ['M', 'T', 'W', 'Th', 'F', 'Sa', 'Su'];
const WEEK_DAY_LABELS = { M: 'Mon', T: 'Tue', W: 'Wed', Th: 'Thu', F: 'Fri', Sa: 'Sat', Su: 'Sun' };
function todayCode() {
  // JS getDay(): 0=Sun. Map to our M..Su label set.
  return ['Su', 'M', 'T', 'W', 'Th', 'F', 'Sa'][new Date().getDay()];
}

/* Filters to items that actually recur on the given day code.
   Items with no `days` field (shouldn't happen, but defensive)
   show every day rather than silently vanishing from a missing
   field. */
function itemsOnDay(items, code) {
  return items.filter((i) => !i.days || i.days.includes(code));
}

/* ============================================================
   ORGANIZATIONS — real, verified TTU student orgs
   ------------------------------------------------------------
   Pulled from Texas Tech's official "Student Organizations by
   Type" directory (depts.ttu.edu/centerforcampuslife) and college-
   level pages (Whitacre College of Engineering, Rawls College of
   Business, College of Media & Communication). Real names, real
   category classifications as TTU itself assigns them. `tags` for
   a few come from department pages that described what the org
   actually does; where no real description was available, `tags`
   states the org's real TTU category rather than inventing detail
   TTU doesn't publish (member counts, meeting times, etc.) — same
   honesty rule as dining hours and building data.

   This is a snapshot, not a live directory feed — TechConnect's
   real list runs on a JS-rendered platform (Campus Labs Engage)
   that isn't fetchable without a browser, so this can't be kept
   current automatically the way buildings/news could be.
   ============================================================ */
/* Real Texas Tech student organizations, sourced from TechConnect's
   own directory export. 589 raw entries were reviewed; 75 excluded
   (residence hall pages, administrative/staff pages, law class-year
   cohort trackers, and entries whose entire description was literally
   "TBD") since those aren't actually joinable student organizations.
   Categories (`tags`) are heuristically derived from each org's real
   name/description — TTU's own type labels weren't part of this
   export, so this is our best-effort grouping, not an official one. */
const ORGS = [
  { id: 'a-dog-s-way-home', name: 'A Dog\'s Way Home', initials: 'DS', tags: 'General Student Organizations', reason: 'We help shelter dogs experience freedom, happiness, and a chance at finding their forever home through Lubbock\'s "Doggy Day Out" and foster programs—while improving your own well-being through meaningful, joyful community service.' },
  { id: 'adventist-christian-fellowship', name: 'Adventist Christian Fellowship', initials: 'AC', tags: 'Faith & Religious Life', reason: 'To provide a spiritual community for Adventist students from which the students can reach out to others.' },
  { id: 'african-students-organization', name: 'African Students Organization', initials: 'AF', tags: 'Cultural & Identity', reason: 'ASO is an organization open to all Texas Tech students that strives to educate our members and the community of Lubbock about African culture and current issues that are going on in our country.' },
  { id: 'ag-eco-competitive-club', name: 'Ag Eco Competitive Club', initials: 'AE', tags: 'General Student Organizations', reason: 'To provide a formally recognized student organization through which students interested in agricultural and applied economics, agribusiness, and related fields may gather funds, coordinate travel, and compete in academic competitions.' },
  { id: 'agricultural-communicators-of-', name: 'Agricultural Communicators of Tomorrow', initials: 'AC', tags: 'Agriculture & Natural Resources', reason: 'The purpose of ACT is to encourage students to develop or enhance communications skills and create awareness of professional opportunities.' },
  { id: 'agricultural-economics-grad-st', name: 'Agricultural Economics Grad Student Association', initials: 'AE', tags: 'Agriculture & Natural Resources', reason: 'The AEGSA is an organization whose purpose is to foster a strong working and professional relationship among all graduate students and faculty in the Department of Agricultural and Applied Economics.' },
  { id: 'agricultural-education-and-com', name: 'Agricultural Education and Communications Graduate Organization', initials: 'AE', tags: 'Agriculture & Natural Resources', reason: 'The purpose of AECGO is to support agricultural education and communications graduate students at research conferences, provide professional development opportunities, provide them with leadership opportunities.' },
  { id: 'agricultural-educators-of-tomo', name: 'Agricultural Educators of Tomorrow', initials: 'AE', tags: 'Agriculture & Natural Resources', reason: 'Texas Tech Collegiate FFA is a organization open to all Texas Tech students who want to participate in leadership activities. These include community service projects and agriculture promoting events.' },
  { id: 'agricultural-law-association', name: 'Agricultural Law Association', initials: 'AL', tags: 'Law', reason: 'The ALA strives to connect Texas Tech Law Students with practicing attorneys involved in the agricultural industry or agricultural related areas of the law.' },
  { id: 'agronomy-club', name: 'Agronomy Club', initials: 'AG', tags: 'General Student Organizations', reason: 'To broaden the horizon of those students interested in the agronomic sciences. We take tours of local businesses in the Agriculture Industry, host guest speakers, compete at collegiate quiz bowls.' },
  { id: 'ajedraiders', name: 'AjedRaiders', initials: 'AJ', tags: 'General Student Organizations', reason: 'Learning and playing chess ourselves and facilitating the same for others.' },
  { id: 'alpha-chi-omega', name: 'Alpha Chi Omega', initials: 'AC', tags: 'General Student Organizations', reason: 'Alpha Chi Omega is an organization about you: unique, talented, genuine women choosing a fun and meaningful way to enhance your college experience and building lifelong bonds.' },
  { id: 'alpha-delta-pi', name: 'Alpha Delta Pi', initials: 'AD', tags: 'General Student Organizations', reason: 'Alpha Delta Pi is a greek organization committed to the betterment of its members by focusing on service, sisterhood, scholarship, and leadership.' },
  { id: 'alpha-gamma-rho-fraternity', name: 'Alpha Gamma Rho Fraternity', initials: 'AG', tags: 'Fraternities & Sororities', reason: 'Social and professional fraternity based in the field of agriculture.' },
  { id: 'alpha-kappa-alpha-sorority-inc', name: 'Alpha Kappa Alpha Sorority INC, Zeta Tau Chapter', initials: 'AK', tags: 'Fraternities & Sororities', reason: 'Alpha Kappa Alpha Sorority, Inc. (AKA), is the first Greek-lettered sorority established and incorporated by African American college women, founded January 15, 1908, on the campus of Howard University.' },
  { id: 'alpha-kappa-psi', name: 'Alpha Kappa Psi', initials: 'AK', tags: 'General Student Organizations', reason: 'Alpha Kappa Psi is the premier developer of principled business leaders. It was founded in 1904 and came to Texas Tech in 1966. We are a co-ed professional business fraternity where all majors are welcome.' },
  { id: 'alpha-lambda-delta-pes', name: 'Alpha Lambda Delta & PES', initials: 'AL', tags: 'General Student Organizations', reason: 'ALD & PES are National Scholastic Honor Societies and boast 315 chapters across the United States! We run the local chapters at Texas Tech University together.' },
  { id: 'alpha-omega-epsilon', name: 'Alpha Omega Epsilon', initials: 'AO', tags: 'General Student Organizations', reason: 'Alpha Omega Epsilon is a professional and social sorority for supporting women in STEM and technical sciences.' },
  { id: 'alpha-phi', name: 'Alpha Phi', initials: 'AP', tags: 'General Student Organizations', reason: 'Alpha Phi is a sisterhood of outstanding women supporting one another in lifelong achievement, stretching from coast to coast through 159 collegiate campuses and more than 200,000 members.' },
  { id: 'alpha-phi-alpha-fraternity-inc', name: 'Alpha Phi Alpha Fraternity, Inc Eta Upsilon Chapter', initials: 'AP', tags: 'Fraternities & Sororities', reason: 'Aims: Manly Deeds, Scholarship, and Love for All Mankind. Alpha Phi Alpha Fraternity, Inc., develops leaders, promotes brotherhood and academic excellence, while providing service and advocacy.' },
  { id: 'alpha-phi-omega', name: 'Alpha Phi Omega', initials: 'AP', tags: 'General Student Organizations', reason: 'A national co-ed service fraternity whose cardinal principles are Leadership, Friendship and Service. This organization offers and provides service to the campus, community, and nation.' },
  { id: 'alpha-psi-omega', name: 'Alpha Psi Omega', initials: 'AP', tags: 'General Student Organizations', reason: 'The Alpha Psi Omega National Theatre Honor Society (Tau Cast) rewards undergraduate students who demonstrate a high standard of accomplishment at the Texas Tech University School of Theatre and Dance.' },
  { id: 'alpha-sigma-rho-sorority-inc', name: 'Alpha Sigma Rho Sorority Inc.', initials: 'AS', tags: 'Fraternities & Sororities', reason: 'The objective of this group shall be to advance involvement of intercultural relationships and its associated interests, as well as to foster and promote diversity.' },
  { id: 'alpha-tau-omega', name: 'Alpha Tau Omega', initials: 'AT', tags: 'General Student Organizations', reason: 'A social fraternity that prides itself on its excellence in academics, leadership, and athletics all while serving as a foundation for young men to better themselves as well as their community.' },
  { id: 'alpha-xi-delta', name: 'Alpha Xi Delta', initials: 'AX', tags: 'General Student Organizations', reason: 'Alpha Xi Delta is a progressive organization dedicated to the personal growth of women, enriching the lives of women throughout the world by emphasizing the ideals our founders instilled.' },
  { id: 'alpha-zeta', name: 'Alpha Zeta', initials: 'AZ', tags: 'General Student Organizations', reason: 'Alpha Zeta is an honorary, professional society for students and industry professionals in the agriculture and natural resources fields. Founded in 1897 at Ohio State University.' },
  { id: 'ambassadors-for-agriculture', name: 'Ambassadors for Agriculture', initials: 'AA', tags: 'Agriculture & Natural Resources', reason: 'The Ambassadors for Agriculture is a group of young men and women who are dedicated to spreading the story of American agriculture and opportunities for youth in agriculture and natural resources.' },
  { id: 'american-association-of-drilli', name: 'American Association Of Drilling Engineers', initials: 'AD', tags: 'STEM & Engineering', reason: 'The American Association of Drilling Engineers (AADE) helps students develop professionally by providing technical and non-technical workshops related to drilling and other trending topics in petroleum engineering fields.' },
  { id: 'american-association-of-family', name: 'American Association of Family & Consumer Sciences-Family, Career and Community Leaders of America', initials: 'AF', tags: 'STEM & Engineering', reason: 'AAFCS-FCCLA is a student organization at Texas Tech University dedicated to promoting leadership, personal growth, and career development in Family and Consumer Sciences.' },
  { id: 'american-association-of-petrol', name: 'American Association of Petroleum Geologists Student Chapter', initials: 'AP', tags: 'General Student Organizations', reason: 'The AAPG chapter at TTU is a student run professional organization focused on providing guidance and opportunities for personal development and career placement in the oil and gas industry.' },
  { id: 'american-chemical-society-stud', name: 'American Chemical Society-Student Affiliate', initials: 'AC', tags: 'General Student Organizations', reason: 'The American Chemical Society at Texas Tech University exists to unite students interested in chemistry so as to pursue intellectual stimulation and form a connected community.' },
  { id: 'american-institute-of-chemical', name: 'American Institute of Chemical Engineers', initials: 'AI', tags: 'STEM & Engineering', reason: 'The American Institute of Chemical Engineers is a student organization recognized nationwide to advance the degree of chemical engineering in industry, providing social and professional development.' },
  { id: 'american-institute-of-graphic-', name: 'American Institute of Graphic Arts', initials: 'AI', tags: 'Arts & Media', reason: 'Our community of graphic design students are devoted to inspire individual integrity to improve our skills, ethics, beliefs, and develop networking friendships while maintaining our sense of family.' },
  { id: 'american-medical-student-assoc', name: 'American Medical Student Association Tech Chapter', initials: 'AM', tags: 'Health & Pre-Professional', reason: 'We are an organization that will provide you with the benefits of any pre-professional health organization, while also exposing you to the other healthcare fields.' },
  { id: 'american-medical-women-s-assoc', name: 'American Medical Women\'s Association', initials: 'AM', tags: 'Health & Pre-Professional', reason: 'The AMWA Student Division is a Pre-Health organization that stands together on behalf of the needs and rights of women doctors and patients.' },
  { id: 'american-rock-mechanics-associ', name: 'American Rock Mechanics Association', initials: 'AR', tags: 'General Student Organizations', reason: 'Explore the American Rock Mechanics Association (ARMA), where the science of rock mechanics converges with cutting-edge innovation, a global alliance of distinguished geoscientists and engineers.' },
  { id: 'american-society-of-civil-engi', name: 'American Society of Civil Engineers', initials: 'AC', tags: 'STEM & Engineering', reason: 'ASCE is a social/academic organization for engineering students interested in civil engineering, including the annual ASCE Steel Bridge, Concrete Canoe, and Timber Strong competitions.' },
  { id: 'american-society-of-interior-d', name: 'American Society of Interior Designers', initials: 'AI', tags: 'General Student Organizations', reason: 'The purpose of ASID is to connect Interior Design students to professionals by hosting informational meetings, working towards continuous advancement in the Interior Design field.' },
  { id: 'american-society-of-mechanical', name: 'American Society of Mechanical Engineers', initials: 'AM', tags: 'STEM & Engineering', reason: 'Texas Tech American Society of Mechanical Engineers (ASME) is a student run organization that seeks to educate future engineers on different aspects of the professional engineering community.' },
  { id: 'american-string-teachers-assoc', name: 'American String Teachers Association', initials: 'AS', tags: 'General Student Organizations', reason: 'The ASTA organization at Texas Tech is a university student chapter of the national American String Teacher Association organization.' },
  { id: 'anchor-student-club', name: 'Anchor Student Club', initials: 'AN', tags: 'General Student Organizations', reason: 'ASC is a Christian organization that creates an environment for students to build community through discussions of relevant issues from a biblical perspective.' },
  { id: 'animal-and-food-science-academ', name: 'Animal and Food Science Academic Quadrathlon', initials: 'AF', tags: 'STEM & Engineering', reason: 'AQ is a competitive team that competes in competitions that include a written test, practicals, a quiz bowl contest, and a public speaking presentation based on animal science-related topics.' },
  { id: 'arnold-air-society-spencer-bri', name: 'Arnold Air Society Spencer Brian LaBrie Squadron', initials: 'AA', tags: 'General Student Organizations', reason: 'A military service organization dedicated to creating the best military officers.' },
  { id: 'asian-pacific-american-law-stu', name: 'Asian Pacific American Law Student Association', initials: 'AP', tags: 'Law', reason: 'APALSA is a student organization at Texas Tech University School of Law. Our members strive to promote diversity in our school and in the community through hosting speakers.' },
  { id: 'associated-general-contractors', name: 'Associated General Contractors', initials: 'AG', tags: 'General Student Organizations', reason: 'This organization strives to bring Construction Engineering students together to meet not only one another but professionals within the construction industry, through networking and site tours.' },
  { id: 'association-for-computing-mach', name: 'Association For Computing Machinery', initials: 'CM', tags: 'STEM & Engineering', reason: 'ACM brings together computing educators, researchers, and professionals to inspire dialogue, share resources, and address the field\'s challenges. Our ACM-W platform empowers women in Computer Science.' },
  { id: 'association-for-competitive-ma', name: 'Association for Competitive Math Olympics', initials: 'CM', tags: 'STEM & Engineering', reason: 'Fostering Excellence and Inclusivity in Mathematics. Our university organization, ACMO, is dedicated to nurturing a culture of academic excellence, ethical integrity, and inclusive participation.' },
  { id: 'association-of-bangladeshi-stu', name: 'Association of Bangladeshi Students and Scholars', initials: 'BS', tags: 'Cultural & Identity', reason: 'The Association of Bangladeshi Students and Scholars at Texas Tech University serves to bring the Bangladeshi community of Lubbock and the surrounding region together.' },
  { id: 'association-of-biologists', name: 'Association of Biologists', initials: 'BI', tags: 'General Student Organizations', reason: 'The Texas Tech University Association of Biologists (TTUAB) is a Graduate Student Organization in the Department of Biological Sciences that promotes camaraderie and sponsors grad student social events.' },
  { id: 'association-of-competitive-eng', name: 'Association of Competitive Engineers', initials: 'CE', tags: 'STEM & Engineering', reason: 'The purpose of the Association of Competitive Engineers, A.C.E., is participating in various external engineering competitions on national and international levels.' },
  { id: 'association-of-information-tec', name: 'Association of Information Technology Professionals', initials: 'IT', tags: 'STEM & Engineering', reason: 'The Texas Tech Association of Information Technology Professionals is a student organization that connects future IT leaders through networking, professional development, and hands-on tech experiences.' },
  { id: 'association-of-students-acting', name: 'Association of Students Acting in Service', initials: 'AS', tags: 'Service & Philanthropy', reason: 'The Association of Students Acting in Service (A.S.A.S.) is an organization in which recovering students and those supporting recovery create opportunities to encourage fun in recovery.' },
  { id: 'atlas-campus-fellowship', name: 'Atlas Campus Fellowship', initials: 'AC', tags: 'General Student Organizations', reason: 'We are a community of students dedicated to making room for restless hearts to find home with Christ.' },
  { id: 'ballroom-dance-at-tech', name: 'Ballroom Dance at Tech', initials: 'BD', tags: 'Arts & Media', reason: 'The Tech Ballroom Dance Team is an organization of people who enjoy learning to dance! We take lessons in Waltz, Swing, Foxtrot, Country, Salsa, and many others.' },
  { id: 'baptist-student-ministry', name: 'Baptist Student Ministry', initials: 'BM', tags: 'Faith & Religious Life', reason: 'Tech BSM exists for the world! We believe that when we impact Red Raiders, we impact the nations; therefore, we equip and encourage each other as students on the Tech campus.' },
  { id: 'best-buddies', name: 'Best Buddies', initials: 'BB', tags: 'General Student Organizations', reason: 'Best Buddies is dedicated to enhancing the lives of individuals with intellectual and developmental disabilities by providing opportunities for one-to-one friendships and leadership development.' },
  { id: 'beta-beta-beta-nu-alpha-chapte', name: 'Beta Beta Beta- Nu Alpha Chapter', initials: 'BB', tags: 'General Student Organizations', reason: 'Beta Beta Beta (TriBeta) is an honor society for students, particularly undergraduates, dedicated to improving the understanding and appreciation of biological study.' },
  { id: 'beta-gamma-sigma', name: 'Beta Gamma Sigma', initials: 'BG', tags: 'Sport Clubs', reason: 'Beta Gamma Sigma is the international honor society serving business programs accredited by AACSB International. Membership is the highest recognition for a business student.' },
  { id: 'beta-theta-pi', name: 'Beta Theta Pi', initials: 'BT', tags: 'General Student Organizations', reason: 'Building Men of Principle for a Principled life. The official TechConnect profile of the Delta Mu Chapter of Beta Theta Pi at Texas Tech University.' },
  { id: 'beta-upsilon-chi', name: 'Beta Upsilon Chi', initials: 'BU', tags: 'General Student Organizations', reason: 'Beta Upsilon Chi, Brothers Under Christ, BYX is the largest Christian social fraternity in the United States. Since its founding in 1985, BYX has spread across the country.' },
  { id: 'beyond-barriers-inclusive-lear', name: 'Beyond Barriers - Inclusive Learning Advocates for Accessible Education', initials: 'BB', tags: 'General Student Organizations', reason: 'Advocating for innovative accommodations that meet the unique nature, needs, and challenges of students\' disabilities and rare illnesses to ensure equal educational access.' },
  { id: 'biotechnology-organization-for', name: 'Biotechnology Organization for Student Success', initials: 'BS', tags: 'STEM & Engineering', reason: 'We aim to promote science literacy and a comprehensive understanding of the many aspects of the field of biotechnology.' },
  { id: 'black-arts-society', name: 'Black Arts Society', initials: 'BA', tags: 'Arts & Media', reason: 'Our mission is to create a supportive community for talented minority students in the arts, offering resources, mentorship, and opportunities to help them grow and develop their unique skills.' },
  { id: 'black-business-student-associa', name: 'Black Business Student Association', initials: 'BB', tags: 'Business', reason: 'BBSA is organized to meet the needs of African American students and all other ethnicities as they relate to business, networking with professionals, students, and the community.' },
  { id: 'black-graduate-student-associa', name: 'Black Graduate Student Association', initials: 'BG', tags: 'General Student Organizations', reason: 'Our purpose is to prepare future leaders for personal and professional success and to promote financial, social, spiritual and cultural resources.' },
  { id: 'black-law-students-association', name: 'Black Law Students Association', initials: 'BL', tags: 'Law', reason: 'As a local chapter of the NBLSA, the Texas Tech BLSA has historically been committed to identifying and articulating the needs of African American and minority law students.' },
  { id: 'black-student-association', name: 'Black Student Association', initials: 'BL', tags: 'Cultural & Identity', reason: 'The Black Student Association (BSA) values the diversity and distinctiveness of the black undergraduate community at Texas Tech University.' },
  { id: 'block-bridle', name: 'Block & Bridle', initials: 'BB', tags: 'General Student Organizations', reason: 'We are an academic organization that is based out of the Animal and Food Sciences Department and participate in many community service events.' },
  { id: 'bookmarked-book-club', name: 'Bookmarked Book Club', initials: 'BB', tags: 'General Student Organizations', reason: 'We aim to provide a space for members to cultivate their knowledge and affection for literature in a safe and respectful space where everyone\'s opinion is heard.' },
  { id: 'chaarg', name: 'CHAARG', initials: 'CH', tags: 'General Student Organizations', reason: 'Changing Health Attitudes and Actions to Recreate Girls, CHAARG, was founded on the belief that working out should be exciting and accessible.' },
  { id: 'ciser-scholar-service-organiza', name: 'CISER Scholar Service Organization', initials: 'CS', tags: 'Service & Philanthropy', reason: 'CISER SSO encourages and enables the integration of science education and research at all educational levels and expands educational opportunities for undergraduate students in STEM fields.' },
  { id: 'campus-crusade-for-christ', name: 'Campus Crusade for Christ', initials: 'CC', tags: 'Faith & Religious Life', reason: 'We are a caring community passionate about connecting people to Jesus. Cru exists at Texas Tech to help clear up any misconceptions about who Christ is and help students grow in their relationship with God.' },
  { id: 'cancer-advocacy-and-research-i', name: 'Cancer Advocacy and Research in Biological Sciences', initials: 'CA', tags: 'STEM & Engineering', reason: 'The intended purpose of this organization is to perpetuate awareness/knowledge of oncology through education on the complex mechanisms behind cancer biology, treatment, and diagnostics.' },
  { id: 'canterbury-episcopal-campus-mi', name: 'Canterbury Episcopal Campus Ministry', initials: 'CE', tags: 'Faith & Religious Life', reason: 'Canterbury is a supportive and inclusive community of faith for the students at Texas Tech who believes in social justice, sacramental worship, spiritual growth, and open-minded discussions.' },
  { id: 'caribbean-student-association', name: 'Caribbean Student Association', initials: 'CA', tags: 'Cultural & Identity', reason: 'CSA allows Caribbean and non-Caribbean students to have a safe space here at Texas Tech to interact, learn, and for the betterment of student life and the Lubbock community.' },
  { id: 'catholic-student-association', name: 'Catholic Student Association', initials: 'CA', tags: 'Faith & Religious Life', reason: 'The Catholic Student Association, CSA, is open to anyone who wants to grow in their faith while enjoying the fellowship of others, hosting hundreds of Catholic based events throughout the year.' },
  { id: 'chabad-jewish-student-group', name: 'Chabad Jewish Student Group', initials: 'CJ', tags: 'Faith & Religious Life', reason: 'Your Jewish home away from home. Join Chabad for social events, cultural traditions, and a warm, welcoming community.' },
  { id: 'chemical-engineering-graduate-', name: 'Chemical Engineering Graduate Student Association', initials: 'CE', tags: 'STEM & Engineering', reason: 'ChEGSA promotes academic and social engagement among Texas Tech\'s chemical engineering graduate students, creating opportunities for collaborative research.' },
  { id: 'chemistry-graduate-student-org', name: 'Chemistry Graduate Student Organization', initials: 'CG', tags: 'STEM & Engineering', reason: 'CGSO is a community of chemistry and biochemistry graduate students, aiming to create a welcoming atmosphere for incoming graduate students.' },
  { id: 'chi-alpha-christian-fellowship', name: 'Chi Alpha Christian Fellowship', initials: 'CA', tags: 'Faith & Religious Life', reason: 'Chi Alpha is a gathering of Christian college students who meet during the week for worship, teaching and fellowship.' },
  { id: 'chi-epsilon', name: 'Chi Epsilon', initials: 'CE', tags: 'General Student Organizations', reason: 'We are dedicated to the purpose of maintaining and promoting the status of civil engineering as an ideal profession, recognizing fundamental characteristics of successful civil engineers.' },
  { id: 'chi-omega', name: 'Chi Omega', initials: 'CO', tags: 'General Student Organizations', reason: 'Founded on April 5, 1895, Chi Omega Fraternity has continued to flourish as the largest and most prominent women\'s fraternal organization in the nation.' },
  { id: 'chi-psi-fraternity', name: 'Chi Psi Fraternity', initials: 'CP', tags: 'Fraternities & Sororities', reason: 'Founded in 1841, Chi Psi offers undergraduate men the chance to pursue excellence in intellectual, moral, and social life.' },
  { id: 'chi-rho', name: 'Chi Rho', initials: 'CR', tags: 'General Student Organizations', reason: 'The purpose of this Fraternity shall be to unite college men under the bonds of Catholicism, provide service to the university, and cultivate the spiritual development of our members.' },
  { id: 'chi-sigma-iota', name: 'Chi Sigma Iota', initials: 'CS', tags: 'General Student Organizations', reason: 'The purpose of the Society is to promote scholarship, research, professionalism, and excellence in counseling, and to recognize high attainment in academic and clinical excellence.' },
  { id: 'children-s-health-and-medical-', name: 'Children\'s Health and Medical Program', initials: 'CS', tags: 'Health & Pre-Professional', reason: 'CHAMP is a student-led outreach club that inspires 4th–7th graders through fun, hands-on sessions in science, health, and medicine!' },
  { id: 'christian-legal-society', name: 'Christian Legal Society', initials: 'CL', tags: 'Law', reason: 'The primary purpose of CLS is to offer opportunities for Christian student fellowship while attending law school, aspiring to serve the law school through service and charitable activities.' },
  { id: 'christian-veterinary-fellowshi', name: 'Christian Veterinary Fellowship', initials: 'CV', tags: 'Faith & Religious Life', reason: 'As veterinary students, our goal is to establish a culture of God\'s love by serving our school, university, community, nation, and world through community service and worship.' },
  { id: 'christians-at-tech', name: 'Christians At Tech', initials: 'CH', tags: 'Faith & Religious Life', reason: 'Christians at Tech has been a student-led faith community on a mission to know Jesus, follow Him, and share His love across campus. We\'re more than a club—we\'re a family.' },
  { id: 'clay-club', name: 'Clay Club', initials: 'CL', tags: 'General Student Organizations', reason: 'Clay Club: Facilitating Community Involvement and Student Learning Opportunities Pertaining to Ceramics.' },
  { id: 'clinical-psychology-graduate-s', name: 'Clinical Psychology Graduate Student Council', initials: 'CP', tags: 'Health & Pre-Professional', reason: 'This organization exists to provide support to graduate students in the clinical psychology program through communication between students and faculty and professional activities.' },
  { id: 'coalition-of-healthcare-studen', name: 'Coalition of Healthcare Students', initials: 'CH', tags: 'Health & Pre-Professional', reason: 'The Coalition of Healthcare Students (CHS) welcomes all future healthcare leaders, offering mentorship, volunteering, shadowing, and community to help members grow, connect, and serve.' },
  { id: 'codepath-org', name: 'CodePath.org', initials: 'CO', tags: 'General Student Organizations', reason: 'College courses only prepare you so much for the real world. Get the technical training, career guidance, mentors, and community you need to navigate the tech industry, at no cost.' },
  { id: 'codename-raider', name: 'Codename: Raider', initials: 'CR', tags: 'General Student Organizations', reason: 'The Codename: Raider Club is a Texas Tech University organization made up of driven Chemical Engineering students who are willing to share, teach, and encourage others in computational thinking.' },
  { id: 'collective-action', name: 'Collective Action', initials: 'CA', tags: 'General Student Organizations', reason: 'Collective Action aims to expand arts in the community through dance improvisation, providing a communal experience of dance expression and social dance open to all willing to move.' },
  { id: 'college-panhellenic', name: 'College Panhellenic', initials: 'CP', tags: 'General Student Organizations', reason: 'The Panhellenic Council is the governing body over the twelve NPC sororities present at Texas Tech University.' },
  { id: 'college-of-arts-sciences-stude', name: 'College of Arts & Sciences Student Ambassadors', initials: 'CA', tags: 'STEM & Engineering', reason: 'The College of Arts & Sciences Student Ambassador Organization is a group of diverse, high-achieving Arts & Sciences students who provide service to Texas Tech and the surrounding community.' },
  { id: 'college-of-health-and-human-sc', name: 'College of Health and Human Sciences Ambassadors', initials: 'CH', tags: 'STEM & Engineering', reason: 'Student Recruitment Organization that helps the Recruitment Coordinator of the College of Health and Human Sciences recruit outstanding students to our college.' },
  { id: 'college-of-health-and-human-sc-2', name: 'College of Health and Human Sciences Society of Future Clinicians', initials: 'CH', tags: 'STEM & Engineering', reason: 'The purpose shall be to support and develop future healthcare professionals by fostering academic excellence, community engagement, and pathways that improve the human condition.' },
  { id: 'college-of-human-sciences-dean', name: 'College of Human Sciences Dean\'s Leadership Council (DLC)', initials: 'CH', tags: 'STEM & Engineering', reason: 'Dean\'s Leadership Council for COHS.' },
  { id: 'college-of-media-communication', name: 'College of Media & Communication Graduate Student Society', initials: 'CM', tags: 'Arts & Media', reason: 'The purpose of this organization is to promote academic growth and social bonding among COMC graduate students both inside and outside of the classroom.' },
  { id: 'collegiate-cattlemen-s-associa', name: 'Collegiate Cattlemen\'s Association', initials: 'CC', tags: 'General Student Organizations', reason: 'The purpose of CCA is to promote the beef cattle industry by providing students with supplemental education on issues in the industry and equipping them with networking opportunities.' },
  { id: 'colorstack', name: 'ColorStack', initials: 'CO', tags: 'General Student Organizations', reason: 'ColorStack to Texas Tech University is an organization cultivating the strongest cross-campus community of its kind to deliver community building, academic support, and career development.' },
  { id: 'communication-studies-society', name: 'Communication Studies Society', initials: 'CS', tags: 'General Student Organizations', reason: 'The Communication Studies Society\'s mission is to give members a clear understanding of the communication field by providing networking opportunities with peers and professionals.' },
  { id: 'counseling-council', name: 'Counseling Council', initials: 'CO', tags: 'Health & Pre-Professional', reason: 'To serve as an advocate and provide education for psychology students and faculty department-wide, to fund professional opportunities, and to promote the reputation of Texas Tech University.' },
  { id: 'criminal-law-association', name: 'Criminal Law Association', initials: 'CL', tags: 'Law', reason: 'The Criminal Law Association aims to provide all students with the opportunity to explore the criminal law system through academic projects, networking events, and guest speakers.' },
  { id: 'criminology-club', name: 'Criminology Club', initials: 'CR', tags: 'General Student Organizations', reason: 'Build, develop, and strengthen the character of our members. Encourage the study of Sociology/Criminology and help future opportunities for post graduation professions.' },
  { id: 'cyber-raiders', name: 'Cyber Raiders', initials: 'CR', tags: 'General Student Organizations', reason: 'The purpose of Cyber Raiders is to provide a platform for students to study, practice, and enhance their cybersecurity skills through workshops, group projects, and competitions.' },
  { id: 'c-firo-enlace-hispano-cultural', name: 'Céfiro: Enlace Hispano, Cultural y Literario', initials: 'CF', tags: 'General Student Organizations', reason: 'Céfiro: Enlace Hispano, Cultural y Literario is a student organization and journal that serves as a cultural, linguistic and professional network for graduate students of Spanish and Portuguese.' },
  { id: 'daily-toreador', name: 'Daily Toreador', initials: 'DT', tags: 'General Student Organizations', reason: 'First issued in 1925, The Daily Toreador is an official student publication designated by the Board of Regents to serve as a news media for the campus community and provide media experience for students.' },
  { id: 'dancers-with-soul-hip-hop-danc', name: 'Dancers with Soul: Hip Hop Dance Team', initials: 'DW', tags: 'Arts & Media', reason: 'Dancers with Soul: Hip Hop Dance Team is for anyone who is interested in learning hip-hop dance styles, performing, and learning how to work with a team.' },
  { id: 'delight-ministries', name: 'Delight Ministries', initials: 'DM', tags: 'General Student Organizations', reason: 'Delight is a nationwide ministry that invites college women into Christ-centered community that fosters vulnerability and transforms stories.' },
  { id: 'delta-alpha-omega', name: 'Delta Alpha Omega', initials: 'DA', tags: 'General Student Organizations', reason: 'The purpose of Delta Alpha Omega Multi-Cultural Fraternity Inc. is to transform a distinct group of men on campus to better improve themselves and their surroundings.' },
  { id: 'delta-alpha-sigma-multicultura', name: 'Delta Alpha Sigma Multicultural Sorority, Inc.', initials: 'DA', tags: 'Fraternities & Sororities', reason: 'The purpose of the Delta Alpha Sigma organization is to unite Texas Tech women from various cultures, nationalities and backgrounds, promoting leadership, multiculturalism, and self-improvement.' },
  { id: 'delta-delta-delta', name: 'Delta Delta Delta', initials: 'DD', tags: 'General Student Organizations', reason: 'As Tri Deltas, we strive to live out our motto and to develop our character in every aspect of our lives, whether on campus, at home, or in the community.' },
  { id: 'delta-epsilon-psi', name: 'Delta Epsilon Psi', initials: 'DE', tags: 'General Student Organizations', reason: 'On April 19, 2008, ten determined individuals took it upon themselves to establish Delta Epsilon Psi: Mu Chapter and become leaders in the city and community of Lubbock, Texas.' },
  { id: 'delta-gamma', name: 'Delta Gamma', initials: 'DG', tags: 'Sport Clubs', reason: 'For Hope. For Strength. For Life.' },
  { id: 'delta-kappa-delta-sorority-inc', name: 'Delta Kappa Delta Sorority, Inc.', initials: 'DK', tags: 'Fraternities & Sororities', reason: 'Delta Kappa Delta Sorority, Inc. is the FIRST South Asian Interest Service Sorority, helping the community and building a sisterhood that lasts a lifetime.' },
  { id: 'delta-kappa-epsilon', name: 'Delta Kappa Epsilon', initials: 'DK', tags: 'General Student Organizations', reason: 'The Tau Gamma Chapter of Delta Kappa Epsilon will constantly and consistently seek improvement among their men. We strive to be well-rounded men, successful academically, professionally, socially, and fraternally.' },
  { id: 'delta-phi-omega-sorority-inc', name: 'Delta Phi Omega Sorority, Inc.', initials: 'DP', tags: 'Fraternities & Sororities', reason: 'Delta Phi Omega Sorority, Inc. is the nation\'s Largest, Strongest, Fastest-growing South Asian interest sorority, creating bonds based on Sisterhood, Respect, Honesty, Loyalty, and Friendship.' },
  { id: 'delta-sigma-phi', name: 'Delta Sigma Phi', initials: 'DS', tags: 'General Student Organizations', reason: 'Delta Sigma Phi -Zeta Zeta Chapter -Texas Tech University -Better Men, Better Lives.' },
  { id: 'delta-sigma-pi', name: 'Delta Sigma Pi', initials: 'DS', tags: 'General Student Organizations', reason: 'Delta Sigma Pi is a professional fraternity organized to foster the study of business in universities to encourage scholarship, social activity and the association of students.' },
  { id: 'delta-sigma-theta-eta-lambda-c', name: 'Delta Sigma Theta, Eta Lambda Chapter', initials: 'DS', tags: 'General Student Organizations', reason: 'The Eta Lambda Chapter of Delta Sigma Theta was chartered on April 17, 1970. Delta Sigma Theta Sorority, Inc. provides assistance and support through established programs.' },
  { id: 'delta-tau-delta', name: 'Delta Tau Delta', initials: 'DT', tags: 'General Student Organizations', reason: 'Founded in 1957, the Texas Tech University chapter of Delta Tau Delta has initiated over 2000 men including former Texas Tech University Chancellor Kent Hance.' },
  { id: 'democrats-for-texas', name: 'Democrats for Texas', initials: 'DE', tags: 'Political', reason: 'The purpose of Democrats for Texas is to engage, educate, and empower students at Texas Tech University to actively participate in the political process.' },
  { id: 'dirty-techsans', name: 'Dirty Techsans', initials: 'DT', tags: 'General Student Organizations', reason: 'The purpose of Dirty Techsans is to educate members about soil science and compete nation wide against other teams in soil judging competition.' },
  { id: 'double-t-locksport', name: 'Double T Locksport', initials: 'DT', tags: 'General Student Organizations', reason: 'Double T Locksport is an organization that focuses on informing students and the community of good security practices as well as providing resources for competitive and hobby lock picking.' },
  { id: 'dr-bernard-harris-pre-medical-', name: 'Dr. Bernard Harris Pre-Medical Society', initials: 'DB', tags: 'Health & Pre-Professional', reason: 'The Dr. Bernard Harris Pre-Medical Society is a pre-medical-centered organization dedicated to creating a community of students who can support each other on the journey to becoming a physician.' },
  { id: 'education-graduate-student-org', name: 'Education Graduate Student Organization', initials: 'EG', tags: 'General Student Organizations', reason: 'The Education Graduate Student Organization aims to foster communication between education graduate students, faculty, & administration and supports graduate students.' },
  { id: 'el-club-de-espa-ol', name: 'El Club de Español', initials: 'ED', tags: 'General Student Organizations', reason: 'El Club de Español is a departmental student organization that hopes to promote the Spanish language in native speakers, heritage speakers, and learners.' },
  { id: 'empire-a-cappella', name: 'Empire A Cappella', initials: 'EC', tags: 'Arts & Media', reason: 'Empire A Cappella is the all-inclusive, award-winning pop a cappella ensemble based out of Texas Tech University in Lubbock, Texas.' },
  { id: 'energy-law-interest-group', name: 'Energy Law Interest Group', initials: 'EL', tags: 'Law', reason: 'Emphasis on Oil & Gas, Electricity, Wind, and Water Law.' },
  { id: 'engineering-diplomats', name: 'Engineering Diplomats', initials: 'ED', tags: 'STEM & Engineering', reason: 'Members of the Engineering Diplomats will represent the interests and policies of the WCOE regarding international affairs, assisting in recruiting students for international programs.' },
  { id: 'environmental-law-society', name: 'Environmental Law Society', initials: 'EL', tags: 'Law', reason: 'The purpose of the Environmental Law Society is to promote discussion and learning within Texas Tech University School of Law in the areas of Environmental, Water, and Energy Law.' },
  { id: 'environmental-toxicology-stude', name: 'Environmental Toxicology Student Association', initials: 'ET', tags: 'STEM & Engineering', reason: 'The purpose of the Association is to promote camaraderie and scientific interaction among students within the Department of Environmental Toxicology.' },
  { id: 'estate-planning-and-community-', name: 'Estate Planning And Community Property Law Journal', initials: 'EP', tags: 'Law', reason: 'The purpose of the Journal is to publish, bi-annually, professional and student scholarly articles that are relevant and beneficial to practicing lawyers in the area of estate planning law.' },
  { id: 'eta-omicron-nu', name: 'Eta Omicron Nu', initials: 'EO', tags: 'General Student Organizations', reason: 'Eta Omicron Nu (HON) is the Texas Tech Honors College affiliated organization and serves as a social and community service organization.' },
  { id: 'family-law-society', name: 'Family Law Society', initials: 'FL', tags: 'Law', reason: 'The purpose of Family Law Society is to aid members of our local community while concurrently learning about family law, representing Texas Tech School of Law through client counseling.' },
  { id: 'farmhouse-fraternity', name: 'FarmHouse Fraternity', initials: 'FF', tags: 'Fraternities & Sororities', reason: 'The Texas Tech Chapter of FarmHouse Fraternity was founded on April 15, 1978. FarmHouse has stood out among all other fraternities by holding true to an emphasis on building the whole man.' },
  { id: 'fashion-and-media-entertainmen', name: 'Fashion and Media Entertainment', initials: 'FM', tags: 'Arts & Media', reason: 'The purpose of FAME is to allow students of all backgrounds to come together for meaningful conversations surrounding diversity in the media.' },
  { id: 'filipino-student-association', name: 'Filipino Student Association', initials: 'FI', tags: 'Cultural & Identity', reason: 'The Filipino Student Association is a cultural organization made up of students from all backgrounds that come together to experience Filipino traditions through dance performances and events.' },
  { id: 'finance-association', name: 'Finance Association', initials: 'FI', tags: 'Business', reason: 'Established in 1970, the Financial Management Association International (FMA) is a global leader in developing and disseminating knowledge about financial decision making.' },
  { id: 'first-lubbock-college-ministry', name: 'First Lubbock College Ministry', initials: 'FL', tags: 'Faith & Religious Life', reason: 'First Baptist Lubbock College Ministry is a weekly worship gathering of college students who have the desire to know God on a deeper level.' },
  { id: 'food-science-club', name: 'Food Science Club', initials: 'FS', tags: 'STEM & Engineering', reason: 'The Food Science Club is a group of students with an interest in the field of Food Science, open to all majors, gathering to discuss innovations and host guest speakers.' },
  { id: 'forensic-science-society', name: 'Forensic Science Society', initials: 'FS', tags: 'STEM & Engineering', reason: 'Provide interested students with an opportunity to learn about the fields of forensic science and establish relationships between students, alumni, and other professionals.' },
  { id: 'foundation-retreat', name: 'Foundation Retreat', initials: 'FR', tags: 'General Student Organizations', reason: 'Foundation Retreat is a 4 day, Christ-centered camp for incoming freshman and transfer students to Lubbock Texas, creating lasting friendships.' },
  { id: 'friendly-raiders-for-education', name: 'Friendly Raiders for Education Equity', initials: 'FR', tags: 'General Student Organizations', reason: 'The purpose of our organization is to bring together Texas Tech students who volunteer as tutors/mentors for underprivileged students in our community.' },
  { id: 'friends-of-m-decins-sans-front', name: 'Friends of Médecins Sans Frontières', initials: 'FM', tags: 'General Student Organizations', reason: 'Friends of Médecins Sans Frontières is a registered chapter of the Doctors Without Borders (DWB), raising awareness and money for the medical work that DWB does.' },
  { id: 'future-lawyers-of-today', name: 'Future Lawyers of Today', initials: 'FL', tags: 'Law', reason: 'The main mission of Future Lawyers of Today is to provide students who are interested in law with opportunities to learn about the profession, compete in Mock Trial, and serve the community.' },
  { id: 'gamma-alpha-omega-sorority-inc', name: 'Gamma Alpha Omega Sorority, Inc.', initials: 'GA', tags: 'Fraternities & Sororities', reason: 'A sisterhood that provides support and encouragement for women of color in higher education, mentoring the youth, empowering women, and giving back to the community.' },
  { id: 'geography-youth-mappers', name: 'Geography & Youth Mappers', initials: 'GY', tags: 'General Student Organizations', reason: 'The purpose of the Geography and YouthMappers is to do what we can as students to advocate for our environment, and have fun doing it.' },
  { id: 'geoscience-student-society', name: 'Geoscience Student Society', initials: 'GE', tags: 'STEM & Engineering', reason: 'The Geoscience Student Society fosters connections between students interested in the geosciences, atmospheric science, and geography through fellowship, research, and service.' },
  { id: 'ghana-students-association', name: 'Ghana Students Association', initials: 'GH', tags: 'Cultural & Identity', reason: 'To promote the interest and well-being of Ghanaian students at Texas Tech University and represent their voices.' },
  { id: 'goin-band-student-association', name: 'Goin\' Band Student Association', initials: 'GB', tags: 'Arts & Media', reason: 'Being the oldest student organization on campus, we are proud to uphold the traditions of Texas Tech University while embracing an environment of innovation and creativity.' },
  { id: 'google-developer-student-club', name: 'Google Developer Student Club', initials: 'GD', tags: 'General Student Organizations', reason: 'Google Developer Groups at Texas Tech is a premier student-led technology community connecting developers, builders, and innovators through hands-on projects and professional development.' },
  { id: 'graduate-association-of-physic', name: 'Graduate Association of Physicists', initials: 'GP', tags: 'General Student Organizations', reason: 'The purposes of this organization are to seek to improve the graduate student experience in the Department of Physics & Astronomy and be a representative body for physics graduate students.' },
  { id: 'graduate-english-society', name: 'Graduate English Society', initials: 'GE', tags: 'General Student Organizations', reason: 'The Graduate English Society aims to support the graduate student community in the English Department at Texas Tech University through social gatherings and professional opportunities.' },
  { id: 'graduate-hospitality-managemen', name: 'Graduate Hospitality Management and Retail Association', initials: 'GH', tags: 'Business', reason: 'Graduate Hospitality & Retail Management Association is an organization for graduate students at TTU to help improve the Texas Tech community and create personal relationships.' },
  { id: 'graduate-nutrition-organizatio', name: 'Graduate Nutrition Organization', initials: 'GN', tags: 'Health & Pre-Professional', reason: 'The Graduate Nutrition Organization (GNO) serves as a friendly network for graduate students in the Nutritional Sciences department at Texas Tech University.' },
  { id: 'hosa-future-health-professiona', name: 'HOSA Future Health Professionals', initials: 'HF', tags: 'Health & Pre-Professional', reason: 'HOSA is TTU\'s only global student-led organization recognized by the U.S. Department of Education and the Department of Health and Human Services, empowering Pre-Health students.' },
  { id: 'hi-tech-fashion-group', name: 'Hi-Tech Fashion Group', initials: 'HF', tags: 'General Student Organizations', reason: 'Hi-Tech Fashion Group is a professional organization for all majors interested in learning about the fashion industry, hosting activities to keep fashion relevant within Texas Tech.' },
  { id: 'high-riders', name: 'High Riders', initials: 'HR', tags: 'General Student Organizations', reason: 'High Riders is a spirit organization dedicated to promoting and supporting Texas Tech women\'s athletics by upholding the principles of Spirit, Tradition, Leadership, Service, and Sisterhood.' },
  { id: 'higher-education-student-assoc', name: 'Higher Education Student Association', initials: 'HE', tags: 'General Student Organizations', reason: 'This group is for anyone interested in working within Student Affairs, providing information, networking opportunities, and job preparation skills.' },
  { id: 'hillel', name: 'Hillel', initials: 'HI', tags: 'Faith & Religious Life', reason: 'The organization\'s chapter at Texas Tech is a fun-loving group actively trying to improve the community, educate others about our Jewish heritage, and build community among our members.' },
  { id: 'hillside-college-life', name: 'Hillside College Life', initials: 'HC', tags: 'General Student Organizations', reason: 'We exist to love God and lead people in a growing relationship with Jesus Christ.' },
  { id: 'hispanic-law-student-associati', name: 'Hispanic Law Student Association', initials: 'HL', tags: 'Law', reason: 'HLSA is an academic organization open to anyone that supports the goals set in our Purpose. Our membership is not restricted to students of Hispanic descent.' },
  { id: 'hispanic-student-society', name: 'Hispanic Student Society', initials: 'HI', tags: 'Cultural & Identity', reason: 'Our purpose first and foremost is to promote Hispanic/Latin culture among the student body at Texas Tech University, the Lubbock community, and surrounding areas.' },
  { id: 'honors-association-for-aspirin', name: 'Honors Association for Aspiring Pre-health Tracks', initials: 'HA', tags: 'Health & Pre-Professional', reason: 'The Honors Association for Aspiring Pre-health Tracks (HAART) is a pre-health honor society dedicated to allowing our members to become leaders in the healthcare field.' },
  { id: 'honors-college-bayless-element', name: 'Honors College Bayless Elementary Mentoring Program', initials: 'HC', tags: 'Honor Societies', reason: 'The Bayless Board is an organization formed to support the Texas Tech Honors College in its adoption of Bayless Elementary, meeting the needs of Bayless students, staff, and administration.' },
  { id: 'horticulture-society', name: 'Horticulture Society', initials: 'HO', tags: 'Agriculture & Natural Resources', reason: 'TTU Horticulture Society: Grow plants, connect with peers, and dig into hands-on fun! All majors & grad students welcome.' },
  { id: 'human-development-and-family-s', name: 'Human Development And Family Sciences Graduate Student Association', initials: 'HD', tags: 'STEM & Engineering', reason: 'Our organization provides a forum for graduate students in the department of HDFS to socialize and provide support for one another.' },
  { id: 'human-development-and-family-s-2', name: 'Human Development and Family Sciences and Early Childhood Ambassadors', initials: 'HD', tags: 'STEM & Engineering', reason: 'The HDFS Ambassadors are a student organization comprised of HDFS, EC, and HS majors within the College of Human Sciences who help with recruitment and campus activities.' },
  { id: 'human-factors-and-ergonomics-s', name: 'Human Factors And Ergonomics Society', initials: 'HF', tags: 'General Student Organizations', reason: 'The HFES Student Chapter exists to serve the needs of the human factors undergraduate and graduate students at Texas Tech, creating networking opportunities.' },
  { id: 'icma-student-chapter-lubbock', name: 'ICMA Student Chapter Lubbock', initials: 'IC', tags: 'General Student Organizations', reason: 'The student chapter at Texas Tech University for the International County & City Management Association, connecting students to a career path in local government administration.' },
  { id: 'ideal', name: 'IDEAL', initials: 'ID', tags: 'General Student Organizations', reason: 'The goal of the Institute for the Development and Enrichment of Advanced Learners (IDEAL) is to provide curriculum based programming to challenge students in STEM and art fields.' },
  { id: 'ieee-eta-kappa-nu', name: 'IEEE Eta Kappa Nu', initials: 'IE', tags: 'General Student Organizations', reason: 'Eta Kappa Nu is a unique organization dedicated to encouraging and recognizing excellence in the electrical and computer engineering fields.' },
  { id: 'ieee-nuclear-plasma-sciences-s', name: 'IEEE Nuclear & Plasma Sciences Society', initials: 'IN', tags: 'STEM & Engineering', reason: 'The TTU NPSS engages students that are interested in Nuclear science and engineering, and plasma science and engineering, inviting national speakers on relevant technologies.' },
  { id: 'informs-student-chapter', name: 'INFORMS Student Chapter', initials: 'IC', tags: 'General Student Organizations', reason: 'Encourage interest in the field of operations research (OR) and the management sciences (MS) by providing a means of communication and educational programs.' },
  { id: 'immigration-law-association', name: 'Immigration Law Association', initials: 'IL', tags: 'Law', reason: 'We are an organization that focuses on immigration law and policy, discussing various issues and organizing events that expose and educate students on immigration law.' },
  { id: 'institute-of-electrical-and-el', name: 'Institute of Electrical and Electronics Engineers', initials: 'IE', tags: 'STEM & Engineering', reason: 'IEEE\'s core purpose is to foster technological innovation and excellence for the benefit of humanity, essential to the global technical community.' },
  { id: 'institute-of-industrial-and-sy', name: 'Institute of Industrial and Systems Engineers', initials: 'II', tags: 'STEM & Engineering', reason: 'IISE is open to all majors and students at Texas Tech University with an interest in Industrial Engineering, participating in community service and industry visits.' },
  { id: 'intellectual-property-student-', name: 'Intellectual Property Student Association', initials: 'IP', tags: 'General Student Organizations', reason: 'IPSA is a student-run organization with a focus on Intellectual Property law, promoting the field through informational presentations and assisting students pursuing IP careers.' },
  { id: 'interfraternity-council', name: 'Interfraternity Council', initials: 'IN', tags: 'Fraternities & Sororities', reason: 'Student governing body over the fraternal Greek system at Texas Tech University, meeting bi-weekly on Greek circle to discuss Greek wide events.' },
  { id: 'international-association-of-b', name: 'International Association of Business Communicators Tech Student Chapter', initials: 'IB', tags: 'Business', reason: 'The International Association of Business Communicators (IABC) is a global network of communication professionals committed to improving organizational effectiveness.' },
  { id: 'international-association-of-d', name: 'International Association of Drilling Contractors', initials: 'ID', tags: 'General Student Organizations', reason: 'The International Association of Drilling Contractors (IADC) helps students develop professionally through technical and non-technical workshops related to drilling.' },
  { id: 'international-interior-design-', name: 'International Interior Design Association', initials: 'II', tags: 'General Student Organizations', reason: 'IIDA promotes unity and interaction between the professional and scholastic degrees of interior design through knowledge and networking opportunities.' },
  { id: 'investment-management-associat', name: 'Investment Management Association', initials: 'IM', tags: 'General Student Organizations', reason: 'The Investment Management Association (IMA) is a premier group for students in investment management, offering industry insights, hands-on experiences, and networking.' },
  { id: 'iota-iota-iota', name: 'Iota Iota Iota', initials: 'II', tags: 'General Student Organizations', reason: 'Triota strives to maintain feminist values central to Women\'s Studies while encouraging members to pursue excellence in academics and fellowship.' },
  { id: 'iota-tau-alpha', name: 'Iota Tau Alpha', initials: 'IT', tags: 'General Student Organizations', reason: 'Iota Tau Alpha\'s purpose is to Promote the Trombone and Trombonists in all aspects of Performance and Practice in the Texas Tech Community.' },
  { id: 'jinxx', name: 'JINXX!', initials: 'JI', tags: 'General Student Organizations', reason: 'JINXX! is Texas Tech\'s first K-pop cover dance team. We hold dance workshops and random play dances as well as have an auditioned group of dancers who perform at various events.' },
  { id: 'japanese-student-association', name: 'Japanese Student Association', initials: 'JA', tags: 'Cultural & Identity', reason: 'The Japanese Student Association (JASA) at Texas Tech is dedicated to supporting not only students from Japan but also individuals with Japanese heritage and anyone interested in Japanese culture.' },
  { id: 'journal-of-technology-law-and-', name: 'Journal of Technology, Law, and Society', initials: 'JT', tags: 'STEM & Engineering', reason: 'The Journal of Technology, Law, and Society offers both a legal and scientific perspective on current issues concerning bioterrorism, public health and safety, and national security.' },
  { id: 'journal-of-the-energy-law-prac', name: 'Journal of the Energy Law Practitioner', initials: 'JE', tags: 'Law', reason: 'It is the goal of the Journal of Oil, Gas, & Energy Resources to provide practical legal writing discussion and address today\'s complex energy legal challenges.' },
  { id: 'joycentric-organization', name: 'JoyCentric Organization', initials: 'JO', tags: 'General Student Organizations', reason: 'JCO\'s mission is to reach out to and support all oncology patients through connecting with patients, assembling handmade gifts, hosting social events, and fundraising.' },
  { id: 'kappa-alpha-order', name: 'Kappa Alpha Order', initials: 'KA', tags: 'General Student Organizations', reason: 'Kappa Alpha Order provides a way of life significant to the development of young men, translating chivalric ideals into the mainstream of American colleges.' },
  { id: 'kappa-alpha-theta', name: 'Kappa Alpha Theta', initials: 'KA', tags: 'General Student Organizations', reason: 'Kappa Alpha Theta was founded in 1870 as the first Greek-letter fraternity for women, leading the way for women\'s groups and women in higher education.' },
  { id: 'kappa-delta-chi', name: 'Kappa Delta Chi', initials: 'KD', tags: 'General Student Organizations', reason: 'The Purpose of Kappa Delta Chi is to promote the values of Unity, Honesty, Integrity and Leadership among women at colleges and universities.' },
  { id: 'kappa-delta-sorority', name: 'Kappa Delta Sorority', initials: 'KD', tags: 'Fraternities & Sororities', reason: 'The Zeta Alpha chapter of Kappa Delta is committed to growth through lifetime learning, responsibility, engagement in social and civic interests, and altruistic service.' },
  { id: 'kappa-kappa-gamma', name: 'Kappa Kappa Gamma', initials: 'KK', tags: 'Sport Clubs', reason: 'Kappa Kappa Gamma is an organization of women, which seeks for every member throughout her life bonds of friendship, mutual support, and opportunities for self-growth.' },
  { id: 'kappa-kappa-psi', name: 'Kappa Kappa Psi', initials: 'KK', tags: 'General Student Organizations', reason: 'The Alpha Omicron Chapter of Kappa Kappa Psi was founded on March 12, 1938 by seventeen members of the Texas Tech band. Today the organization serves the band program.' },
  { id: 'kappa-sigma', name: 'Kappa Sigma', initials: 'KS', tags: 'General Student Organizations', reason: 'Kappa Sigma is focused upon the four pillars of fellowship, leadership, scholarship, and service, strictly forbidding hazing and fostering meaningful college experiences.' },
  { id: 'kinesiology-and-sport-manageme', name: 'Kinesiology and Sport Management Ambassadors', initials: 'KS', tags: 'Health & Pre-Professional', reason: 'The ambassador program works to serve the entirety of the Kinesiology & Sport Management department by maintaining communication between faculty, staff, and students.' },
  { id: 'knight-raiders', name: 'Knight Raiders', initials: 'KR', tags: 'General Student Organizations', reason: 'Our purpose is to promote chess among students, faculty, and staff at Texas Tech University System, enabling members to play chess over-the-board and over the Internet.' },
  { id: 'knights-of-architecture', name: 'Knights of Architecture', initials: 'KA', tags: 'General Student Organizations', reason: 'The Knights of Architecture is a student-run social and service organization which serves as ambassadors for the student culture of the Huckabee College of Architecture.' },
  { id: 'knowledge-empowering-you', name: 'Knowledge Empowering You', initials: 'KE', tags: 'General Student Organizations', reason: 'Knowledge Empowering You Outreach Program utilizes Texas Tech University Personal Financial Planning students to provide educational outreach and financial counseling in the Lubbock community.' },
  { id: 'korean-student-association', name: 'Korean Student Association', initials: 'KO', tags: 'Cultural & Identity', reason: 'The Korean Student Association is a social organization for Korean students and any students who are interested in Korean culture.' },
  { id: 'lambda-chi-alpha', name: 'Lambda Chi Alpha', initials: 'LC', tags: 'General Student Organizations', reason: 'Lambda Chi Alpha is a social fraternity based on timeless precepts, cultivating a progressive environment that will allow men to become better men.' },
  { id: 'lambda-delta-psi-sorority-inc', name: 'Lambda Delta Psi Sorority, Inc.', initials: 'LD', tags: 'Fraternities & Sororities', reason: 'Our purpose is to cultivate a sisterhood of distinguished women through friendship and service while maintaining high moral and academic standards.' },
  { id: 'latino-medical-student-associa', name: 'Latino Medical Student Association Plus', initials: 'LM', tags: 'Cultural & Identity', reason: 'LMSA+ is a student group representing premedical and health professions students from Texas Tech University in supporting the Latinx community.' },
  { id: 'latter-day-saint-student-assoc', name: 'Latter-Day Saint Student Association', initials: 'LD', tags: 'Faith & Religious Life', reason: 'LDS Student Association is an organization affiliated with The Church of Jesus Christ of Latter-day Saints which offers Latter-day Saint university students community.' },
  { id: 'live-oak-college-ministry', name: 'Live Oak College Ministry', initials: 'LO', tags: 'Faith & Religious Life', reason: 'Live Oak College Ministry exists to connect college-aged young adults to both Christ and community.' },
  { id: 'livestock-judging-team', name: 'Livestock Judging Team', initials: 'LJ', tags: 'Agriculture & Natural Resources', reason: 'The livestock judging team travels around the United States throughout the year to compete at various contests against other universities.' },
  { id: 'llano-estacado-student-chapter', name: 'Llano Estacado Student Chapter Of The Society Of Environmental Toxicology And Chemistry', initials: 'LE', tags: 'STEM & Engineering', reason: 'The regional chapter (Llano Estacado) of SETAC is dedicated to advancing environmental science and science-informed decision-making through collaboration and education.' },
  { id: 'lubbock-rotaract-club', name: 'Lubbock Rotaract Club', initials: 'LR', tags: 'General Student Organizations', reason: 'Rotaract\'s mission is to provide an opportunity for men and women to enhance the knowledge and skills that will assist them in personal development.' },
  { id: 'lutheran-student-fellowship', name: 'Lutheran Student Fellowship', initials: 'LF', tags: 'Faith & Religious Life', reason: 'The Lutheran Student Fellowship (LSF) is a family of college students seizing everyday opportunities to share the love of Christ.' },
  { id: 'mantra-meditation', name: 'Mantra Meditation', initials: 'MM', tags: 'General Student Organizations', reason: 'Mantra Meditation promotes a healthy and conscious lifestyle among all in and around campus and brings together Texas Tech University students interested in mantra-based meditation.' },
  { id: 'matador-collegiate-farm-bureau', name: 'Matador Collegiate Farm Bureau', initials: 'MC', tags: 'Agriculture & Natural Resources', reason: 'The purpose of the Organization is to serve as a connection between current industry professionals and agricultural students, interacting with legislators at the state and national level.' },
  { id: 'matador-mma', name: 'Matador MMA', initials: 'MM', tags: 'Sport Clubs', reason: 'The purpose of this organization is to provide a safe, growth-oriented environment for the practice of Brazilian Jiu-Jitsu and Mixed Martial Arts at Texas Tech University.' },
  { id: 'matador-powerlifting-team', name: 'Matador Powerlifting Team', initials: 'MP', tags: 'Sport Clubs', reason: 'The MPT is a collegiate powerlifting club organized through Texas Tech University, aiding each team member into reaching their full potential in the sport of powerlifting.' },
  { id: 'meat-animal-evaluation-team', name: 'Meat Animal Evaluation Team', initials: 'MA', tags: 'Agriculture & Natural Resources', reason: 'The meat animal evaluation team travels around the United States throughout the year to compete at various contests against other universities.' },
  { id: 'meat-judging-team', name: 'Meat Judging Team', initials: 'MJ', tags: 'Agriculture & Natural Resources', reason: 'The Meat Judging Team represents the University by traveling to contests throughout the year, evaluating beef, pork, and lamb based on quality and yield.' },
  { id: 'meat-science-academic-quiz-bow', name: 'Meat Science Academic Quiz Bowl Team', initials: 'MS', tags: 'STEM & Engineering', reason: 'The purpose of the Meat Science Academic Quiz Bowl Team is to compete at the national level demonstrating knowledge and comprehension of Meat and Food Science.' },
  { id: 'meat-science-association', name: 'Meat Science Association', initials: 'MS', tags: 'STEM & Engineering', reason: 'The purpose of the Meat Science Association is to serve and support the meat science program, promoting it through attending national meetings and community service.' },
  { id: 'medlife', name: 'MedLife', initials: 'ME', tags: 'General Student Organizations', reason: 'Building a worldwide Movement empowering the poor in their fight for equal access to healthcare, education, and safe homes through listening, collaborating, and prioritizing sustainability.' },
  { id: 'medical-and-dental-global-brig', name: 'Medical and Dental Global Brigades', initials: 'MD', tags: 'Health & Pre-Professional', reason: 'Students will spend 7-9 days in either Honduras, Panama, Nicaragua, Greece, or Ghana providing healthcare for under-resourced communities.' },
  { id: 'mediterranean-student-society', name: 'Mediterranean Student Society', initials: 'ME', tags: 'General Student Organizations', reason: 'Our purpose is to promote Mediterranean culture to the student body at Texas Tech University, Lubbock, and neighboring regions through academic enrichment and social gatherings.' },
  { id: 'metals-club', name: 'Metals Club', initials: 'ME', tags: 'General Student Organizations', reason: 'The purpose of this club is to promote the education and interest in jewelry design and metalsmithing among Texas Tech University students.' },
  { id: 'military-veteran-programs', name: 'Military & Veteran Programs', initials: 'MV', tags: 'General Student Organizations', reason: 'Military & Veterans Programs assists veterans, service members, and their families in achieving academic, personal, and professional success.' },
  { id: 'mindmatters', name: 'MindMatters', initials: 'MI', tags: 'General Student Organizations', reason: 'Our mission is to spread adolescent mental health awareness among the Lubbock community.' },
  { id: 'minorities-in-agriculture-natu', name: 'Minorities in Agriculture, Natural Resources and Related Sciences', initials: 'MA', tags: 'STEM & Engineering', reason: 'MANRRS promotes academic and professional advancement by empowering minorities in agriculture, natural resources, and related sciences.' },
  { id: 'minorities-in-pre-law-alliance', name: 'Minorities in Pre Law Alliance', initials: 'MP', tags: 'Law', reason: 'Foster a place where minority students wanting to pursue a career in pre-law can access resources through professional networking opportunities related to the law.' },
  { id: 'minority-association-of-pre-he', name: 'Minority Association of Pre-Health Students', initials: 'MP', tags: 'Health & Pre-Professional', reason: 'The Minority Association of Pre-medical Students (MAPS) is a network of pre-health students aiming to diversify the field of medicine.' },
  { id: 'miracle-pennies-college-editio', name: 'Miracle Pennies College Edition', initials: 'MP', tags: 'General Student Organizations', reason: 'We aim to maintain an inclusive and diverse team of student leaders united in their efforts to change KIDS\' health and change the future.' },
  { id: 'missionary-baptist-student-fel', name: 'Missionary Baptist Student Fellowship', initials: 'MB', tags: 'Faith & Religious Life', reason: 'To promote the Gospel of Christ on campus and students\' spiritual advancement through Biblical knowledge according to Missionary Baptist doctrines.' },
  { id: 'model-united-nations', name: 'Model United Nations', initials: 'MU', tags: 'General Student Organizations', reason: 'We are an organization of global-minded students who debate solutions to international problems in simulations that model the United Nations.' },
  { id: 'mortar-board', name: 'Mortar Board', initials: 'MB', tags: 'Honor Societies', reason: 'The Forum Chapter of Mortar Board is an organization comprised of the top seniors on campus based on the 3 pillars of Mortar Board Nationals: Leadership, service and scholarship.' },
  { id: 'mu-epsilon-kappa-anime', name: 'Mu Epsilon Kappa Anime', initials: 'ME', tags: 'General Student Organizations', reason: 'Mu Epsilon Kappa Anime (aka "MEKA") is a Japanese animation fan club at Texas Tech University, providing a safe environment where anime fans can watch and discuss anime.' },
  { id: 'multicultural-greek-council', name: 'Multicultural Greek Council', initials: 'MG', tags: 'Cultural & Identity', reason: 'The Multicultural Greek Council houses 13 multicultural fraternities and sororities, preparing members to be ethical leaders for a diverse and globally competitive workforce.' },
  { id: 'multicultural-pre-dental-assoc', name: 'Multicultural Pre-Dental Association', initials: 'MP', tags: 'Cultural & Identity', reason: 'Multicultural Pre-Dental Association is aiming to reach all students at Texas Tech University that aspire to work in the Dental Medicine field.' },
  { id: 'multicultural-student-business', name: 'Multicultural Student Business Association', initials: 'MB', tags: 'Business', reason: 'The Multicultural Student Business Association (MSBA) serves to create a diverse community of leaders within the Rawls College of Business.' },
  { id: 'museum-heritage-student-associ', name: 'Museum Heritage Student Association', initials: 'MH', tags: 'General Student Organizations', reason: 'MHSA promotes the Museum of Texas Tech University and the Heritage and Museum Sciences Department to local, state, national, and international museum communities.' },
  { id: 'muslim-student-association', name: 'Muslim Student Association', initials: 'MU', tags: 'Faith & Religious Life', reason: 'MSA is a religious organization dedicated to promoting the Islamic cultural heritage, increasing public awareness about Muslims and Islam.' },
  { id: 'naacp-tech', name: 'NAACP @ Tech', initials: 'NA', tags: 'Cultural & Identity', reason: 'The NAACP of Texas Tech University is one of the many branches of the Youth & College division, educating and promoting political awareness surrounding issues facing minorities.' },
  { id: 'national-association-of-teache', name: 'National Association of Teachers of Singing at Tech', initials: 'NT', tags: 'General Student Organizations', reason: 'National Association of Teachers of Singing at Tech is a student group that meets several times a semester to promote healthy singing and the teaching of singing.' },
  { id: 'national-marrow-donation-progr', name: 'National Marrow Donation Program', initials: 'NM', tags: 'General Student Organizations', reason: 'NMDP at Texas Tech works to advocate for people in need of treatment for a blood cancer or disease by trying to get students to be potential donors.' },
  { id: 'national-organization-of-minor', name: 'National Organization of Minority Architect Students Lubbock Chapter', initials: 'NM', tags: 'General Student Organizations', reason: 'This organization is in affiliation with NOMA, a professional organization for Texas Tech architecture students.' },
  { id: 'national-pan-hellenic-council', name: 'National Pan-Hellenic Council', initials: 'NP', tags: 'General Student Organizations', reason: 'The National Pan-Hellenic Councils consists of nine historically African-American Fraternities and Sororities.' },
  { id: 'national-society-of-black-engi', name: 'National Society of Black Engineers', initials: 'NB', tags: 'STEM & Engineering', reason: 'The mission of the National Society of Black Engineers is to increase the number of culturally responsible Black engineers who excel academically and succeed professionally.' },
  { id: 'navigators', name: 'Navigators', initials: 'NA', tags: 'Faith & Religious Life', reason: 'We are an interdenominational campus ministry that seeks to know Jesus Christ and to make Him known through training sessions and small group discipleship.' },
  { id: 'nepal-students-association', name: 'Nepal Students Association', initials: 'NE', tags: 'Cultural & Identity', reason: 'The Nepal Students Association at Texas Tech supports Nepali students, celebrates Nepal\'s culture and heritage, and builds an inclusive community.' },
  { id: 'network-of-enlightened-women', name: 'Network of Enlightened Women', initials: 'NE', tags: 'General Student Organizations', reason: 'The Network of enlightened Women (NeW) is dedicated to fostering the education and leadership skills of conservative university women.' },
  { id: 'nigerian-students-association', name: 'Nigerian Students Association', initials: 'NI', tags: 'Cultural & Identity', reason: 'The NSA is a community of TTU students of Nigerian origin, aiming to strengthen community relations and promote Nigeria\'s socio-cultural heritage.' },
  { id: 'no-mind-left-behind', name: 'No Mind Left Behind', initials: 'NM', tags: 'General Student Organizations', reason: 'No Mind Left Behind is a mental health organization that has the goal of providing and promoting resources, awareness, community, and service.' },
  { id: 'non-traditional-law-student-as', name: 'Non-Traditional Law Student Association', initials: 'NT', tags: 'Law', reason: 'An organization for non-traditional law students at TTU School of Law to create a supportive environment for students who have lived life between their undergraduate degree and law school.' },
  { id: 'outlaw', name: 'OUTlaw', initials: 'OU', tags: 'General Student Organizations', reason: 'The purpose of OUTLaw is to build awareness of legal issues surrounding sexual orientation and gender identity, promoting social equality and fostering an inclusive community.' },
  { id: 'omega-delta-phi-fraternity-inc', name: 'Omega Delta Phi Fraternity, Inc.', initials: 'OD', tags: 'Fraternities & Sororities', reason: 'A service/social fraternity founded here at Texas Tech in 1987, a multicultural fraternity with the belief that anyone can be part of this brotherhood regardless of race or beliefs.' },
  { id: 'organization-of-women-law-stud', name: 'Organization Of Women Law Students', initials: 'WL', tags: 'Law', reason: 'OWLS promotes women in the legal field while giving back to the law school and Lubbock community, providing networking opportunities.' },
  { id: 'orthodox-christian-fellowship', name: 'Orthodox Christian Fellowship', initials: 'OC', tags: 'Faith & Religious Life', reason: 'The Texas Tech University OCF is a student led organization dedicated to building pan-orthodox community and friendships through interaction with other Eastern Orthodox college students.' },
  { id: 'peers-against-tobacco', name: 'Peers Against Tobacco', initials: 'PA', tags: 'General Student Organizations', reason: 'To serve the West Texas community through impactful service initiatives, with particular focus on tobacco and substance use prevention and overdose education.' },
  { id: 'personal-financial-planning-as', name: 'Personal Financial Planning Association', initials: 'PF', tags: 'General Student Organizations', reason: 'The mission of this organization is to provide opportunities for professional development through meaningful student involvement in the division of financial planning.' },
  { id: 'pets-are-worth-saving', name: 'Pets Are Worth Saving', initials: 'PA', tags: 'General Student Organizations', reason: 'The purpose of the Pets Are Worth Saving Club is to promote the caring of pets and adoption within the Lubbock community.' },
  { id: 'phi-alpha-delta-pre-law', name: 'Phi Alpha Delta Pre-Law', initials: 'PA', tags: 'Health & Pre-Professional', reason: 'The purpose of Phi Alpha Delta Pre-Law Fraternity, International is to assist its members in making a well informed decision on attending law school.' },
  { id: 'phi-alpha-theta-zeta-iota-chap', name: 'Phi Alpha Theta: Zeta-Iota Chapter', initials: 'PA', tags: 'General Student Organizations', reason: 'Phi Alpha Theta is a historical honor society dedicated to the pursuit of history, service, and honor.' },
  { id: 'phi-delta-theta', name: 'Phi Delta Theta', initials: 'PD', tags: 'General Student Organizations', reason: 'Social Fraternity based on Friendship, Sound Learning, and Rectitude.' },
  { id: 'phi-gamma-delta', name: 'Phi Gamma Delta', initials: 'PG', tags: 'Sport Clubs', reason: 'A social Fraternity based on the principals of friendship, knowledge, service, morality, and excellence, shaping college men into inspirational leaders.' },
  { id: 'phi-kappa-psi', name: 'Phi Kappa Psi', initials: 'PK', tags: 'General Student Organizations', reason: 'The Phi Kappa Psi Fraternity is an association of men of integrity who strive to develop the individual in his intellect, community involvement, and faith.' },
  { id: 'phi-kappa-tau', name: 'Phi Kappa Tau', initials: 'PK', tags: 'General Student Organizations', reason: 'We are a group of guys who are interested in a fraternal experience that is centered in self development and expression.' },
  { id: 'phi-mu-alpha-sinfonia-fraterni', name: 'Phi Mu Alpha Sinfonia Fraternity', initials: 'PM', tags: 'Fraternities & Sororities', reason: 'The Object of this Fraternity shall be for the development of the best and truest fraternal spirit and the advancement of music in America.' },
  { id: 'phi-upsilon-omicron', name: 'Phi Upsilon Omicron', initials: 'PU', tags: 'General Student Organizations', reason: 'Phi Upsilon Omicron is an honor society and service organization for outstanding scholars and leaders representing all majors within the College of Human Sciences.' },
  { id: 'philosophy-graduate-student-as', name: 'Philosophy Graduate Student Association', initials: 'PG', tags: 'General Student Organizations', reason: 'The purpose of the Philosophy Graduate Student Association is to promote a general interest in philosophy on the Texas Tech Campus.' },
  { id: 'physician-assistant-student-or', name: 'Physician Assistant Student Organization', initials: 'PA', tags: 'General Student Organizations', reason: 'The Physician Assistant Student Organization provides volunteer and networking opportunities, community engagement, application support, and mentorship for PA school hopefuls.' },
  { id: 'pi-beta-phi', name: 'Pi Beta Phi', initials: 'PB', tags: 'General Student Organizations', reason: 'The mission of Pi Beta Phi Fraternity for Women is to promote friendship, develop women of intellect and integrity, and enrich lives through community service.' },
  { id: 'pi-kappa-alpha', name: 'Pi Kappa Alpha', initials: 'PK', tags: 'General Student Organizations', reason: 'Pi Kappa Alpha is dedicated to developing men of integrity, intellect, and high moral character and fostering a truly lifelong fraternal experience.' },
  { id: 'pi-kappa-phi-fraternity', name: 'Pi Kappa Phi Fraternity', initials: 'PK', tags: 'Fraternities & Sororities', reason: 'To create an uncommon and lifelong brotherhood that develops leaders and encourages service to others for the betterment of our communities.' },
  { id: 'pi-tau-sigma', name: 'Pi Tau Sigma', initials: 'PT', tags: 'General Student Organizations', reason: 'Pi Tau Sigma is the international honor society for Mechanical Engineers.' },
  { id: 'plant-and-soil-science-graduat', name: 'Plant and Soil Science Graduate Council', initials: 'PS', tags: 'STEM & Engineering', reason: 'The purpose of this organization is to represent Plant and Soil Science graduate students and address their interests and concerns.' },
  { id: 'pre-athletic-training-club', name: 'Pre-Athletic Training Club', initials: 'PA', tags: 'General Student Organizations', reason: 'The purpose of the Pre-Athletic Training Club is to give students who intend to pursue Athletic Training the opportunity to network and prepare for graduate school applications.' },
  { id: 'pre-dental-society', name: 'Pre-Dental Society', initials: 'PD', tags: 'Health & Pre-Professional', reason: 'The mission of the Texas Tech Pre-Dental Society is to increase the number of students matriculated into dental school through hands-on dental experience and networking.' },
  { id: 'pre-nursing-association', name: 'Pre-Nursing Association', initials: 'PN', tags: 'Health & Pre-Professional', reason: 'An organization designated for students interested in the nursing field, a community where you can meet people and make new friends on your nursing journey.' },
  { id: 'pre-optometry-professional-soc', name: 'Pre-Optometry Professional Society', initials: 'PO', tags: 'General Student Organizations', reason: 'The TTU Pre-Optometry Professional Society welcomes students interested in the growing field of optometry, open to all Texas Tech students.' },
  { id: 'pre-physical-therapy-club', name: 'Pre-Physical Therapy Club', initials: 'PP', tags: 'Health & Pre-Professional', reason: 'This is a fun group of students with similar interests in physical therapy, hosting meetings with guest speakers from local physical therapy clinics and PT schools.' },
  { id: 'president-s-select', name: 'President\'s Select', initials: 'PS', tags: 'General Student Organizations', reason: 'President\'s Select is a group of Texas Tech University student ambassadors chosen specifically to serve Texas Tech through the Office of the President and Athletics.' },
  { id: 'presidential-lecture-and-perfo', name: 'Presidential Lecture and Performance Series', initials: 'PL', tags: 'General Student Organizations', reason: 'The Presidential Lecture & Performance Series provides engaging entertainment and learning opportunities for the Texas Tech University and Lubbock communities.' },
  { id: 'prosecution-law-association', name: 'Prosecution Law Association', initials: 'PL', tags: 'Law', reason: 'The purpose of the organization is to promote a better understanding of prosecution law and encourage future prosecutors to uphold the highest standards of ethics.' },
  { id: 'providing-the-outside-world-wi', name: 'Providing the Outside World with Empowerment and Resources', initials: 'PO', tags: 'General Student Organizations', reason: 'The mission of the POWER Committee is to provide a foundation and voice for under-represented individuals in recovery.' },
  { id: 'psi-chi-international-honor-so', name: 'Psi Chi: International Honor Society In Psychology', initials: 'PC', tags: 'Health & Pre-Professional', reason: 'Interested in a career in psychology? Join Psi Chi for exclusive access to research opportunities, graduate school workshops, and scholarships.' },
  { id: 'public-relations-student-socie', name: 'Public Relations Student Society of America', initials: 'PR', tags: 'General Student Organizations', reason: 'PRSSA is the foremost organization for students interested in public relations and communications, advocating rigorous academic standards and diversity in the profession.' },
  { id: 'rise-risk-intervention-and-saf', name: 'RISE - Risk Intervention and Safety Education', initials: 'RR', tags: 'General Student Organizations', reason: 'The Risk Intervention & Safety Education (RISE) office is the central hub for prevention and wellness at Texas Tech!' },
  { id: 'raider-aerospace-society', name: 'Raider Aerospace Society', initials: 'RA', tags: 'General Student Organizations', reason: 'Raider Aerospace Society is Texas Tech\'s premier aerospace and aeronautics organization, providing students an opportunity to explore aerospace and aviation fields.' },
  { id: 'raider-backpacking-club', name: 'Raider Backpacking Club', initials: 'RB', tags: 'General Student Organizations', reason: 'The mission of the Raider Backpacking club is to reach fellow students who have a love of the outdoors and get them outdoors with consistency.' },
  { id: 'raider-badminton-club', name: 'Raider Badminton Club', initials: 'RB', tags: 'Sport Clubs', reason: 'Raider Badminton Club is the official badminton sport club for students at Texas Tech University, welcoming beginners and advanced level members.' },
  { id: 'raider-bar-association', name: 'Raider Bar Association', initials: 'RB', tags: 'Law', reason: 'The purpose of RBA is to foster long-lasting relationships among law students, alumni, and faculty, creating an environment that allows members to network.' },
  { id: 'raider-calisthenics-club', name: 'Raider Calisthenics Club', initials: 'RC', tags: 'Sport Clubs', reason: 'The purpose of the Raider Calisthenics Club is to engage Texas Tech students in the art and discipline of calisthenics while fostering a supportive community.' },
  { id: 'raider-entrepreneurship-club', name: 'Raider Entrepreneurship Club', initials: 'RE', tags: 'Business', reason: 'The purpose of REC is to foster an entrepreneurial spirit among Texas Tech students.' },
  { id: 'raider-historical-fencing', name: 'Raider Historical Fencing', initials: 'RH', tags: 'Sport Clubs', reason: 'HEMA, or Historical European Martial Arts, focusing on the longsword, as taught by Fiore Dei Liberi.' },
  { id: 'raider-medical-screening-socie', name: 'Raider Medical Screening Society', initials: 'RM', tags: 'Health & Pre-Professional', reason: 'The primary goal of RMSS is to offer free medical screenings to detect early signs of diabetes, high cholesterol, and high blood pressure in underserved communities.' },
  { id: 'raider-power-of-paranormal', name: 'Raider Power of Paranormal', initials: 'RP', tags: 'General Student Organizations', reason: 'RPOP is a student-led organization, actively exploring the boundaries of human knowledge through alleged paranormal phenomena.' },
  { id: 'raider-precision-rifle-club', name: 'Raider Precision Rifle Club', initials: 'RP', tags: 'General Student Organizations', reason: 'No membership dues. Feel free to bring equipment to train with; equipment can be provided via rental or borrowed for club events.' },
  { id: 'raider-recycling', name: 'Raider Recycling', initials: 'RR', tags: 'Service & Philanthropy', reason: 'Raider Recycling is a club dedicated to making recycling more available and apparent at Texas Tech, engaging with campus and community.' },
  { id: 'raider-red-s-food-pantry', name: 'Raider Red\'s Food Pantry', initials: 'RR', tags: 'Service & Philanthropy', reason: 'Raider Red\'s Food Pantry provides hygiene products and limited non-perishable food to students.' },
  { id: 'raider-rhetoric-society', name: 'Raider Rhetoric Society', initials: 'RR', tags: 'General Student Organizations', reason: 'The purpose of this organization is to serve undergraduate and graduate students interested in expanding their understanding of rhetoric and rhetorical approaches to communication.' },
  { id: 'raider-riot', name: 'Raider Riot', initials: 'RR', tags: 'General Student Organizations', reason: 'The official identity of the student section for Texas Tech Athletics, one of the loudest and rowdiest student sections in the nation!' },
  { id: 'raider-sisters-for-christ', name: 'Raider Sisters for Christ', initials: 'RS', tags: 'General Student Organizations', reason: 'Raider Sisters for Christ is a Christian sorority aiming to glorify God in all aspects of life through fellowship, growth, and sisterhood.' },
  { id: 'raider-trumpet-guild', name: 'Raider Trumpet Guild', initials: 'RT', tags: 'General Student Organizations', reason: 'To promote communication among trumpet players around the world and to improve the artistic level of performance, teaching, and literature associated with the trumpet.' },
  { id: 'raider-s-knit-knot', name: 'Raider\'s Knit & Knot', initials: 'RS', tags: 'General Student Organizations', reason: 'This organization brings together Texas Tech students who share an interest in the arts in a beginner friendly environment, teaching and serving the community.' },
  { id: 'raiders-helping-others', name: 'Raiders Helping Others', initials: 'RH', tags: 'Service & Philanthropy', reason: 'A group of Texas Tech residence hall students that are dedicated to helping others through community service initiatives both on and off campus.' },
  { id: 'raiders-uncorked', name: 'Raiders Uncorked', initials: 'RU', tags: 'General Student Organizations', reason: 'Raiders Uncorked is a student organization established for the purpose of academically exploring and appreciating viticulture, enology and the wines of Texas and the world.' },
  { id: 'raiders-for-life', name: 'Raiders for Life', initials: 'RL', tags: 'General Student Organizations', reason: 'Raiders Defending Life is a student-led organization seeking to build a Culture of Life at Texas Tech University and in the Lubbock community.' },
  { id: 'raiders-for-reproductive-right', name: 'Raiders for Reproductive Rights', initials: 'RR', tags: 'General Student Organizations', reason: 'Raiders for Reproductive Rights\' purpose is to advocate for reproductive freedom, raise public awareness about reproductive health and rights.' },
  { id: 'rawls-banking-association', name: 'Rawls Banking Association', initials: 'RB', tags: 'Business', reason: 'The Rawls Banking Association is here to help students develop the skills necessary for a career in banking, providing advice and real-world experience.' },
  { id: 'rawls-college-of-business-dean', name: 'Rawls College of Business Dean\'s Student Council', initials: 'RC', tags: 'Business', reason: 'Our purpose is to provide any student at Rawls College of Business with the full university experience by serving as a connection between the Dean and students.' },
  { id: 'rawls-global-business-council', name: 'Rawls Global Business Council', initials: 'RG', tags: 'Business', reason: 'The Rawls Global Business Council is a student organization for Rawls College of Business students who have completed an international learning experience.' },
  { id: 'rawls-graduate-association', name: 'Rawls Graduate Association', initials: 'RG', tags: 'General Student Organizations', reason: 'RGA is a professional and social organization for all Rawls graduate students, hosting networking and social events.' },
  { id: 'real-estate-organization', name: 'Real Estate Organization', initials: 'RE', tags: 'Business', reason: 'The Real Estate Organization (REO) is the premier organization for students interested in investment real estate markets, analysis and professions.' },
  { id: 'red-costa-rica-female-futbol-c', name: 'Red Costa Rica Female Futbol Club', initials: 'RC', tags: 'General Student Organizations', reason: 'The purpose of this organization is to support and encourage female sports in the country and promote a healthier lifestyle through exercise.' },
  { id: 'red-costa-rica-men-s-futbol-cl', name: 'Red Costa Rica Men\'s Futbol Club', initials: 'RC', tags: 'General Student Organizations', reason: 'The purpose of the Red Costa Rica Fútbol Club is to promote soccer among students and develop teamwork, leadership, and sportsmanship.' },
  { id: 'red-dirt-racing', name: 'Red Dirt Racing', initials: 'RD', tags: 'General Student Organizations', reason: 'The purpose of Red Dirt Racing, also known as Baja SAE, is to work with a senior capstone design team and compete in the Baja SAE International collegiate design competition.' },
  { id: 'red-planet', name: 'Red PlaNet', initials: 'RP', tags: 'General Student Organizations', reason: 'Make, create, plan, design, organize, implement, improve and explore STEM projects for innovation on Earth meant to impact and investigate the space industries problems.' },
  { id: 'red-raider-racing', name: 'Red Raider Racing', initials: 'RR', tags: 'General Student Organizations', reason: 'The purpose of Formula SAE at Texas Tech is to design, fabricate, test and compete with a formula style race car in the international Formula SAE Collegiate Design Competition.' },
  { id: 'red-theatre-company', name: 'Red Theatre Company', initials: 'RT', tags: 'Arts & Media', reason: 'The purpose of our organization is to create leadership, performance, and management opportunities for students who hope to foster their skills in the theatre arts.' },
  { id: 'redeemed-christian-church-of-g', name: 'Redeemed Christian Church of God, Dominion Chapel Fellowship', initials: 'RC', tags: 'Faith & Religious Life', reason: 'The Redeemed Christian Church of God (RCCG), Dominion Chapel Fellowship is a growing fellowship in the Lubbock community spreading the gospel of Christ.' },
  { id: 'redeemer-college-ministry', name: 'Redeemer College Ministry', initials: 'RC', tags: 'Faith & Religious Life', reason: 'Redeemer College Ministry seeks to connect, equip, and mobilize students to be on mission for Jesus Christ.' },
  { id: 'reformed-university-fellowship', name: 'Reformed University Fellowship', initials: 'RF', tags: 'General Student Organizations', reason: 'We are a Christian ministry on campus seeking to foster a love for God and love for our neighbors through learning what the Bible teaches.' },
  { id: 'renewable-energy-student-assoc', name: 'Renewable Energy Student Association', initials: 'RE', tags: 'General Student Organizations', reason: 'The Renewable Energy Student Association is for students passionate about renewable energy, working closely with the renewable energy competition teams.' },
  { id: 'residence-halls-association', name: 'Residence Halls Association', initials: 'RH', tags: 'General Student Organizations', reason: 'The Residence Halls Association (RHA) serves as the voice for those students who live within the residence halls on campus, the second-largest student organization at Texas Tech.' },
  { id: 'robotics-and-advanced-tech-soc', name: 'Robotics and Advanced Tech Society', initials: 'RA', tags: 'STEM & Engineering', reason: 'Welcome to the Robotics and Advanced Tech Society. Our org provides hands on engineering experience, learning and growing while building projects.' },
  { id: 'sabre-flight-drill-team', name: 'Sabre Flight Drill Team', initials: 'SF', tags: 'General Student Organizations', reason: 'A Texas Tech University honor guard and drill team which performs color guards, saber arches, and other military ceremonies.' },
  { id: 'saddle-tramps', name: 'Saddle Tramps', initials: 'ST', tags: 'General Student Organizations', reason: 'Saddle Tramps is an all male spirit/service organization dedicated in 1936 to the betterment of Texas Tech University and the Lubbock community, celebrating its 85th anniversary.' },
  { id: 'sales-leadership-group', name: 'Sales Leadership Group', initials: 'SL', tags: 'Business', reason: 'The purpose of the Sales Leadership Group is to provide the student body interested in sales and customer relationship management with opportunities for professional development.' },
  { id: 'school-of-veterinary-medicine-', name: 'School of Veterinary Medicine Companion Animal Club', initials: 'SV', tags: 'Health & Pre-Professional', reason: 'Student led organization within the School of Veterinary Medicine dedicated towards providing educational opportunities in companion animal species.' },
  { id: 'school-of-veterinary-medicine--2', name: 'School of Veterinary Medicine Graduate Student Association', initials: 'SV', tags: 'Health & Pre-Professional', reason: 'The Tech SVM-GSA is a student organization that aims to promote professional and social development of our members and the concept of One Health.' },
  { id: 'script-raiders', name: 'Script Raiders', initials: 'SR', tags: 'General Student Organizations', reason: 'Script Raiders focuses on giving script writers a casual space to present developing, original work among peers, and to receive constructive feedback.' },
  { id: 'sigma-alpha', name: 'Sigma Alpha', initials: 'SA', tags: 'General Student Organizations', reason: 'Sigma Alpha is a professional agricultural sorority that promotes scholarship, leadership, service and fellowship among its members, founded in 1978 at Ohio State University.' },
  { id: 'sigma-alpha-epsilon', name: 'Sigma Alpha Epsilon', initials: 'SA', tags: 'General Student Organizations', reason: 'A group of young men aimed to maintain involvement in the University.' },
  { id: 'sigma-alpha-iota', name: 'Sigma Alpha Iota', initials: 'SA', tags: 'General Student Organizations', reason: 'The mission of Sigma Alpha Iota International Music Fraternity is to encourage, nurture, and support the art of music.' },
  { id: 'sigma-chi', name: 'Sigma Chi', initials: 'SC', tags: 'General Student Organizations', reason: 'Since 1855, Sigma Chi has developed values-based leaders committed to the betterment of character, campus, and community.' },
  { id: 'sigma-delta-pi', name: 'Sigma Delta Pi', initials: 'SD', tags: 'General Student Organizations', reason: 'Sigma Delta Pi, the National Collegiate Hispanic Honor society, is dedicated to preserving and spreading awareness of the Hispanic culture and language.' },
  { id: 'sigma-iota-epsilon', name: 'Sigma Iota Epsilon', initials: 'SI', tags: 'General Student Organizations', reason: 'Sigma Iota Epsilon is a national honorary and professional management fraternity, encouraging scholastic excellence and cooperation between academic and practical management.' },
  { id: 'sigma-lambda-beta-internationa', name: 'Sigma Lambda Beta International Fraternity Inc.', initials: 'SL', tags: 'Fraternities & Sororities', reason: 'Sigma Lambda Beta International Fraternity is the largest and fastest-growing multicultural fraternity in the nation, founded in 1986.' },
  { id: 'sigma-nu', name: 'Sigma Nu', initials: 'SN', tags: 'General Student Organizations', reason: 'In Sigma Nu we pride ourselves in developing ethical leaders inspired by the principles of Love, Honor and Truth, fostering personal growth of mind, heart and character.' },
  { id: 'sigma-phi-epsilon-texas-iota', name: 'Sigma Phi Epsilon - Texas Iota', initials: 'SP', tags: 'General Student Organizations', reason: 'Through SigEp, men strengthen their character, build leadership and interpersonal skills, and learn to develop healthy, lifelong relationships.' },
  { id: 'sigma-phi-lambda', name: 'Sigma Phi Lambda', initials: 'SP', tags: 'General Student Organizations', reason: 'Sigma Phi Lambda is a nondenominational Christian sorority that focuses on glorifying Christ in everything that we do, including community service and outreach.' },
  { id: 'sigma-tau-delta', name: 'Sigma Tau Delta', initials: 'ST', tags: 'General Student Organizations', reason: 'Sigma Tau Delta is an international English honor society committed to distinguishing students for their contribution to English language and literature.' },
  { id: 'signing-raiders', name: 'Signing Raiders', initials: 'SR', tags: 'General Student Organizations', reason: 'The purpose of Signing Raiders is to promote personal and professional growth for ASL students by facilitating language use and educating about Deaf culture.' },
  { id: 'skyraiders', name: 'Skyraiders', initials: 'SK', tags: 'General Student Organizations', reason: 'We are a student organization run by the students in the Aerospace Studies Department, supporting the 820th Cadet Wing\'s mission to build quality leaders.' },
  { id: 'social-work-student-organizati', name: 'Social Work Student Organization', initials: 'SW', tags: 'General Student Organizations', reason: 'The purpose of this organization is to enhance the professional growth and camaraderie between social work and all helping profession focused students.' },
  { id: 'society-of-environmental-profe', name: 'Society Of Environmental Professionals', initials: 'EP', tags: 'General Student Organizations', reason: 'The purpose of the Society of Environmental Professionals is to foster and promote interest in all matters pertaining to environmental engineering.' },
  { id: 'society-of-petroleum-engineers', name: 'Society Of Petroleum Engineers', initials: 'PE', tags: 'STEM & Engineering', reason: 'We are the Texas Tech University Student Chapter of the Society of Petroleum Engineers International, comprised of promising petroleum engineering professionals.' },
  { id: 'society-of-hispanic-profession', name: 'Society of Hispanic Professional Engineers', initials: 'HP', tags: 'STEM & Engineering', reason: 'Our Mission is to promote the advancement of Hispanics in math, science, engineering and other technical fields through community service and academic achievement.' },
  { id: 'society-of-plastics-engineers', name: 'Society of Plastics Engineers', initials: 'PE', tags: 'STEM & Engineering', reason: 'Society of Plastics Engineers is one of the largest and most well known technical communities in the global polymer/plastics industry.' },
  { id: 'society-of-professional-journa', name: 'Society of Professional Journalists', initials: 'PJ', tags: 'General Student Organizations', reason: 'The Texas Tech University chapter of the Society of Professional Journalists seeks to promote ethical, informed, and responsible journalism.' },
  { id: 'society-of-women-engineers', name: 'Society of Women Engineers', initials: 'WE', tags: 'STEM & Engineering', reason: 'Society of Women Engineers is a non-profit organization that supports the advancement of women as professional engineers, hosting outreach events and networking opportunities.' },
  { id: 'south-asian-student-associatio', name: 'South Asian Student Association', initials: 'SA', tags: 'Cultural & Identity', reason: 'The organization celebrates the South Asian cultures of Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, and Sri Lanka through music, dance, and holiday celebrations.' },
  { id: 'space-exploration-raiders', name: 'Space Exploration Raiders', initials: 'SE', tags: 'General Student Organizations', reason: 'Are you interested in exploring space? In this club you will get to design, build, and manufacture a human-powered space rover for NASA\'s annual HERC competition.' },
  { id: 'special-olympics-college', name: 'Special Olympics College', initials: 'SO', tags: 'General Student Organizations', reason: 'S.O. College aims to foster friendships and create a safe recreational environment for individuals with physical and intellectual disabilities through sports and leisure activity.' },
  { id: 'sports-and-entertainment-law-s', name: 'Sports and Entertainment Law Society', initials: 'SE', tags: 'Law', reason: 'The TTU Sports and Entertainment Law Society is committed to exploring legal issues and career paths in the sport and entertainment industries.' },
  { id: 'sri-lankan-students-associatio', name: 'Sri Lankan Students Association', initials: 'SL', tags: 'Cultural & Identity', reason: 'The purpose of the Sri Lankan Students Association is to promote awareness about Sri Lanka and address the needs of Sri Lankan students at Texas Tech.' },
  { id: 'student-activities-board', name: 'Student Activities Board', initials: 'AB', tags: 'General Student Organizations', reason: 'Mission: The Student Activities Board, SAB, is committed to hosting FREE STUDENT EVENTS that contribute to each student\'s individual experience at Texas Tech University.' },
  { id: 'student-agricultural-and-natur', name: 'Student Agricultural and Natural Resources Council', initials: 'AN', tags: 'Agriculture & Natural Resources', reason: 'The purpose of this organization is to establish a working relationship between students, faculty, administration, and the agricultural & natural resource community.' },
  { id: 'student-alumni-board', name: 'Student Alumni Board', initials: 'AB', tags: 'General Student Organizations', reason: 'The Texas Tech Student Alumni Board are student ambassadors for the Texas Tech Alumni Association who enrich relationships between students and alumni.' },
  { id: 'student-association-of-marriag', name: 'Student Association Of Marriage And Family Therapy', initials: 'MF', tags: 'General Student Organizations', reason: 'The Student Association of Marriage and Family Therapy is an organization of students committed to promoting student networking and developing the potential of students.' },
  { id: 'student-association-for-fire-e', name: 'Student Association for Fire Ecology', initials: 'FE', tags: 'General Student Organizations', reason: 'The Student Association for Fire Ecology is dedicated to exploring the role of fire in ecosystem processes, benefiting from AFE\'s international expertise.' },
  { id: 'student-bar-association', name: 'Student Bar Association', initials: 'BA', tags: 'Law', reason: 'The Student Bar Association (SBA) is a group of law students elected by their peers to be the voice of the student body, planning budgets and providing a forum for grievances.' },
  { id: 'student-chapter-of-the-america', name: 'Student Chapter of the American Association of Equine Practitioners', initials: 'CA', tags: 'Agriculture & Natural Resources', reason: 'A student chapter designed to allow students to advance their knowledge in equine medicine through extracurricular activities.' },
  { id: 'student-chapter-of-the-america-2', name: 'Student Chapter of the American Meteorological Society at Tech', initials: 'CA', tags: 'STEM & Engineering', reason: 'We strive to aid in the development and dissemination of the knowledge of meteorology, bringing together students interested in the field.' },
  { id: 'student-government-association', name: 'Student Government Association', initials: 'GO', tags: 'General Student Organizations', reason: 'Texas Tech University\'s Student Government.' },
  { id: 'student-mobilization', name: 'Student Mobilization', initials: 'MO', tags: 'General Student Organizations', reason: 'Tech StuMo is a non-denominational student organization committed to the growth of Tech students in their leadership, character & spiritual development.' },
  { id: 'student-nutrition-organization', name: 'Student Nutrition Organization', initials: 'NU', tags: 'Health & Pre-Professional', reason: 'The Student Nutrition Organization\'s mission is to inspire students pursuing health science degrees to dedicate themselves to improving public health through nutrition.' },
  { id: 'student-organ-donation-advocat', name: 'Student Organ Donation Advocates', initials: 'OD', tags: 'General Student Organizations', reason: 'The purpose of Student Organ Donation Advocates is to advocate for organ donation through education and donor registration efforts in our community.' },
  { id: 'student-veterinary-emergency-r', name: 'Student Veterinary Emergency Response Association', initials: 'VE', tags: 'Health & Pre-Professional', reason: 'The Student Veterinary Emergency Response Association is a student-led organization focused on Emergency Preparation, Response, and Community support.' },
  { id: 'students-of-east-africa-at-tec', name: 'Students of East Africa at Tech', initials: 'EA', tags: 'General Student Organizations', reason: 'The mission of Students of East Africa at Texas Tech is to embody and unite the East African community and create awareness of the cultures.' },
  { id: 'studio-hacks', name: 'Studio Hacks', initials: 'SH', tags: 'General Student Organizations', reason: 'We offer help with all the basic skills needed to succeed in the Architecture major, showing you the ropes of being an architecture student.' },
  { id: 'trio-student-support-services', name: 'TRIO Student Support Services', initials: 'TS', tags: 'Service & Philanthropy', reason: 'TRIO SSS is a program designed to increase the graduation and retention rates at TTU.' },
  { id: 'ttu-svm-food-animal-club', name: 'TTU SVM Food Animal Club', initials: 'TS', tags: 'General Student Organizations', reason: 'The TTUSVM Food Animal Club is designed to serve the School of Veterinary Medicine students, providing hands-on learning opportunities on food and production animal medicine.' },
  { id: 'tau-beta-pi', name: 'Tau Beta Pi', initials: 'TB', tags: 'Honor Societies', reason: 'Tau Beta Pi is universally recognized as the preeminent engineering honor society, the nation\'s second-oldest honor society, founded at Lehigh University in 1885.' },
  { id: 'tau-beta-sigma', name: 'Tau Beta Sigma', initials: 'TB', tags: 'Honor Societies', reason: 'Tau Beta Sigma is a co-educational national honorary band sorority dedicated to serving college and band programs as a student service and leadership organization.' },
  { id: 'tau-kappa-epsilon', name: 'Tau Kappa Epsilon', initials: 'TK', tags: 'General Student Organizations', reason: 'Omicron Rho Chapter of the largest social fraternity in the world, aiding men in their mental, moral, and social development for life.' },
  { id: 'teaching-techsans', name: 'Teaching Techsans', initials: 'TT', tags: 'General Student Organizations', reason: 'Find new friendships in an inclusive, teacher-centered environment, gaining knowledge about your future while working alongside future educators.' },
  { id: 'tech-advertising-federation', name: 'Tech Advertising Federation', initials: 'AF', tags: 'General Student Organizations', reason: 'Tech Advertising Federation is Texas Tech\'s chapter of the American Advertising Federation, giving advertising majors opportunities for success in the industry.' },
  { id: 'tech-american-society-for-micr', name: 'Tech American Society for Microbiology', initials: 'AM', tags: 'STEM & Engineering', reason: 'We are an organization that focuses on promoting research, education and advancement in the field of Microbiology, open to graduate students.' },
  { id: 'tech-archery-club', name: 'Tech Archery Club', initials: 'AR', tags: 'Sport Clubs', reason: 'Tech Archery Club is a club geared towards anything archery, from bowhunting to target archery, from recurves to compounds.' },
  { id: 'tech-astronomy-club', name: 'Tech Astronomy Club', initials: 'AS', tags: 'STEM & Engineering', reason: 'To provide students with an outlet to connect, research, and learn about all things astronomy.' },
  { id: 'tech-athletic-ambassadors', name: 'Tech Athletic Ambassadors', initials: 'AA', tags: 'General Student Organizations', reason: 'The Tech Athletics Ambassadors is comprised of the most elite Texas Tech students starting their careers in sports marketing, engaging fans and promoting Texas Tech Athletics.' },
  { id: 'tech-bass-fishing-team', name: 'Tech Bass Fishing Team', initials: 'BF', tags: 'Sport Clubs', reason: 'We look to compete around the country in organized tournaments for college anglers, determined to win at a high level and represent our school.' },
  { id: 'tech-board-game-club', name: 'Tech Board Game Club', initials: 'BG', tags: 'General Student Organizations', reason: 'The purpose of the Tech Board Game Club is to bring people together under the common interest of tabletop board games and create a community.' },
  { id: 'tech-book-history-club', name: 'Tech Book History Club', initials: 'BH', tags: 'General Student Organizations', reason: 'The Tech University Book History Club explores the interdisciplinary field of Book History, including how paper and books are made and exploring rare books.' },
  { id: 'tech-chinese-language-and-cult', name: 'Tech Chinese Language and Culture Association', initials: 'CL', tags: 'Cultural & Identity', reason: 'The purpose of the Tech Chinese Language and Culture Association is to invite individuals of the student body to experience Chinese Culture.' },
  { id: 'tech-choirs', name: 'Tech Choirs', initials: 'CH', tags: 'Arts & Media', reason: 'Texas Tech Choirs is an organization in which students from numerous majors come together to learn and grow through music in four different ensembles.' },
  { id: 'tech-classical-society', name: 'Tech Classical Society', initials: 'CL', tags: 'General Student Organizations', reason: 'A society promoting knowledge of the Ancient Mediterranean.' },
  { id: 'tech-climbing-club', name: 'Tech Climbing Club', initials: 'CL', tags: 'Sport Clubs', reason: 'We strive to provide a friendly community for climbers at Texas Tech.' },
  { id: 'tech-club-baseball', name: 'Tech Club Baseball', initials: 'BA', tags: 'Sport Clubs', reason: 'We are a competitive collegiate baseball club designed to compete in the NCBA (National Club Baseball Association).' },
  { id: 'tech-club-hockey', name: 'Tech Club Hockey', initials: 'HO', tags: 'Sport Clubs', reason: 'Tech Ice Hockey is a club for hockey players that want to continue playing competitive hockey, competing in the American Collegiate Hockey Association.' },
  { id: 'tech-club-water-polo-team', name: 'Tech Club Water Polo Team', initials: 'WP', tags: 'Sport Clubs', reason: 'We play water polo in the Collegiate Water Polo Association Men\'s Texas Division as a Co-Ed team.' },
  { id: 'tech-college-republicans', name: 'Tech College Republicans', initials: 'CR', tags: 'Political', reason: 'Tech College Republicans is an official auxiliary branch of the Republican Party of Texas, actively promoting Republican values at Tech.' },
  { id: 'tech-council-on-family-relatio', name: 'Tech Council on Family Relations', initials: 'OF', tags: 'General Student Organizations', reason: 'Tech CFR members work to fulfill the mission of the organization by providing information sessions, regular meetings with guest speakers, and service opportunities.' },
  { id: 'tech-creative-media-associatio', name: 'Tech Creative Media Association', initials: 'CM', tags: 'Arts & Media', reason: 'The Tech Creative Media Association is a group of like-minded content creators, a place of creative freedom for filmmakers and photographers.' },
  { id: 'tech-dairy-science-club', name: 'Tech Dairy Science Club', initials: 'DS', tags: 'STEM & Engineering', reason: 'The purpose of our organization is to bring together Texas Tech students interested in dairy cattle or a career within the industry.' },
  { id: 'tech-disc-golf', name: 'Tech Disc Golf', initials: 'DG', tags: 'Sport Clubs', reason: 'Tech Disc Golf Club intends to teach new players the amazing sport of disc golf while also creating a competitive environment for veteran players.' },
  { id: 'tech-economics-association', name: 'Tech Economics Association', initials: 'EC', tags: 'General Student Organizations', reason: 'The Tech Economics Association is an academic-based student organization for all students interested in Economics for networking and academic guidance.' },
  { id: 'tech-emergency-medical-service', name: 'Tech Emergency Medical Services', initials: 'EM', tags: 'Health & Pre-Professional', reason: 'A student-run EMS volunteer organization at Texas Tech University open to all students, with monthly skills workshops and volunteering opportunities.' },
  { id: 'tech-entomology-club', name: 'Tech Entomology Club', initials: 'EN', tags: 'STEM & Engineering', reason: 'The main emphasis of the Tech Entomology Club is to provide professional and social opportunities for all students interested in entomology.' },
  { id: 'tech-equestrian-team', name: 'Tech Equestrian Team', initials: 'ET', tags: 'Sport Clubs', reason: 'The Tech Equestrian Team is for undergraduate students of all majors who want to show horses in IHSA collegiate competitions, beginners welcome.' },
  { id: 'tech-esports-association', name: 'Tech Esports Association', initials: 'ES', tags: 'General Student Organizations', reason: 'Community of members interested in playing video games together, either on the competitive or social level, currently competing in regional & national level.' },
  { id: 'tech-feral-cat-coalition', name: 'Tech Feral Cat Coalition', initials: 'FC', tags: 'General Student Organizations', reason: 'The mission of the Tech Feral Cat Coalition is to manage the campus cat colony at Texas Tech by humanely trapping, vaccinating, and returning cats to their environment.' },
  { id: 'tech-french-club', name: 'Tech French Club', initials: 'FR', tags: 'General Student Organizations', reason: 'The purpose of our organization is to promote a community of Francophiles who have an appreciation for the French language and French/Francophone cultures.' },
  { id: 'tech-gender-and-sexuality-asso', name: 'Tech Gender and Sexuality Association', initials: 'GS', tags: 'General Student Organizations', reason: 'Tech GSA is a student-led LGBTQIA+ and allies organization striving to make Texas Tech and the Lubbock community a safe and welcoming place to all students.' },
  { id: 'tech-golf-club', name: 'Tech Golf Club', initials: 'GO', tags: 'Sport Clubs', reason: 'Social and Competitive golf, competing against major Texas schools in multiple tournaments each semester.' },
  { id: 'tech-gymnastics-club', name: 'Tech Gymnastics Club', initials: 'GY', tags: 'Sport Clubs', reason: 'Texas Tech Gymnastics Club is an all-inclusive sports club committed to sharing the love of gymnastics.' },
  { id: 'tech-horn-society', name: 'Tech Horn Society', initials: 'HO', tags: 'General Student Organizations', reason: 'The Tech Horn Society\'s purpose is to support the activities of the Texas Tech University School of Music Horn Studio.' },
  { id: 'tech-horse-judging-team', name: 'Tech Horse Judging Team', initials: 'HJ', tags: 'General Student Organizations', reason: 'The purpose of this organization is intercollegiate competition, recruitment, further educational advancement and representation of Texas Tech University.' },
  { id: 'tech-improv-troupe', name: 'Tech Improv Troupe', initials: 'IT', tags: 'Arts & Media', reason: 'The Sentient Nuts perform improvisational comedy and unscripted theatre events on campus and in the Lubbock area.' },
  { id: 'tech-kahaani-bollywood-dance-t', name: 'Tech Kahaani Bollywood Dance Team', initials: 'KB', tags: 'Arts & Media', reason: 'Tech Kahaani is a coed dance team that expresses culture and diversity through Bollywood fusion dancing, performing at on/off-campus events.' },
  { id: 'tech-kpop-club', name: 'Tech Kpop Club', initials: 'KP', tags: 'General Student Organizations', reason: 'Our purpose of the Tech K-Pop Club is to create lasting friendships and memories with the help of a strong love for Korean Pop music.' },
  { id: 'tech-law-military-association', name: 'Tech Law Military Association', initials: 'LM', tags: 'Law', reason: 'The Tech Law Military Association (TLMA) strives to be the premier organization committed to providing a sense of camaraderie to persons with ties to the armed forces.' },
  { id: 'tech-lawn-mower-racing', name: 'Tech Lawn Mower Racing', initials: 'LM', tags: 'Law', reason: 'The main purpose of the club is to build and race lawnmowers, applying engineering knowledge to a competitive setting.' },
  { id: 'tech-magic-club', name: 'Tech Magic Club', initials: 'MA', tags: 'General Student Organizations', reason: 'This club is dedicated to providing a community for magic players in the Texas Tech Community, hosting monthly and weekly meet-ups.' },
  { id: 'tech-marketing-association', name: 'Tech Marketing Association', initials: 'MA', tags: 'Business', reason: 'Tech Marketing Association (TMA) was created to promote the academic and professional development of Texas Tech students through networking events and leadership opportunities.' },
  { id: 'tech-martial-arts-club', name: 'Tech Martial Arts Club', initials: 'MA', tags: 'Sport Clubs', reason: 'Tech Martial Arts Club\'s purpose is teaching the discipline of Aikido and Judo to students, developing self-defense skills.' },
  { id: 'tech-men-s-club-volleyball', name: 'Tech Men\'s Club Volleyball', initials: 'MS', tags: 'Sport Clubs', reason: 'This organization is to help further the understanding of the men\'s volleyball game.' },
  { id: 'tech-men-s-lacrosse-club', name: 'Tech Men\'s Lacrosse Club', initials: 'MS', tags: 'Sport Clubs', reason: 'The Tech Men\'s Lacrosse Club is dedicated to the growth of Lacrosse at a competitive level.' },
  { id: 'tech-men-s-rugby-club', name: 'Tech Men\'s Rugby Club', initials: 'MS', tags: 'Sport Clubs', reason: 'Texas Tech Men\'s Rugby strives to be the best rugby team in the nation, learning, teaching, and honoring the game of Rugby.' },
  { id: 'tech-men-s-soccer-club', name: 'Tech Men\'s Soccer Club', initials: 'MS', tags: 'General Student Organizations', reason: 'We are a student-run organization which provides competitive soccer without the time commitment of a varsity program.' },
  { id: 'tech-minorities-and-philosophy', name: 'Tech Minorities And Philosophy', initials: 'MP', tags: 'General Student Organizations', reason: 'Texas Tech MAP is one of several Graduate-led chapters of Minorities and Philosophy globally, addressing systemic injustice in academic philosophy.' },
  { id: 'tech-national-retail-federatio', name: 'Tech National Retail Federation Student Association', initials: 'NR', tags: 'Business', reason: 'The Mission of the Texas Tech University Retail Management Program is to prepare individuals who will make a contribution to the retail industry.' },
  { id: 'tech-philosophy-club', name: 'Tech Philosophy Club', initials: 'PH', tags: 'General Student Organizations', reason: 'Here at Tech Philosophy Club we are dedicated to creating a compassionate and understanding community that welcomes all diverse perspectives.' },
  { id: 'tech-photo-club', name: 'Tech Photo Club', initials: 'PH', tags: 'General Student Organizations', reason: 'The Tech Photo Club promotes, enhances, and furthers photographic knowledge, involvement, and opportunities within the Texas Tech community.' },
  { id: 'tech-pok-mon', name: 'Tech Pokémon', initials: 'PM', tags: 'General Student Organizations', reason: 'Tech Pokémon is a club for anyone interested in Pokémon, hosting events such as casual tournaments and Pokémon GO community days.' },
  { id: 'tech-polo-club', name: 'Tech Polo Club', initials: 'PO', tags: 'Sport Clubs', reason: 'The Tech Polo Club is an organization dedicated to introducing horsemanship and this incredible sport to any students who are interested in learning.' },
  { id: 'tech-pre-occupational-therapy-', name: 'Tech Pre-Occupational Therapy Club', initials: 'PO', tags: 'Health & Pre-Professional', reason: 'The purpose of the organization is to inform, support, encourage, promote volunteer participation and aid students interested in Occupational Therapy.' },
  { id: 'tech-pre-pharmacy-club', name: 'Tech Pre-Pharmacy Club', initials: 'PP', tags: 'Health & Pre-Professional', reason: 'The Pre-Pharmacy Club (PPC) is a student organization for TTU students who are interested in pharmacy, keeping members updated about pharmacy school admissions.' },
  { id: 'tech-pre-vet-society', name: 'Tech Pre-Vet Society', initials: 'PV', tags: 'Health & Pre-Professional', reason: 'The Tech Pre-Vet Society is an academic organization dedicated to aiding students who are seeking to attend a school of Veterinary Medicine.' },
  { id: 'tech-print-club', name: 'Tech Print Club', initials: 'PR', tags: 'General Student Organizations', reason: 'An art club for students at Texas Tech interested in the field of Printmaking.' },
  { id: 'tech-rpg-club', name: 'Tech RPG Club', initials: 'RP', tags: 'General Student Organizations', reason: 'An organization dedicated to providing a fun and inviting space for students interested in Table Top Role-Playing Games and Table Top Card Games.' },
  { id: 'tech-research-club', name: 'Tech Research Club', initials: 'RE', tags: 'STEM & Engineering', reason: 'The purpose of the Tech Research Club is to provide undergraduate students with opportunities to engage in and learn about research across all academic disciplines.' },
  { id: 'tech-robotics-association', name: 'Tech Robotics Association', initials: 'RO', tags: 'STEM & Engineering', reason: 'The Tech Robotics Association is a robotics club open to all Texas Tech students who are interested in being involved in the West Texas robotics community.' },
  { id: 'tech-russian-and-slavic-associ', name: 'Tech Russian and Slavic Association', initials: 'RS', tags: 'General Student Organizations', reason: 'This club is for anyone interested in learning about Russian culture and language.' },
  { id: 'tech-secular-student-alliance', name: 'Tech Secular Student Alliance', initials: 'SA', tags: 'General Student Organizations', reason: 'The Tech SSA empowers secular students and our allies to proudly express their identity, build welcoming communities, and promote secular values.' },
  { id: 'tech-shelter-medicine-club', name: 'Tech Shelter Medicine Club', initials: 'SM', tags: 'Service & Philanthropy', reason: 'The Tech Shelter Medicine Club is dedicated to advancing veterinary student education in shelter medicine through hands-on clinical practice.' },
  { id: 'tech-society-for-human-resourc', name: 'Tech Society for Human Resource Management', initials: 'HR', tags: 'Business', reason: 'The purpose of Tech SHRM is to encourage and support individual professional development in the field of business, management, and human resource management.' },
  { id: 'tech-sport-management-group', name: 'Tech Sport Management Group', initials: 'SM', tags: 'General Student Organizations', reason: 'The Tech Sport Management Group welcomes all scholars within the KSM department of TTU who have an interest in networking and gaining insights into sports industry careers.' },
  { id: 'tech-student-association-for-w', name: 'Tech Student Association for Women\'s Health', initials: 'WS', tags: 'Health & Pre-Professional', reason: 'Our goal is to empower women on campus and in the Lubbock community by promoting health and addressing disparities in menstrual hygiene.' },
  { id: 'tech-student-chapter-of-the-am', name: 'Tech Student Chapter of the American Choral Directors Association', initials: 'CA', tags: 'General Student Organizations', reason: 'Help prepare choral music education majors for their first job, providing the tools and skills needed to be successful wherever they teach.' },
  { id: 'tech-student-chapter-of-the-am-2', name: 'Tech Student Chapter of the American College of Veterinary Pathologists', initials: 'CA', tags: 'Health & Pre-Professional', reason: 'This organization aims to develop student interest in pathology and collaborate with other TTU SVM clubs and the parent body.' },
  { id: 'tech-student-subunit-of-the-te', name: 'Tech Student Subunit of the Texas Chapter of the American Fisheries Society', initials: 'SC', tags: 'General Student Organizations', reason: 'We are an organization that provides a forum for the discussion of fisheries and aquatic sciences among students and the American Fisheries Society.' },
  { id: 'tech-supply-chain-association', name: 'Tech Supply Chain Association', initials: 'SC', tags: 'Business', reason: 'The purpose of TSCA is to promote the academic and professional development of members and advance the prestige of the Rawls College of Business Supply Chain program.' },
  { id: 'tech-swimming', name: 'Tech Swimming', initials: 'SW', tags: 'Sport Clubs', reason: 'Tech Swimming is hoping to bring together anyone and everyone who has a passion for swimming, offering a great way to exercise.' },
  { id: 'tech-taara', name: 'Tech Taara', initials: 'TA', tags: 'General Student Organizations', reason: 'Tech Taara is Texas Tech\'s first bhangra fusion dance team, expressing culture and diversity through Bollywood fusion dancing.' },
  { id: 'tech-tennis-club', name: 'Tech Tennis Club', initials: 'TE', tags: 'Sport Clubs', reason: 'The club is a great way to get involved and meet new people through tennis, open to all skill levels with a traveling competitive team.' },
  { id: 'tech-terry-scholars', name: 'Tech Terry Scholars', initials: 'TS', tags: 'Honor Societies', reason: 'Student organization for recipients of the Terry Foundation Scholarship.' },
  { id: 'tech-thoma-scholars', name: 'Tech Thoma Scholars', initials: 'TS', tags: 'Honor Societies', reason: 'The Tech Thoma Scholars organization seeks to develop members into leaders and advocates for rural regions of Texas, Oklahoma panhandles and eastern New Mexico.' },
  { id: 'tech-trap-skeet-club', name: 'Tech Trap & Skeet Club', initials: 'TS', tags: 'Sport Clubs', reason: 'An organization meant for educating students about gun safety and range etiquette, introducing members to trap and skeet shooting sports.' },
  { id: 'tech-unicef', name: 'Tech UNICEF', initials: 'UN', tags: 'General Student Organizations', reason: 'Tech UNICEF is a college branch of UNICEF, focusing on educating our community about UNICEF\'s efforts through meetings and fundraisers.' },
  { id: 'tech-women-in-high-performance', name: 'Tech Women in High Performance Computing', initials: 'WH', tags: 'STEM & Engineering', reason: '"Tech Women in HPC" tries to increase the visibility of women in HPC in both practical and research fields.' },
  { id: 'tech-women-s-club-soccer', name: 'Tech Women\'s Club Soccer', initials: 'WS', tags: 'Sport Clubs', reason: 'Tech Women\'s Club Soccer is a competitive student-run sports club that plays other universities in a league and tournaments.' },
  { id: 'tech-women-s-club-volleyball', name: 'Tech Women\'s Club Volleyball', initials: 'WS', tags: 'Sport Clubs', reason: 'Competitive club volleyball team at Texas Tech University.' },
  { id: 'tech-women-s-lacrosse-club', name: 'Tech Women\'s Lacrosse Club', initials: 'WS', tags: 'Sport Clubs', reason: 'A Sports Club that allows girls to get together and compete against other members of the TWLL league, no experience required.' },
  { id: 'tech-women-s-rugby-football-cl', name: 'Tech Women\'s Rugby Football Club', initials: 'WS', tags: 'Sport Clubs', reason: 'Since our induction into the Texas Tech University Sports Club Federation in 1995, the Texas Tech Women\'s Rugby team has become a prominent club in women\'s athletics.' },
  { id: 'tech-yugioh-club', name: 'Tech Yugioh Club', initials: 'YU', tags: 'General Student Organizations', reason: 'Our purpose is to create a safe and welcoming environment for students to play and talk about yugioh and its many facets.' },
  { id: 'tech-the-vote', name: 'Tech the Vote', initials: 'VO', tags: 'Political', reason: 'Tech the Vote serves to educate, activate, and engage Texas Tech students on voting rights and civic engagement.' },
  { id: 'texas-aggie-bar-association', name: 'Texas Aggie Bar Association', initials: 'AB', tags: 'Law', reason: 'Howdy! The Texas Aggie Bar Association is a student law organization for alumni and friends of the Texas A&M University system.' },
  { id: 'texas-society-of-professional-', name: 'Texas Society of Professional Engineers', initials: 'PE', tags: 'STEM & Engineering', reason: 'Engineering organization that encompasses all fields, working to uphold the Professional Engineering License.' },
  { id: 'texas-tech-law-review', name: 'Texas Tech Law Review', initials: 'LR', tags: 'Law', reason: 'The Texas Tech Law Review is a general-interest academic law journal published quarterly by students of Texas Tech University School of Law, first published in 1970.' },
  { id: 'the-biochemical-society-at-tec', name: 'The Biochemical Society at Tech', initials: 'BI', tags: 'General Student Organizations', reason: 'The Biochemical Society is an organization based out of Texas Tech that is meant to provide a community for students in the biochemical field.' },
  { id: 'the-delta-chi-fraternity', name: 'The Delta Chi Fraternity', initials: 'DC', tags: 'Fraternities & Sororities', reason: 'We are a group of men that strives to promote friendship, develop character, advance justice, and assist in the acquisition of a sound education.' },
  { id: 'the-electrochemical-society', name: 'The Electrochemical Society', initials: 'EL', tags: 'General Student Organizations', reason: 'The mission of an ECS student chapter is to provide students the opportunity to foster understanding and promote electrochemical and solid-state science and technology.' },
  { id: 'the-journey-at-southcrest', name: 'The Journey at Southcrest', initials: 'JS', tags: 'General Student Organizations', reason: 'The Journey is a ministry of Southcrest Baptist Church for college students & young adults, helping them find their greatest pleasure and purpose in Jesus.' },
  { id: 'the-masked-bakers', name: 'The Masked Bakers', initials: 'MB', tags: 'General Student Organizations', reason: 'We provide the underprivileged population of Lubbock access to delicious handmade desserts as well as meet some other TTU students and Lubbock locals.' },
  { id: 'the-math-club', name: 'The Math Club', initials: 'MA', tags: 'STEM & Engineering', reason: 'The Math Club is a social club on campus for students who are interested in mathematics, come join us for free food and games.' },
  { id: 'the-national-society-of-colleg', name: 'The National Society of Collegiate Scholars', initials: 'NC', tags: 'Honor Societies', reason: 'NSCS is an honor society that engages high-achieving first- and second-year students in the top 20% of their class.' },
  { id: 'the-national-society-of-leader', name: 'The National Society of Leadership and Success', initials: 'NL', tags: 'General Student Organizations', reason: 'The NSLS is an organization that provides a life-changing leadership program that helps students achieve personal growth and career success.' },
  { id: 'the-raiders-chapter-of-the-ass', name: 'The Raiders Chapter of the Association for Women in Mathematics', initials: 'RC', tags: 'STEM & Engineering', reason: 'The purpose of the AWM Raiders is to encourage women and girls to study and have active careers in the mathematical sciences.' },
  { id: 'the-rotaract-club-of-costa-ric', name: 'The Rotaract Club of Costa Rica/Raiders Service Team', initials: 'RC', tags: 'Service & Philanthropy', reason: 'The purpose of the Rotaract Club is to create a positive impact in the community through service projects and leadership development.' },
  { id: 'the-structural-engineers-assoc', name: 'The Structural Engineers Association of Texas', initials: 'SE', tags: 'STEM & Engineering', reason: 'The Structural Engineering Association of Texas (SEAoT) is dedicated to enhancing opportunities for students in the Civil, Environmental, and Construction Engineering department.' },
  { id: 'the-student-chapter-of-the-soc', name: 'The Student Chapter of the Society for Range Management at Tech', initials: 'CR', tags: 'General Student Organizations', reason: 'The Student Chapter of the Society for Range Management at Tech provides students with foundational skills and opportunities to grow as stewards of rangelands.' },
  { id: 'the-texas-bank-lawyer', name: 'The Texas Bank Lawyer', initials: 'BL', tags: 'Law', reason: 'The Texas Bank Lawyer (TBL) is a monthly legal publication that provides materials of interest to subscribing banks and attorneys practicing banking and commercial law.' },
  { id: 'the-way', name: 'The Way', initials: 'WA', tags: 'General Student Organizations', reason: 'The Way is a non-denominational college and young adult ministry of Indiana Avenue Baptist Church that lives to worship Jesus, look like Jesus, and share Jesus.' },
  { id: 'the-wildlife-society-at-tech', name: 'The Wildlife Society at Tech', initials: 'WI', tags: 'Agriculture & Natural Resources', reason: 'The Wildlife Society at Tech is an international professional organization dedicated to promoting the scientific study of biological diversity.' },
  { id: 'theta-chi-fraternity', name: 'Theta Chi Fraternity', initials: 'TC', tags: 'Fraternities & Sororities', reason: 'Theta Chi is one of the oldest men\'s college fraternities in North America, founded in 1856, enjoying the Fraternity\'s traditions and fellowship.' },
  { id: 'transfer-techsans', name: 'Transfer Techsans', initials: 'TT', tags: 'General Student Organizations', reason: 'Transfer Techsans is a student organization designed to seamlessly integrate transfer students into campus and student life here at Texas Tech.' },
  { id: 'tree-of-restoration', name: 'Tree Of Restoration', initials: 'TR', tags: 'General Student Organizations', reason: 'Tree Of Restoration is a student led College Campus Ministry purposed in developing the spiritual lives and abilities of students at Texas Tech.' },
  { id: 'turkish-student-association', name: 'Turkish Student Association', initials: 'TU', tags: 'Cultural & Identity', reason: 'To promote appreciation, awareness, and celebration of Turkish culture and history.' },
  { id: 'turning-point-usa-at-tech', name: 'Turning Point USA at Tech', initials: 'TP', tags: 'General Student Organizations', reason: 'Turning Point USA is a national non-profit, non-partisan organization that works hard to promote fiscal responsibility, free markets, and limited government.' },
  { id: 'u-at-south-plains-campus-minis', name: 'U at South Plains Campus Ministry', initials: 'US', tags: 'Faith & Religious Life', reason: 'U at South Plains Campus Ministry is a welcoming Christian organization dedicated to fostering a strong sense of community, faith, and growth among college students.' },
  { id: 'ukrainian-club', name: 'Ukrainian Club', initials: 'UK', tags: 'Cultural & Identity', reason: 'Ukrainian Club unites students and community members interested in Ukrainian culture, celebrating heritage through customs, traditions, art, and history.' },
  { id: 'ultimate-frisbee-club', name: 'Ultimate Frisbee Club', initials: 'UF', tags: 'Sport Clubs', reason: 'Our club is a co-ed competitive team that plays in tournaments with other Universities throughout the year, one of the fastest growing sports on the college level.' },
  { id: 'united-states-institute-for-th', name: 'United States Institute for Theatre Technology Student Chapter', initials: 'US', tags: 'STEM & Engineering', reason: 'Our organization strives to actively promote the advancement of knowledge and skills of its members in all aspects of design and production in the performing arts.' },
  { id: 'veterinary-business-management', name: 'Veterinary Business Management Association', initials: 'VB', tags: 'Business', reason: 'TTU SVM Chapter of the Veterinary Business Management Association.' },
  { id: 'victory-life-college-ministry', name: 'Victory Life College Ministry', initials: 'VL', tags: 'Faith & Religious Life', reason: 'Love God, Love People, & Make Disciples.' },
  { id: 'vitality-dance-company', name: 'Vitality Dance Company', initials: 'VD', tags: 'Arts & Media', reason: 'VDC is a student organization for dancers, choreographing and performing pieces in various dance styles including contemporary and hip-hop.' },
  { id: 'vocal-synth-club', name: 'Vocal Synth Club', initials: 'VS', tags: 'General Student Organizations', reason: 'Supporting artists, music producers, and fans in using and discovering vocal synthesizers.' },
  { id: 'we-impact-supply-chain-excelle', name: 'We Impact Supply Chain Excellence', initials: 'WI', tags: 'Business', reason: 'WISE is a student organization with the purpose of encouraging more women to enter the supply chain field and promoting professional development.' },
  { id: 'wesley-at-tx-tech', name: 'Wesley at Tx Tech', initials: 'WT', tags: 'General Student Organizations', reason: 'The Wesley is dedicated to raising up generations of dynamic Christians who lead by inviting real people into real ministry in the real world.' },
  { id: 'west-texas-association-for-bot', name: 'West Texas Association for Botany', initials: 'WB', tags: 'General Student Organizations', reason: 'West Texas Association for Botany aims to build a positive and active plant research environment and share research interests with undergraduate and graduate students.' },
  { id: 'whitacre-college-of-engineerin', name: 'Whitacre College of Engineering Outreach Raiders', initials: 'WC', tags: 'STEM & Engineering', reason: 'The Whitacre College of Engineering Outreach Raiders program engages with local K-12th grade students to educate and cultivate an interest in engineering fields.' },
  { id: 'wildlife-medicine-club', name: 'Wildlife Medicine Club', initials: 'WM', tags: 'Agriculture & Natural Resources', reason: 'The purpose of our organization is to use our scientific knowledge and skills to conserve and manage wildlife on a state, national, and global level.' },
  { id: 'women-in-business', name: 'Women In Business', initials: 'WB', tags: 'Business', reason: 'WIB is an organization revolving around the composition of TTU students dedicated to professional relationship development and personal growth.' },
  { id: 'women-in-engineering', name: 'Women in Engineering', initials: 'WE', tags: 'STEM & Engineering', reason: 'The purpose Women in Engineering is to support the recruitment, success, and retention of women in all technical disciplines, specifically in Electrical and Computer Engineering.' },
  { id: 'women-in-physics', name: 'Women in Physics', initials: 'WP', tags: 'STEM & Engineering', reason: 'The Women in Physics (WiP) group at Texas Tech University was founded in 2018 to improve the recruitment and retention of women in physics.' },
  { id: 'women-in-pre-law-society', name: 'Women in Pre-Law Society', initials: 'WP', tags: 'Law', reason: 'The mission of the Women in Pre-Law Society is to empower and support women who are interested in pursuing a career in law.' },
  { id: 'women-in-stem', name: 'Women in STEM', initials: 'WS', tags: 'General Student Organizations', reason: 'The Women in STEM organization values women who are currently majoring/minoring in Science, Technology, Engineering, and/or Mathematics.' },
  { id: 'women-s-service-organization', name: 'Women\'s Service Organization', initials: 'WS', tags: 'Service & Philanthropy', reason: 'The purpose of Women\'s Service Organization is to assemble the students of Texas Tech University to serve the campus and community in the spirit of friendship and equality.' },
  { id: 'wool-judging-team', name: 'Wool Judging Team', initials: 'WJ', tags: 'Agriculture & Natural Resources', reason: 'The Wool Judging Team travels to various contests around the U.S. to compete against other universities.' },
  { id: 'yellow-caped-raiders', name: 'Yellow Caped Raiders', initials: 'YC', tags: 'General Student Organizations', reason: 'Canine Companions puppy raising club. Our purpose is to bring awareness and education regarding service dog puppies in training.' },
  { id: 'young-conservatives-of-texas', name: 'Young Conservatives of Texas', initials: 'YC', tags: 'Political', reason: 'Young Conservatives of Texas, a non-partisan conservative youth organization, has been fighting for conservative values for forty years in the Lone Star State.' },
  { id: 'young-professionals-for-casa', name: 'Young Professionals for CASA', initials: 'YP', tags: 'General Student Organizations', reason: 'Tech Students for CASA supports and helps neglected and abused children in the foster care system by volunteering and raising funds.' },
  { id: 'young-professionals-of-texas-t', name: 'Young Professionals of Texas Tech', initials: 'YP', tags: 'General Student Organizations', reason: 'To provide an opportunity for Young Professionals of Texas Tech to network, socialize, and connect.' },
  { id: 'zamo-raiders', name: 'Zamo Raiders', initials: 'ZR', tags: 'General Student Organizations', reason: '"Zamo raiders" is a graduate student organization for Zamorano alumni enrolled in Texas Tech University and anyone who identifies with the Zamorano culture.' },
  { id: 'zeta-phi-beta-sorority-inc', name: 'Zeta Phi Beta Sorority, Inc.', initials: 'ZP', tags: 'Fraternities & Sororities', reason: 'A Community Conscious, Action-Oriented Organization.' },
];

/* Dining and study spots are now DERIVED from the real building
   data rather than hand-written. Status comes from each place's
   actual OSM opening_hours where present, so "Open now" reflects
   real posted hours instead of a hardcoded string. Places with no
   hours in OSM show their walk time only, rather than claiming a
   status we don't actually know. */
/* REAL on-campus dining, transcribed from Texas Tech Hospitality
   Services' own official dining hours page (page-dated Sep 1, 2026).

   This replaces the previous approach, which derived DINING by
   filtering BUILDINGS for kind === 'Dining'. That was genuinely
   broken for this purpose: OpenStreetMap reliably tags standalone
   chains (Whataburger, Chipotle, Raising Cane's) but does NOT tag
   TTU's actual dining halls as dining — Stangel/Murdough, Talkington,
   and Sneed are all tagged 'Housing', so the real halls never showed
   up at all and the list was almost entirely off-campus restaurants.

   Hours use OSM opening_hours syntax so the existing, already
   unit-tested isOpenNow() parser handles them unchanged. `venue` is
   the real building it sits inside; `concepts` lists the real
   individual food stations where TTU publishes them. */
const DINING = [
  { id: '23-at-sneed-sneed-hall', name: '23 at Sneed', venue: 'Sneed Hall', buildingId: 'sneed-residence-hall', hours: 'Mo-Fr 07:00-21:00; Sa-Su 10:00-20:00', concepts: [] },
  { id: 'the-commons-talkington-hall', name: 'The Commons', venue: 'Talkington Hall', buildingId: 'j-t-and-margaret-talkington-reside', hours: 'Mo-Th 11:00-21:00; Fr-Sa 11:00-20:00; Su 11:00-21:00', concepts: ['Greens & Things (salads & wraps)', 'Just Say Cheez (grilled cheese, mac & cheese)', 'Khans Mongolian Grill', 'Klucrs (chicken strips & wings)', 'Parrillas Tex-Mex', 'Parrillas Street Tacos', 'Pi Pizza', 'Second to Naan (Mediterranean)', 'Retail & Grab-N-Go'] },
  { id: 'the-fresh-plate-wall-gates-hall', name: 'The Fresh Plate', venue: 'Wall/Gates Hall', buildingId: null, hours: 'Mo-Fr 10:00-22:00', concepts: ['Breakfast Mo-Fr 7-10am', 'Lunch Mo-Fr 11am-2pm', 'Dinner Mo-Th 5-7pm', 'Retail Mo-Fr 10am-10pm', 'All-You-Care-to-Eat'] },
  { id: 'the-market-stangel-murdough-hall', name: 'The Market', venue: 'Stangel/Murdough Hall', buildingId: 'stangel-murdough-residence-hall', hours: 'Mo-Th 07:00-23:00; Fr 07:00-20:00; Sa 11:00-20:00; Su 11:00-21:00', concepts: ['Multiple dine-in and carry-out concepts'] },
  { id: 'ol-red-s-wiggins-complex', name: 'Ol\'Red\'s', venue: 'Wiggins Complex', buildingId: 'wiggins-complex-dining-hall', hours: 'Mo-Fr 07:00-24:00; Sa-Su 10:00-24:00', concepts: [] },
  { id: 'ghostrider-murray-hall', name: 'GhostRider', venue: 'Murray Hall', buildingId: 'murray-residence-hall', hours: 'Mo-Th 11:00-22:00; Su 12:00-22:00', concepts: [] },
  { id: 'raider-exchange-west-village', name: 'Raider Exchange', venue: 'West Village', buildingId: null, hours: 'Mo-Fr 10:00-21:00; Sa-Su 11:00-21:00', concepts: [] },
  { id: 'sam-s-place-student-union-building', name: 'Sam\'s Place', venue: 'Student Union Building', buildingId: 'student-union', hours: 'Mo-Th 08:00-21:00; Fr 08:00-20:00; Su 12:00-18:00', concepts: [] },
  { id: 'sam-s-express-holden-hall', name: 'Sam\'s Express', venue: 'Holden Hall', buildingId: 'holden-hall', hours: 'Mo-Th 07:30-14:30', concepts: [] },
  { id: 'sam-s-express-the-library', name: 'Sam\'s Express', venue: 'The Library', buildingId: 'texas-tech-university-library', hours: 'Mo-Th 08:00-16:00; Fr 08:00-13:00', concepts: [] },
  { id: 'chick-fil-a-student-union-building', name: 'Chick-fil-A', venue: 'Student Union Building', buildingId: 'student-union', hours: 'Mo-Fr 09:00-22:00; Sa 09:00-14:00', concepts: [] },
  { id: 'chick-fil-a-rawls-cob', name: 'Chick-fil-A', venue: 'Rawls CoB', buildingId: null, hours: 'Mo-Fr 10:30-21:00; Sa 11:00-19:00', concepts: [] },
  { id: 'chick-fil-a-wiggins-complex', name: 'Chick-fil-A', venue: 'Wiggins Complex', buildingId: 'wiggins-complex-dining-hall', hours: 'Mo-Sa 10:30-22:00', concepts: [] },
  { id: 'starbucks-student-union-building', name: 'Starbucks', venue: 'Student Union Building', buildingId: 'student-union', hours: 'Mo-Th 07:00-22:00; Fr 07:00-19:00; Sa 08:00-14:00', concepts: [] },
  { id: 'starbucks-honors-hall', name: 'Starbucks', venue: 'Honors Hall', buildingId: null, hours: 'Mo-Th 07:00-21:00; Fr 07:00-20:00; Sa-Su 09:00-21:00', concepts: [] },
  { id: 'einstein-bros-bagels-talkington-hall', name: 'Einstein Bros Bagels', venue: 'Talkington Hall', buildingId: 'j-t-and-margaret-talkington-reside', hours: 'Mo-Fr 07:00-15:00; Sa-Su 09:00-15:00', concepts: [] },
  { id: 'einstein-bros-bagels-rawls-cob', name: 'Einstein Bros Bagels', venue: 'Rawls CoB', buildingId: null, hours: 'Mo-Fr 07:30-15:00', concepts: [] },
  { id: 'fazoli-s-stangel-murdough-hall', name: 'Fazoli\'s', venue: 'Stangel/Murdough Hall', buildingId: 'stangel-murdough-residence-hall', hours: 'Mo-Th 11:00-21:00; Fr 11:00-19:00; Su 12:00-20:00', concepts: [] },
  { id: 'day-break-coffee-roasters-stangel-murdough-hall', name: 'Day Break Coffee Roasters', venue: 'Stangel/Murdough Hall', buildingId: 'stangel-murdough-residence-hall', hours: 'Mo-Th 07:00-17:00; Fr 07:00-15:00; Sa 11:00-15:00; Su 11:00-17:00', concepts: [] },
  { id: 'pizza-hut-student-union-building', name: 'Pizza Hut', venue: 'Student Union Building', buildingId: 'student-union', hours: 'Mo-Fr 10:00-16:00', concepts: [] },
  { id: 'raider-pit-bbq-student-union-building', name: 'Raider Pit BBQ', venue: 'Student Union Building', buildingId: 'student-union', hours: 'Mo-Fr 10:00-16:00', concepts: [] },
  { id: 'boar-s-head-deli-student-union-building', name: 'Boar\'s Head Deli', venue: 'Student Union Building', buildingId: 'student-union', hours: 'Mo-Fr 10:00-16:00', concepts: [] },
  { id: 'sub-to-go-student-union-building', name: 'SUB To Go', venue: 'Student Union Building', buildingId: 'student-union', hours: 'Mo-Fr 10:00-16:00', concepts: [] },
  { id: 'the-break-student-union-building', name: 'The Break', venue: 'Student Union Building', buildingId: 'student-union', hours: 'Mo-Fr 08:00-17:00', concepts: [] },
  { id: 'burkhart-cafe-burkhart-center', name: 'Burkhart Cafe', venue: 'Burkhart Center', buildingId: null, hours: 'Mo-Th 11:00-19:00; Fr 11:00-17:00', concepts: [] },
].map((d) => {
  const b = d.buildingId ? BUILDINGS.find((x) => x.id === d.buildingId) : null;
  return { ...d, walk: b ? b.walk : null, lat: b ? b.lat : null, lng: b ? b.lng : null };
});

const STUDY = BUILDINGS
  .filter((b) => b.kind === 'Library' || /commons|union/i.test(b.name))
  .sort((a, b) => a.walk - b.walk)
  .slice(0, 6)
  .map((b) => ({ ...b, buildingId: b.id }));

const RESOURCES = [
  { id: 'res1', name: 'Math Emporium Tutoring', kind: 'Academic · Free', buildingId: 'holden-hall' },
  { id: 'res2', name: 'Writing Center', kind: 'Academic · Free', buildingId: 'texas-tech-university-library' },
  { id: 'res3', name: 'Student Counseling Center', kind: 'Student Life · By appointment', buildingId: 'student-union' },
  { id: 'res4', name: 'IT Help Central', kind: 'Technology · Walk-in', buildingId: 'texas-tech-university-library' },
  /* Link-based resources: real answers to the practical questions an
     incoming student doesn't know to ask — how to get into a game,
     which gate, where to buy books. These live here (not only in
     Settings) because Get Help is where someone actually looks. Both
     verified real and current; TTU maintains them, so we link out
     rather than copy details that change. */
  { id: 'res5', name: 'Gameday in Raiderland', kind: 'Athletics · Gates, parking & shuttles',
    url: 'https://texastech.com/sports/2026/7/15/gameday-in-raiderland' },
  { id: 'res6', name: 'Raider Depot', kind: 'Bookstore · Textbooks & merch',
    url: 'https://www.depts.ttu.edu/bookstore/', buildingId: 'student-union' },
  { id: 'res7', name: 'Football Parking Map', kind: 'Athletics · Lots, ADA & Park & Ride',
    url: 'https://texastech.com/sports/2026/8/18/football-parking-map' },
];

/* REAL 2026 football schedule with actual dates, verified against
   live sports data. This replaces a hardcoded "next game" whose
   date was written as the literal string "Tomorrow" — which stayed
   frozen as "Tomorrow" forever once that game was played, showing
   students a game that had already happened. Storing real ISO
   dates means nextGame() recomputes against today every time, so
   it rolls over on its own and can never go stale that way again. */
const FOOTBALL_SCHEDULE = [
  { kickoff: '2026-09-05T18:00:00', opponent: 'Abilene Christian', homeAway: 'home', venue: 'Galaxy Stadium', buildingId: 'jones-att-stadium', result: 'W 33-10' },
  { kickoff: '2026-09-12T18:30:00', opponent: 'Oregon State', homeAway: 'away', venue: 'Reser Stadium', buildingId: null, result: null },
  { kickoff: '2026-09-18T19:00:00', opponent: 'Houston', homeAway: 'home', venue: 'Galaxy Stadium', buildingId: 'jones-att-stadium', result: null },
  { kickoff: '2026-09-26T12:00:00', opponent: 'Sam Houston', homeAway: 'home', venue: 'Galaxy Stadium', buildingId: 'jones-att-stadium', result: null },
  { kickoff: '2026-10-03T12:00:00', opponent: 'Colorado', homeAway: 'away', venue: 'Folsom Field', buildingId: null, result: null },
  { kickoff: '2026-10-17T12:00:00', opponent: 'Arizona State', homeAway: 'home', venue: 'Galaxy Stadium', buildingId: 'jones-att-stadium', result: null },
  { kickoff: '2026-10-24T12:00:00', opponent: 'Cincinnati', homeAway: 'away', venue: 'Nippert Stadium', buildingId: null, result: null },
  { kickoff: '2026-10-31T12:00:00', opponent: 'Arizona', homeAway: 'home', venue: 'Galaxy Stadium', buildingId: 'jones-att-stadium', result: null },
  { kickoff: '2026-11-07T12:00:00', opponent: 'West Virginia', homeAway: 'home', venue: 'Galaxy Stadium', buildingId: 'jones-att-stadium', result: null },
  { kickoff: '2026-11-14T12:00:00', opponent: 'Oklahoma State', homeAway: 'away', venue: 'Boone Pickens Stadium', buildingId: null, result: null },
  { kickoff: '2026-11-21T12:00:00', opponent: 'Baylor', homeAway: 'away', venue: 'McLane Stadium', buildingId: null, result: null },
  { kickoff: '2026-11-26T19:00:00', opponent: 'TCU', homeAway: 'home', venue: 'Galaxy Stadium', buildingId: 'jones-att-stadium', result: null },
];

/* The next game that hasn't kicked off yet — recomputed live, never
   stored. Returns null once the season is over rather than showing
   a stale final game as if it were upcoming. */
function nextGame(now = new Date()) {
  return FOOTBALL_SCHEDULE.find((g) => new Date(g.kickoff) > now) || null;
}

/* Most recent completed game with a real result, for showing what
   just happened rather than nothing at all. */
function lastGame(now = new Date()) {
  const played = FOOTBALL_SCHEDULE.filter((g) => new Date(g.kickoff) <= now && g.result);
  return played.length ? played[played.length - 1] : null;
}

function gameDateLabel(iso, now = new Date()) {
  const d = new Date(iso);
  const days = Math.round((d.setHours(0, 0, 0, 0) - new Date(now).setHours(0, 0, 0, 0)) / 86400000);
  const time = new Date(iso).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  if (days === 0) return `Today · ${time}`;
  if (days === 1) return `Tomorrow · ${time}`;
  const label = new Date(iso).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  return `${label} · ${time}`;
}

const SPORTS_LIST = ['Football', 'Basketball', "Women's Basketball", 'Baseball', 'Softball', 'Soccer', 'Volleyball', 'Track'];

/* Citibus real on-campus stops — a starter set, not a complete feed.
   Confirmed real stop names via Moovit/Transit app data for
   Citibus's "Red Raider" campus loop route, matched to buildings
   already in our real, verified BUILDINGS coordinates above rather
   than guessed. This is deliberately partial: Citibus publishes a
   full GTFS feed (confirmed real via Transitland) with every stop's
   exact coordinates and scheduled times, but the direct feed URL
   wasn't pinned down — this seed covers only the stops we could
   independently verify against real building data. Extend this
   once the full GTFS feed URL is confirmed. */
const BUS_STOPS = [
  { id: 'bus-holden', name: 'Holden Hall', buildingId: 'holden-hall', route: 'Red Raider' },
  { id: 'bus-west', name: 'West Hall', buildingId: 'west-hall', route: 'Red Raider' },
  { id: 'bus-library', name: 'Texas Tech University Library', buildingId: 'texas-tech-university-library', route: 'Red Raider' },
];

/* ============================================================
   WEATHER — real, live, no API key
   ------------------------------------------------------------
   Open-Meteo is a free public weather API that needs no key and
   no billing account, which matters for a student project with
   no backend. Fetched once on Home's mount, for the real campus
   coordinates. Falls back to a clearly-labeled placeholder if the
   request fails, rather than silently showing stale fake numbers.
   ============================================================ */
function weatherCodeToCondition(code) {
  if (code === 0) return 'Clear';
  if (code <= 2) return 'Mostly Sunny';
  if (code === 3) return 'Overcast';
  if (code <= 48) return 'Foggy';
  if (code <= 57) return 'Drizzle';
  if (code <= 67) return 'Rain';
  if (code <= 77) return 'Snow';
  if (code <= 82) return 'Showers';
  if (code <= 86) return 'Snow Showers';
  if (code >= 95) return 'Thunderstorms';
  return 'Clear';
}

/* Shared pattern for the Tavily-backed functions: call on mount
   (or when params change), track loading/error honestly, and
   never silently swallow a failure — callers get a real error
   message to show or fall back on, same discipline as everything
   else built tonight. */
/* ============================================================
   LOCAL NOTIFICATIONS
   ------------------------------------------------------------
   No backend involved — this reads data already in the app
   (today's real classes, real saved events) and schedules device
   notifications directly. Re-runs whenever the schedule or saved
   list changes, and always clears previously-scheduled RaiderLoop
   notifications first — otherwise editing a class time would leave
   a stale notification firing at the old time alongside a new one
   at the corrected time.
   ============================================================ */
function timeStringToDateToday(timeStr, offsetMinutes = 0) {
  const mins = toMinutes(timeStr);
  if (mins === null) return null;
  const d = new Date();
  d.setSeconds(0, 0);
  d.setHours(0, 0);
  d.setMinutes(mins - offsetMinutes);
  return d;
}

function useScheduleNotifications(scheduleItems, savedIds) {
  useEffect(() => {
    if (!Notifications) return;
    let cancelled = false;

    (async () => {
      const perm = await Notifications.getPermissionsAsync();
      let granted = perm.granted;
      if (!granted && perm.canAskAgain) {
        const req = await Notifications.requestPermissionsAsync();
        granted = req.granted;
      }
      if (!granted || cancelled) return;

      await Notifications.cancelAllScheduledNotificationsAsync();

      const todays = itemsOnDay(scheduleItems, todayCode());
      for (const item of todays) {
        const trigger = timeStringToDateToday(item.time, 15);
        if (!trigger || trigger.getTime() <= Date.now()) continue;
        await Notifications.scheduleNotificationAsync({
          content: { title: item.title, body: `Starts in 15 minutes${item.place ? ' · ' + item.place : ''}` },
          trigger,
        });
      }

      const saved = allEvents().filter((e) => savedIds.has(e.id) && /today|tonight/i.test(e.date || ''));
      for (const ev of saved) {
        const trigger = timeStringToDateToday(ev.time, 15);
        if (!trigger || trigger.getTime() <= Date.now()) continue;
        await Notifications.scheduleNotificationAsync({
          content: { title: ev.title, body: `Starts in 15 minutes${ev.room ? ' · ' + ev.room : ''}` },
          trigger,
        });
      }
    })();

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(scheduleItems), JSON.stringify([...savedIds])]);
}

/* Same pattern as useLiveData, but for endpoints that return a single
   value (like a URL or an object) rather than an array — forcing
   those into useLiveData's array coercion would silently break them. */
function useLiveValue(callable, params, resultKey) {
  const paramsKey = JSON.stringify(params || {});
  const [state, setState] = useState({ data: null, loading: true, error: null });

  useEffect(() => {
    let cancelled = false;
    setState({ data: null, loading: true, error: null });
    callable(params)
      .then((res) => {
        if (cancelled) return;
        const value = res && res.data && res.data[resultKey];
        setState({ data: value ?? null, loading: false, error: null });
      })
      .catch((e) => {
        if (cancelled) return;
        setState({ data: null, loading: false, error: (e && e.message) || 'Failed to load.' });
      });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paramsKey]);

  return state;
}

function useLiveData(callable, params, resultKey) {
  const paramsKey = JSON.stringify(params || {});
  const [state, setState] = useState({ data: null, loading: true, error: null });

  useEffect(() => {
    let cancelled = false;
    setState({ data: null, loading: true, error: null });
    callable(params)
      .then((res) => {
        if (cancelled) return;
        const value = res && res.data && res.data[resultKey];
        setState({ data: Array.isArray(value) ? value : [], loading: false, error: null });
      })
      .catch((e) => {
        if (cancelled) return;
        setState({ data: null, loading: false, error: (e && e.message) || 'Failed to load.' });
      });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paramsKey]);

  return state;
}

function useWeather() {
  const [state, setState] = useState({ temp: null, condition: null, city: 'Lubbock', loading: true, error: false });

  useEffect(() => {
    let cancelled = false;
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${CAMPUS_CENTER.latitude}&longitude=${CAMPUS_CENTER.longitude}&current=temperature_2m,weather_code&temperature_unit=fahrenheit&timezone=America%2FChicago`;
    fetch(url)
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        const cur = data && data.current;
        if (!cur) throw new Error('no current block');
        setState({
          temp: Math.round(cur.temperature_2m),
          condition: weatherCodeToCondition(cur.weather_code),
          city: 'Lubbock',
          loading: false,
          error: false,
        });
      })
      .catch(() => {
        if (!cancelled) setState((p) => ({ ...p, loading: false, error: true }));
      });
    return () => { cancelled = true; };
  }, []);

  return state;
}

const INTERESTS = ['Sports', 'Music', 'Arts', 'Technology', 'Gaming', 'Career', 'Faith', 'Academics', 'Campus Events'];
// One shared stroke-icon system — same 24x24 grid, same stroke
// weight, used for tabs, interest tags, save marks, and chevrons.
// Replaces the earlier mix of hand-drawn SVG + emoji + text glyphs,
// which read as three different visual languages stitched together.
const ICON_PATHS = {
  home: 'M3.5 10.2 12 3.5l8.5 6.7V20a1 1 0 0 1-1 1h-5v-6h-5v6h-5a1 1 0 0 1-1-1z',
  discover: 'M4 5.5h6.5v6.5H4zM13.5 5.5H20v4.2h-6.5zM4 15h6.5v3.5H4zM13.5 12.7H20v5.8h-6.5z',
  campus: 'M12 21s-6.5-5.4-6.5-10.2A6.5 6.5 0 0 1 18.5 10.8C18.5 15.6 12 21 12 21z',
  schedule: 'M4 6.5h16v14H4zM4 10.5h16M8.5 3.5v4M15.5 3.5v4',
  you: 'M12 11.5a3.6 3.6 0 1 0 0-7.2 3.6 3.6 0 0 0 0 7.2zM5 20.5c0-3.6 3.1-5.6 7-5.6s7 2 7 5.6',
  chevron: 'M9 5l7 7-7 7',
  starOutline: 'M12 3.5l2.55 5.4 5.95.6-4.45 4.05 1.25 5.85L12 16.4l-5.3 3-1.25-5.85-4.45-4.05 5.95-.6z',
  red: 'M4 5.5h16v10.5H8l-3 3.2v-3.2H4z',
  dining: 'M7 3v7a2 2 0 0 0 4 0V3M9 10v11M15 3c-1.2 0-2 1.5-2 4s.8 4 2 4v10',
  bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0',
  sun: 'M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10zM12 1.5v2M12 20.5v2M3.5 12h-2M22.5 12h-2M5.6 5.6 4.2 4.2M19.8 19.8l-1.4-1.4M18.4 5.6l1.4-1.4M4.2 19.8l1.4-1.4',
  Sports: 'M4 4h16v16H4zM4 12h16M12 4v16M6.5 6.5l3 3M17.5 17.5l-3-3M17.5 6.5l-3 3M6.5 17.5l3-3',
  Music: 'M9 18a2.2 2.2 0 1 1-2.2-2.2A2.2 2.2 0 0 1 9 18zM9 18V6l10-2v10M18 14a2.2 2.2 0 1 1-2.2-2.2A2.2 2.2 0 0 1 18 14z',
  Arts: 'M12 3a9 9 0 1 0 0 18c1.4 0 1.7-1.2.9-2s-.4-2.1 1-2.1H16a3.5 3.5 0 0 0 3.5-3.5C19.5 7.5 16.1 3 12 3zM7.5 12a1.2 1.2 0 1 1 0-2.4 1.2 1.2 0 0 1 0 2.4zM9.8 8.3a1.2 1.2 0 1 1 0-2.4 1.2 1.2 0 0 1 0 2.4zM14.3 8.3a1.2 1.2 0 1 1 0-2.4 1.2 1.2 0 0 1 0 2.4z',
  Technology: 'M4 5.5h16v10.5H4zM9 20h6M12 16v4',
  Gaming: 'M6 9h12l1.5 8a2 2 0 0 1-2 2.4c-1 0-1.7-.6-2-1.5L15 16H9l-.5 1.9c-.3.9-1 1.5-2 1.5A2 2 0 0 1 4.5 17zM8 11.5v3M6.5 13h3M15.3 12h.01M17.3 13.5h.01',
  Career: 'M4 8h16v11H4zM8 8V5.5A1.5 1.5 0 0 1 9.5 4h5A1.5 1.5 0 0 1 16 5.5V8M4 13h16',
  Faith: 'M12 3v18M6 8h12M8 21l4-13 4 13',
  Academics: 'M2 8l10-4 10 4-10 4zM6 10.5V16c0 1.4 2.7 3 6 3s6-1.6 6-3v-5.5M22 8v6.5',
  'Campus Events': 'M4 4.5h13l3 4-3 4H4zM4 4.5v15',
};

function Icon({ id, size = 20, color = '#000', strokeWidth = 2, fill }) {
  if (!Svg) return <View style={{ width: size, height: size, borderRadius: size / 2, borderWidth: 2, borderColor: color }} />;
  const d = ICON_PATHS[id];
  if (!d) return null;
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24">
      <Path d={d} stroke={color} strokeWidth={strokeWidth} fill={fill || 'none'} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

const RED_REPLIES = [
  { match: ['eat', 'food', 'hungry', 'lunch', 'dinner'], text: "Here's what's open near you.", buildingIds: ['student-union', 'student-recreation-center'] },
  { match: ['study', 'quiet', 'library'], text: 'Two study spots close by.', buildingIds: ['texas-tech-university-library', 'student-union'] },
  { match: ['club', 'organization', 'org', 'join'], text: 'A few organizations you might like.', orgIds: ['swe', 'rats', 'gaming'] },
  { match: ['tutor', 'help', 'resource', 'counseling'], text: 'Student resources that can help.', resourceIds: ['res1', 'res2', 'res3'] },
  /* Gameday and bookstore questions come up constantly and have real,
     official answers TTU maintains — better to point at those than to
     let a live search paraphrase details that change game to game. */
  { match: ['gate', 'get in the game', 'get into the game', 'stadium', 'bag policy', 'gameday', 'game day'],
    text: "Gates, bag policy, and entry are all in Texas Tech's own gameday guide. Student entry uses Red Raider Loyalty in the Red Raiders app, and you'll need your student ID.",
    resourceIds: ['res5'] },
  { match: ['parking', 'park', "can't find parking", 'lot', 'shuttle'],
    text: "Football parking lots open at 7:30 a.m. on game days, and Citibus runs a shuttle from the free fan parking areas starting three hours before kickoff. The full map has lot categories and ADA info.",
    resourceIds: ['res7'] },
  { match: ['textbook', 'book', 'bookstore', 'merch', 'apparel', 'shirt'],
    text: 'Raider Depot is the official campus bookstore — west side of the Student Union. Textbooks, course materials, and official merch are all there.',
    resourceIds: ['res6'] },
  { match: ['thank', 'thanks'], text: "Anytime — that's what I'm here for." },
  { match: ['bye', 'goodbye', 'see you'], text: 'Later, Red Raider.' },
  { match: ['hi', 'hello', 'hey'], text: "Hey — I'm Red. Ask what's happening tonight, or where your next class is." },
];

const RED_SUGGESTIONS = [
  "What's happening tonight?",
  'Where is my next class?',
  "What's the weather like?",
  'Where can I study?',
];

function toMinutes(t) {
  if (!t) return null;
  const m = t.match(/(\d+):(\d+)\s*(AM|PM)/i);
  if (!m) return null;
  let h = parseInt(m[1], 10);
  const min = parseInt(m[2], 10);
  if (/pm/i.test(m[3]) && h !== 12) h += 12;
  if (/am/i.test(m[3]) && h === 12) h = 0;
  return h * 60 + min;
}
function overlaps(aS, aE, bS, bE) {
  const v = [aS, aE, bS, bE].map(toMinutes);
  if (v.some((x) => x === null)) return false;
  return v[0] < v[3] && v[2] < v[1];
}
function allEvents() { const f = featuredEvent(); return f ? [f, ...EVENTS] : [...EVENTS]; }
function eventById(id) { return allEvents().find((e) => e.id === id); }

/* A real, working action: hands off to the device's own Maps app
   rather than faking turn-by-turn we can't actually build here. */
function openDirections(building) {
  if (!building) return;
  const label = encodeURIComponent(building.name);
  const url = Platform.select({
    ios: `maps://?daddr=${building.lat},${building.lng}&q=${label}`,
    android: `google.navigation:q=${building.lat},${building.lng}(${label})`,
    default: `https://www.google.com/maps/dir/?api=1&destination=${building.lat},${building.lng}`,
  });
  Linking.openURL(url).catch(() => {
    Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${building.lat},${building.lng}`);
  });
}

const MAP_STYLE_LIGHT = [
  { elementType: 'geometry', stylers: [{ color: '#FBF8F5' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#716660' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#FBF8F5' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#F0E8E1' }] },
  { featureType: 'poi', elementType: 'geometry', stylers: [{ color: '#F5EFEA' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#E7E1D3' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#E1D9D3' }] },
  { featureType: 'poi.business', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit', stylers: [{ visibility: 'off' }] },
];
const MAP_STYLE_DARK = [
  { elementType: 'geometry', stylers: [{ color: '#121011' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#9B918C' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#121011' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#262223' }] },
  { featureType: 'poi', elementType: 'geometry', stylers: [{ color: '#1D1A1B' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#181516' }] },
  { featureType: 'poi.business', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit', stylers: [{ visibility: 'off' }] },
];

/* ============================================================
   STATE
   ============================================================ */

const AppContext = createContext(null);
const useApp = () => useContext(AppContext);

function AppProvider({ children }) {
  const [savedIds, setSavedIds] = useState(new Set());
  const [followedOrgIds, setFollowedOrgIds] = useState(new Set());
  const [orgDetailId, setOrgDetailId] = useState(null);
  const [infoSheet, setInfoSheet] = useState(null);
  const [scheduleItems, setScheduleItems] = useState(SCHEDULE_SEED);
  const [selectedBuildingId, setSelectedBuildingId] = useState(null);
  const [interests, setInterests] = useState([]);
  const [onboarded, setOnboarded] = useState(false);
  const [onboardStep, setOnboardStep] = useState('signin'); // signin | welcome | profile | interests | schedule | confirm
  const [userName, setUserName] = useState('');
  const [userMajor, setUserMajor] = useState('');
  const [userClassYear, setUserClassYear] = useState('');
  const [isGuest, setIsGuest] = useState(false);
  const [tab, setTab] = useState('home');
  const [detailId, setDetailId] = useState(null);
  const [conflict, setConflict] = useState(null);
  const [redOpen, setRedOpen] = useState(false);
  const [quietDay, setQuietDay] = useState(false);
  const [discoverCategory, setDiscoverCategory] = useState(null);
  const [liveDetailEvent, setLiveDetailEvent] = useState(null);
  const [pendingRedQuestion, setPendingRedQuestion] = useState(null);
  const [hydrated, setHydrated] = useState(false);

  /* Load once on mount. Without AsyncStorage installed, or on a
     first-ever launch with nothing saved yet, this just marks
     hydrated immediately and the app starts fresh — same as
     before persistence existed. A corrupt/unreadable value is
     treated the same way rather than crashing the app on launch. */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!AsyncStorage) { setHydrated(true); return; }
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw && !cancelled) {
          const data = JSON.parse(raw);
          if (typeof data.userName === 'string') setUserName(data.userName);
          if (typeof data.userMajor === 'string') setUserMajor(data.userMajor);
          if (typeof data.userClassYear === 'string') setUserClassYear(data.userClassYear);
          if (typeof data.isGuest === 'boolean') setIsGuest(data.isGuest);
          if (Array.isArray(data.interests)) setInterests(data.interests);
          if (typeof data.onboarded === 'boolean') setOnboarded(data.onboarded);
          if (Array.isArray(data.scheduleItems)) setScheduleItems(data.scheduleItems);
          if (Array.isArray(data.savedIds)) setSavedIds(new Set(data.savedIds));
        }
      } catch (e) {
        // Unreadable/corrupt storage — start fresh rather than crash.
      }
      if (!cancelled) setHydrated(true);
    })();
    return () => { cancelled = true; };
  }, []);

  /* Save on every meaningful change, once initial load has
     finished — saving before hydration completes would overwrite
     real stored data with the empty defaults every state starts
     at. */
  useEffect(() => {
    if (!hydrated || !AsyncStorage) return;
    const blob = {
      userName, userMajor, userClassYear, isGuest, interests, onboarded,
      scheduleItems, savedIds: Array.from(savedIds),
    };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(blob)).catch(() => {});
  }, [hydrated, userName, userMajor, userClassYear, isGuest, interests, onboarded, scheduleItems, savedIds]);

  const toggleSave = (id) => setSavedIds((p) => {
    const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n;
  });
  const toggleFollow = (id) => setFollowedOrgIds((p) => {
    const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n;
  });

  const addToSchedule = (ev, { force = false } = {}) => {
    if (!force) {
      const clash = scheduleItems.find((i) => overlaps(i.time, i.endTime || i.time, ev.time, ev.endTime || ev.time));
      if (clash) { setConflict({ incoming: ev, existing: clash }); return; }
    }
    setScheduleItems((p) => [...p, {
      id: `sch-${ev.id}`, time: ev.time, endTime: ev.endTime, title: ev.title,
      place: `${buildingById(ev.buildingId)?.name || ''} · ${ev.room}`,
      type: 'event', buildingId: ev.buildingId,
      // One-off event, not a recurring class — tagged to today only so
      // it doesn't silently become "every day" under itemsOnDay's
      // missing-days fallback.
      days: [todayCode()],
    }].sort((a, b) => toMinutes(a.time) - toMinutes(b.time)));
  };

  const addClass = (cls) => {
    setScheduleItems((p) => [...p, { ...cls, id: `cls-${Date.now()}` }]
      .sort((a, b) => toMinutes(a.time) - toMinutes(b.time)));
  };
  const updateClass = (id, cls) => {
    setScheduleItems((p) => p.map((i) => (i.id === id ? { ...i, ...cls } : i))
      .sort((a, b) => toMinutes(a.time) - toMinutes(b.time)));
  };
  const removeClass = (id) => setScheduleItems((p) => p.filter((i) => i.id !== id));
  const replaceSchedule = (items) => setScheduleItems(items);

  /* Real reset, not just a UI trick — clears everything onboarding
     sets so the flow can be re-tested honestly, including the
     tour, rather than skipping straight back to Home because
     persisted state still says onboarded. */
  const resetOnboarding = () => {
    setOnboarded(false);
    setIsGuest(false);
    setUserName('');
    setUserMajor('');
    setUserClassYear('');
    setInterests([]);
    setOnboardStep('signin');
    setScheduleItems(SCHEDULE_SEED);
    setSavedIds(new Set());
  };

  const goToBuilding = (id) => { setSelectedBuildingId(id); setDetailId(null); setTab('campus'); };

  return (
    <AppContext.Provider value={{
      savedIds, toggleSave, scheduleItems, addToSchedule,
      addClass, updateClass, removeClass, replaceSchedule, resetOnboarding,
      followedOrgIds, toggleFollow, orgDetailId, setOrgDetailId, infoSheet, setInfoSheet,
      selectedBuildingId, setSelectedBuildingId, goToBuilding,
      interests, setInterests, onboarded, setOnboarded,
      onboardStep, setOnboardStep,
      userName, setUserName, userMajor, setUserMajor, userClassYear, setUserClassYear,
      isGuest, setIsGuest,
      tab, setTab, detailId, setDetailId, conflict, setConflict,
      redOpen, setRedOpen, quietDay, setQuietDay,
      discoverCategory, setDiscoverCategory, pendingRedQuestion, setPendingRedQuestion,
      liveDetailEvent, setLiveDetailEvent,
      hydrated,
    }}>{children}</AppContext.Provider>
  );
}

/* ============================================================
   MATERIAL — Raider Glass + Raider Bleed
   ------------------------------------------------------------
   Bleed intensity carries hierarchy, per the brief:
     2  featured content
     1  secondary content
     0  utility tiles (no bleed at all)
   ============================================================ */

let bleedId = 0;

function Bleed({ t, intensity = 1, corner = 'topRight' }) {
  const id = useRef(`bl${bleedId++}`).current;
  if (!intensity || !Svg) return null;
  const peak = intensity === 2 ? 0.30 : 0.15;
  const pos = {
    topRight: { cx: '88%', cy: '4%' },
    topLeft: { cx: '12%', cy: '4%' },
    bottomRight: { cx: '92%', cy: '96%' },
    bottomLeft: { cx: '8%', cy: '96%' },
  }[corner];

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Svg width="100%" height="100%">
        <Defs>
          <RadialGradient id={id} cx={pos.cx} cy={pos.cy} r="78%">
            <Stop offset="0%" stopColor={t.bleedWarm} stopOpacity={peak} />
            <Stop offset="38%" stopColor={t.red} stopOpacity={peak * 0.62} />
            <Stop offset="100%" stopColor={t.red} stopOpacity="0" />
          </RadialGradient>
        </Defs>
        <Rect x="0" y="0" width="100%" height="100%" fill={`url(#${id})`} />
      </Svg>
    </View>
  );
}

/* Small walking figure — used next to walk-time distances so the
   number reads at a glance instead of requiring the word "walk". */
function WalkGlyph({ color = '#000', size = 13 }) {
  if (!Svg) return null;
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" style={{ marginRight: 5 }}>
      <Circle cx="14" cy="4.5" r="2.2" fill={color} />
      <Path d="M13 8 L9 11 L10 16 L8 21 M13 8 L16 10 L15 14 L18 17 M9 11 L14 12"
        stroke={color} strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

/* An animated pulsing dot — used wherever something is happening
   live or imminently, so it reads as active rather than static. */
function LiveDot({ color, size = 7 }) {
  const pulse = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: 850, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: 850, easing: Easing.in(Easing.quad), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, []);
  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.7] });
  const opacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.85, 0.1] });
  return (
    <View style={{ width: size * 2, height: size * 2, alignItems: 'center', justifyContent: 'center', marginRight: 7 }}>
      <Animated.View style={{ position: 'absolute', width: size * 2, height: size * 2, borderRadius: size, backgroundColor: color, transform: [{ scale }], opacity }} />
      <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color }} />
    </View>
  );
}

function CalendarGlyph({ color, size = 16 }) {
  return <Icon id="schedule" size={size} color={color} strokeWidth={2} />;
}

/* ============================================================
   RAIDER GLASS — levitating material
   ------------------------------------------------------------
   Cards should read as objects floating above the canvas, not
   panels resting on it. Four things together do that:

   1. DETACHED SHADOW. A contact shadow (tight, dark, hugging the
      base) is what makes something look like it's sitting on a
      surface. We do the opposite — as lift rises, the shadow
      pushes further down and gets softer and fainter, so a
      visible gap opens between the card and its shadow. That gap
      is the whole illusion.

   2. TIERED HEIGHT. lift={2} hero cards float highest and get
      the full treatment. lift={1} sits closer. lift={0} utility
      rows are static and cheap — no glow, no motion. This is a
      performance requirement as much as a design one: Campus
      lists 213 buildings, and animating every row would be a
      real problem on device.

   3. ASYNC DRIFT. Each floating card bobs on its own randomized
      phase and duration, seeded once at mount. If they all
      shared a rhythm it would read as a synchronized machine
      rather than independent objects in the air.

   4. PRESS-DESCEND. Pressing pushes the card down toward the
      canvas and shrinks its shadow — it "lands" — then springs
      back up on release. Reads as pulling something out of the
      air rather than squishing it into a table.

   Deliberately NOT here: rotation, scroll-velocity inertia,
   edge-tilt, depth-sorted shadow tint. Each is defensible alone,
   but stacking them guarantees something looks wrong, and this
   is being written without a device to check against.
   ============================================================ */

/* Per-lift shadow shape. Note offset grows while opacity falls —
   further away, fainter, softer, which is how real cast shadows
   behave as an object rises. */
const LIFT_SHADOW = {
  0: { opacity: 0.9, radius: 8,  offsetY: 3,  elevation: 2 },
  1: { opacity: 1.3, radius: 20, offsetY: 12, elevation: 5 },
  2: { opacity: 1.5, radius: 34, offsetY: 24, elevation: 9 },
};

/* Only hero-tier cards drift. lift={1} keeps its detached shadow
   and press-descend but stays still: Row defaults to lift=1, and
   Campus renders 213 of them — 213 concurrent animation loops is a
   real performance problem, not a theoretical one. */
const DRIFT_PX = { 0: 0, 1: 0, 2: 5 };

function Glass({
  s, t, children, style, onPress, radius = 20, lift = 1,
  bleed = 0, bleedCorner = 'topRight', ring, tint, glow,
}) {
  const cfg = LIFT_SHADOW[lift] || LIFT_SHADOW[1];

  // Seeded once per card so drift is stable across re-renders but
  // differs between cards. Math.random() inline would re-roll on
  // every render and make the motion jitter.
  const seed = useRef({
    phase: Math.random(),
    duration: 4200 + Math.random() * 2600,
  }).current;

  const drift = useRef(new Animated.Value(0)).current;
  const press = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!DRIFT_PX[lift]) return;
    let cancelled = false;
    const run = () => {
      if (cancelled) return;
      Animated.sequence([
        Animated.timing(drift, { toValue: 1, duration: seed.duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(drift, { toValue: 0, duration: seed.duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ]).start(({ finished }) => { if (finished) run(); });
    };
    // Stagger the start so cards never fall into lockstep.
    const t0 = setTimeout(run, seed.phase * seed.duration);
    return () => { cancelled = true; clearTimeout(t0); };
  }, [lift]);

  const amp = DRIFT_PX[lift] || 0;
  const floatY = drift.interpolate({ inputRange: [0, 1], outputRange: [amp / 2, -amp / 2] });
  const pressY = press.interpolate({ inputRange: [0, 1], outputRange: [0, amp ? 6 : 3] });
  const translateY = Animated.add(floatY, pressY);

  // Shadow tightens as the card descends under the finger.
  const shadowRadius = press.interpolate({ inputRange: [0, 1], outputRange: [cfg.radius, cfg.radius * 0.45] });
  const shadowOffsetY = press.interpolate({ inputRange: [0, 1], outputRange: [cfg.offsetY, cfg.offsetY * 0.35] });

  const springTo = (v) => Animated.spring(press, {
    toValue: v, useNativeDriver: false, damping: 15, stiffness: 220, mass: 0.5,
  }).start();

  const W = onPress ? Pressable : View;
  const pressHandlers = onPress
    ? { onPressIn: () => springTo(1), onPressOut: () => springTo(0) }
    : {};

  return (
    <View style={style}>
      {/* Light pooling on the canvas beneath a floating card —
          a bloom, not a shadow. Reuses the Bleed gradient stack. */}
      {glow && lift === 2 ? <FloatGlow t={t} radius={radius} /> : null}

      <Animated.View
        style={{
          borderRadius: radius,
          shadowColor: t.shadow,
          shadowOpacity: t.shadowOpacity * cfg.opacity,
          shadowRadius,
          shadowOffset: { width: 0, height: shadowOffsetY },
          elevation: cfg.elevation,
          transform: [{ translateY }],
        }}
      >
        <W
          onPress={onPress}
          {...pressHandlers}
          style={{
            borderRadius: radius,
            backgroundColor: tint || t.surface,
            borderWidth: tint ? 0 : ring ? 1.4 : 0.5,
            borderColor: ring || t.border,
            overflow: 'hidden',
          }}
        >
          {!tint ? <Bleed t={t} intensity={bleed} corner={bleedCorner} /> : null}
          {/* Rim light — a hairline along the top edge, where a
              raised object would catch the most light. */}
          {!tint ? (
            <View pointerEvents="none" style={{
              position: 'absolute', top: 0, left: radius * 0.6, right: radius * 0.6,
              height: 1, backgroundColor: t.rim,
            }} />
          ) : null}
          <View>{children}</View>
        </W>
      </Animated.View>
    </View>
  );
}

/* Warm bloom on the canvas under a levitating card. Sits behind
   the card and slightly inset, so it reads as light spilling out
   from underneath rather than an outline around it. */
function FloatGlow({ t, radius }) {
  const id = useRef(`fg${bleedId++}`).current;
  if (!Svg) return null;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 10, right: 10, top: 18, bottom: -14 }}>
      <Svg width="100%" height="100%">
        <Defs>
          <RadialGradient id={id} cx="50%" cy="70%" r="62%">
            <Stop offset="0%" stopColor={t.bleedWarm} stopOpacity={t.mode === 'dark' ? 0.30 : 0.20} />
            <Stop offset="55%" stopColor={t.red} stopOpacity={t.mode === 'dark' ? 0.14 : 0.09} />
            <Stop offset="100%" stopColor={t.red} stopOpacity="0" />
          </RadialGradient>
        </Defs>
        <Rect x="0" y="0" width="100%" height="100%" rx={radius} fill={`url(#${id})`} />
      </Svg>
    </View>
  );
}

/* Frosted, blurred surfaces for the nav bar and modal backdrops —
   real translucency instead of a flat opaque card / dark rectangle.
   Rendered as an absolute-fill layer behind existing content rather
   than swapping element types, so it drops in without touching any
   JSX structure elsewhere. No-ops cleanly if expo-blur isn't
   installed. */
function BlurFill({ t, style }) {
  if (!BlurView) return null;
  return (
    <BlurView
      intensity={t.mode === 'dark' ? 50 : 40}
      tint={t.mode}
      style={style || StyleSheet.absoluteFill}
      pointerEvents="none"
    />
  );
}

function SectionLabel({ s, children, action, onAction }) {
  return (
    <View style={s.sectionHead}>
      <Text style={s.sectionLabel}>{children}</Text>
      {action ? <Pressable onPress={onAction} hitSlop={8}><Text style={s.sectionAction}>{action}</Text></Pressable> : null}
    </View>
  );
}

function Pill({ s, t, label, active, onPress }) {
  return (
    <Pressable onPress={onPress} style={[s.pill, active && { backgroundColor: t.red, borderColor: t.red }]}>
      <Text style={[s.pillText, active && { color: t.onRed }]}>{label}</Text>
    </Pressable>
  );
}

/* One continuous rounded container with thin dividers between rows —
   only the outer corners round, matching native Settings-style
   grouped lists instead of five separate floating cards. */
function GroupedList({ s, t, items }) {
  return (
    <View style={[s.groupedList, { shadowColor: t.shadow, shadowOpacity: t.shadowOpacity * 0.9, shadowRadius: 9, shadowOffset: { width: 0, height: 3 }, elevation: 2 }]}>
      {items.map((item, i) => (
        <Pressable key={item.title} onPress={item.onPress} style={[s.groupedRow, i < items.length - 1 && s.groupedRowDivider]}>
          <View style={{ flex: 1 }}>
            <Text style={s.rowTitle}>{item.title}</Text>
            {item.meta ? <Text style={s.rowMeta}>{item.meta}</Text> : null}
          </View>
          {item.right !== undefined ? item.right : <Icon id="chevron" size={16} color={t.textFaint} strokeWidth={2.2} />}
        </Pressable>
      ))}
    </View>
  );
}

function Row({ s, t, title, meta, note, right, onPress }) {
  /* The chevron is an affordance — it tells someone "this opens
     something." Showing it on a row with no onPress (like the
     dining vendor list) promises an action that doesn't exist,
     which reads as broken rather than informative. */
  return (
    <Glass s={s} t={t} onPress={onPress} style={{ marginBottom: 9 }}>
      <View style={s.rowInner}>
        <View style={{ flex: 1 }}>
          <Text style={s.rowTitle}>{title}</Text>
          {meta ? <Text style={s.rowMeta}>{meta}</Text> : null}
          {note ? <Text style={s.rowNote}>{note}</Text> : null}
        </View>
        {right !== undefined ? right : (onPress ? <Icon id="chevron" size={16} color={t.textFaint} strokeWidth={2.2} /> : null)}
      </View>
    </Glass>
  );
}

function TabGlyph({ t, id, active }) {
  const c = active ? t.red : t.textFaint;
  const sw = active ? 2.2 : 1.8;
  if (!Svg) return <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: c }} />;
  return (
    <Svg width={22} height={22} viewBox="0 0 24 24">
      <Path d={ICON_PATHS[id]} stroke={c} strokeWidth={sw} fill="none" strokeLinejoin="round" strokeLinecap="round" />
      {id === 'campus' ? <Circle cx="12" cy="10.5" r="2.3" stroke={c} strokeWidth={sw} fill="none" /> : null}
    </Svg>
  );
}

/* ============================================================
   HOME — the front door
   ------------------------------------------------------------
   Deliberately conventional. Section 3 of the brief: this is the
   screen students return to all day, so it must be immediately
   legible. The material does the distinguishing, not the layout.
   Curated, not comprehensive — Campus Update only appears when
   there is genuinely something to say, and weather sits inline
   with the greeting rather than claiming a card of its own.
   ============================================================ */

function HomeScreen({ s, t }) {
  const { scheduleItems, goToBuilding, userName, isGuest, setInfoSheet } = useApp();
  const weather = useWeather();
  const alertsData = useLiveData(callGetCampusAlerts, {}, 'alerts');
  const alerts = alertsData.data || [];
  const now = new Date();
  const nowM = now.getHours() * 60 + now.getMinutes();
  const hour = now.getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const dateLabel = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  const firstName = isGuest ? 'Guest' : (userName.trim().split(' ')[0] || 'Red Raider');

  const day = useMemo(
    () => itemsOnDay(scheduleItems, todayCode()).sort((a, b) => toMinutes(a.time) - toMinutes(b.time)),
    [scheduleItems]
  );
  const next = day.find((i) => (toMinutes(i.time) ?? 0) >= nowM);
  const minsUntil = next ? (toMinutes(next.time) ?? 0) - nowM : null;
  const building = next ? buildingById(next.buildingId) : null;

  // Real, live headlines via Tavily — this is what should have
  // replaced the static NEWS snapshot from earlier tonight and
  // didn't, until now. Falls back to that snapshot only if the
  // live fetch comes back empty or fails, so there's still real
  // (if dated) content rather than a blank feed.
  const liveNews = useLiveData(callGetNews, {}, 'news');
  const newsSource = (liveNews.data && liveNews.data.length) ? liveNews.data : NEWS;
  const newsWithIds = newsSource.map((n, i) => ({ ...n, id: n.id || `news-${i}` }));
  const [hero, ...rest] = newsWithIds;

  return (
    <ScrollView style={s.screen} contentContainerStyle={s.screenContent} showsVerticalScrollIndicator={false}>
      {/* GREETING — real name and date from onboarding, weather
          inline beneath it. Notifications bell is honest: there's
          no real notification system yet, so it opens the same
          plain explanation the You screen's settings already use. */}
      <View style={s.greetRow}>
        <View style={{ flex: 1 }}>
          <Text style={s.greetTitle}>{greeting}, {firstName}</Text>
          <Text style={s.greetDate}>{dateLabel}</Text>
          <View style={s.greetWeatherRow}>
            <Icon id="sun" size={13} color={t.gold} strokeWidth={1.9} />
            <Text style={s.greetWeatherText}>
              {weather.loading
                ? 'Loading weather…'
                : weather.error
                  ? `${weather.city} · weather unavailable`
                  : `${weather.city} · ${weather.temp}°F · ${weather.condition}`}
            </Text>
          </View>
        </View>
        <Pressable style={s.bellBtn} onPress={() => setInfoSheet('Notifications')}>
          <Icon id="bell" size={19} color={t.textMuted} strokeWidth={1.8} />
        </Pressable>
      </View>

      {/* NEXT UP — dark glass rather than solid Scarlet, with a
          location line and a real, honest action row. The reference
          image showed three actions (View Location / Open Map /
          Navigate) — View Location and Open Map would do the exact
          same thing here (jump to Campus), so that's collapsed to
          two real, distinct actions rather than padding to three. */}
      {next ? (
        <Glass s={s} t={t} radius={22} lift={2} tint={t.canvasDeep} glow style={{ marginTop: 22 }}>
          <View style={s.nextDarkInner}>
            <Text style={s.nextDarkKicker}>NEXT UP</Text>
            <Text style={s.nextDarkTitle}>{next.title}</Text>
            <View style={s.nextDarkLocRow}>
              <Icon id="campus" size={13} color={t.textMuted} strokeWidth={1.8} />
              <Text style={s.nextDarkLocText}>{next.time} · {building?.name || next.place}</Text>
            </View>
            {minsUntil !== null && minsUntil >= 0 && minsUntil < 180 ? (
              <Text style={s.nextDarkCountdown}>
                {minsUntil === 0 ? 'Starting now' : `Starts in ${minsUntil} minutes`}
              </Text>
            ) : null}

            <View style={s.nextDarkDivider} />

            <View style={s.nextDarkActions}>
              <Pressable style={s.nextDarkAction} onPress={() => goToBuilding(next.buildingId)}>
                <Icon id="campus" size={15} color={t.text} strokeWidth={1.8} />
                <Text style={s.nextDarkActionText}>Open Map</Text>
              </Pressable>
              <Pressable style={s.nextDarkAction} onPress={() => openDirections(building)}>
                <WalkGlyph color={t.text} size={15} />
                <Text style={s.nextDarkActionText}>Navigate</Text>
              </Pressable>
            </View>
          </View>
        </Glass>
      ) : null}

      {/* CAMPUS ALERTS — real, live, via Tavily. Only renders when
          something real turns up; an empty list is the correct,
          honest state most of the time, not a placeholder to fill. */}
      {alerts.length ? alerts.map((a, i) => (
        <Glass key={i} s={s} t={t} radius={18} lift={0} style={{ marginTop: 14 }}>
          <View style={s.updateInner}>
            <Text style={s.updateTitle}>{a.title}</Text>
            <Text style={s.updateBody}>{a.body}</Text>
            <Text style={s.updateSource}>{a.source}</Text>
          </View>
        </Glass>
      )) : null}

      {/* IN THE LOOP — the actual reason to open the app daily.
          First story runs as a full hero; the rest fall into a
          compact list, the way a real news app leads with one
          story and lets the rest be scanned quickly. */}
      <View style={{ marginTop: 30 }}>
        <SectionLabel s={s}>IN THE LOOP</SectionLabel>
      </View>

      {hero ? (
        <Pressable onPress={() => Linking.openURL(hero.url)}>
          <Glass s={s} t={t} radius={20} lift={1} style={{ marginBottom: 12 }}>
            <SafeImage uri={hero.art} fallback={IMG.library} style={{ width: '100%', height: 150 }} />
            <View style={s.newsHeroBody}>
              <Text style={s.newsHeadline}>{hero.headline}</Text>
              <Text style={hero.official ? s.newsSourceOfficial : s.newsSourceText}>
                {hero.official ? 'Daily Toreador' : hero.source}
              </Text>
              <Text style={s.newsExcerpt} numberOfLines={2}>{hero.excerpt}</Text>
            </View>
          </Glass>
        </Pressable>
      ) : null}

      {rest.map((n) => (
        <Pressable key={n.id} onPress={() => Linking.openURL(n.url)}>
          <Glass s={s} t={t} radius={16} lift={0} style={{ marginBottom: 10 }}>
            <View style={s.newsRow}>
              <SafeImage uri={n.art} fallback={IMG.library} style={s.newsRowThumb} />
              <View style={{ flex: 1 }}>
                <Text style={s.newsRowTitle} numberOfLines={2}>{n.headline}</Text>
                <Text style={n.official ? s.newsSourceOfficial : s.newsSourceText}>
                  {n.official ? 'Daily Toreador' : n.source}
                </Text>
              </View>
            </View>
          </Glass>
        </Pressable>
      ))}
    </ScrollView>
  );
}


/* ============================================================
   DISCOVER — THE RAIDER GRID
   ------------------------------------------------------------
   Section 9 of the brief is the load-bearing rule here: tiles
   must not all be "rounded rectangle + icon + gradient + text."
   The content type decides the tile's internal structure.

     Featured      large type, strong bleed, save affordance
     Tonight       a count, time-oriented
     Sports        next fixture, scoreboard-ish framing
     Dining        utility — status dots, open/closed, no bleed
     Organizations a collection — stacked initials marks
     Study         utility — availability first
     Arts          editorial, minimal
     Resources     plain, calm, no decoration

   Selecting a tile expands it in place (section 12) rather than
   pushing a new screen.
   ============================================================ */

/* A real linear gradient (not a stacked-opacity hack) so text sits
   legibly over a photo without flattening the image underneath. */
/* Images fetched from live search sometimes point at URLs that
   don't actually resolve — the news hero rendered as blank space on
   device for exactly this reason. React Native's Image gives no
   visual feedback on failure, so this catches onError and swaps in
   a known-good fallback rather than leaving a hole in the layout. */
function SafeImage({ uri, fallback, style, resizeMode = 'cover' }) {
  const [failed, setFailed] = useState(false);
  const src = failed || !uri ? fallback : uri;
  if (!src) return null;
  return (
    <Image
      source={{ uri: src }}
      style={style}
      resizeMode={resizeMode}
      onError={() => setFailed(true)}
    />
  );
}

function PhotoOverlay({ strength = 0.72 }) {
  if (!Svg) {
    return <View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: `rgba(0,0,0,${strength * 0.6})` }]} />;
  }
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Svg width="100%" height="100%">
        <Defs>
          <LinearGradient id="photoFade" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#000000" stopOpacity="0" />
            <Stop offset="0.45" stopColor="#000000" stopOpacity="0" />
            <Stop offset="1" stopColor="#000000" stopOpacity={strength} />
          </LinearGradient>
        </Defs>
        <Rect x="0" y="0" width="100%" height="100%" fill="url(#photoFade)" />
      </Svg>
    </View>
  );
}

function TileFeatured({ s, t, ev, saved, onToggleSave, onOpen }) {
  return (
    <Glass s={s} t={t} radius={20} lift={2} glow onPress={onOpen} style={{ width: GRID_W, marginBottom: GAP }}>
      <View style={{ width: GRID_W, height: 200 }}>
        <SafeImage uri={ev.img} fallback={IMG.stadium} style={StyleSheet.absoluteFill} />
        <PhotoOverlay strength={0.8} />
        <View style={s.featInner}>
          <View style={s.featTopRow}>
            {ev.live ? (
              <View style={s.liveBadge}><View style={s.liveDot} /><Text style={s.liveBadgeText}>LIVE TONIGHT</Text></View>
            ) : (
              <Text style={s.featEyebrowPhoto}>{ev.date.toUpperCase()} · {ev.time}</Text>
            )}
            <Pressable onPress={onToggleSave} hitSlop={12}>
              <Icon id="starOutline" size={22} color={saved ? t.red : 'rgba(255,255,255,0.85)'} strokeWidth={1.8} fill={saved ? t.red : 'none'} />
            </Pressable>
          </View>
          <Text style={s.featTitlePhoto}>{ev.title}</Text>
          <Text style={s.featMetaPhoto}>{buildingById(ev.buildingId)?.name}</Text>
        </View>
      </View>
    </Glass>
  );
}

function TileTonight({ s, t, count, onOpen }) {
  return (
    <Glass s={s} t={t} radius={20} bleed={1} bleedCorner="topRight" onPress={onOpen}
      style={{ width: NARROW, marginBottom: GAP }}>
      <View style={s.tileTall}>
        <View style={s.tileIconRow}>
          <CalendarGlyph color={t.red} size={16} />
          <Text style={s.tileKicker}>TONIGHT</Text>
        </View>
        <Text style={s.bigNumber}>{count}</Text>
        <Text style={s.tileSub}>events after 5 PM</Text>
      </View>
    </Glass>
  );
}

function TileSports({ s, t, onOpen, img }) {
  const photo = img || IMG.stadium;
  const game = nextGame();
  const last = lastGame();
  return (
    <Glass s={s} t={t} radius={20} onPress={onOpen} style={{ width: WIDE, marginBottom: GAP }}>
      <View style={{ height: 148 }}>
        <SafeImage uri={photo} fallback={IMG.stadium} style={StyleSheet.absoluteFill} />
        <PhotoOverlay strength={0.75} />
        <View style={s.tileTallPhoto}>
          <Text style={s.tileKickerPhoto}>{game ? (game.homeAway === 'home' ? 'NEXT HOME GAME' : 'NEXT GAME') : 'LAST GAME'}</Text>
          <View style={s.sportsRow}>
            <Text style={s.sportsUsPhoto}>TTU</Text>
            <Text style={s.sportsVsPhoto}>{game ? (game.homeAway === 'home' ? 'vs' : '@') : 'vs'}</Text>
            <Text style={s.sportsThemPhoto}>{game ? game.opponent : last ? last.opponent : '—'}</Text>
          </View>
          <Text style={s.tileSubPhoto}>
            {game ? gameDateLabel(game.kickoff) : last ? last.result : 'Season complete'}
          </Text>
        </View>
      </View>
    </Glass>
  );
}

/* Utility tile: no bleed at all, per the hierarchy rule. */
function TileDining({ s, t, onOpen }) {
  const openCount = DINING.filter((d) => isOpenNow(d.hours) === true).length;
  return (
    <Glass s={s} t={t} radius={20} lift={0} onPress={onOpen}
      style={{ width: WIDE, marginBottom: GAP }}>
      <View style={s.tileUtility}>
        <View style={s.utilityHead}>
          <Image source={{ uri: IMG.dining }} style={s.diningThumb} resizeMode="cover" />
          <View style={{ flex: 1, marginLeft: 10 }}>
            <Text style={s.tileKicker}>DINING</Text>
            <Text style={s.utilityCount}>{openCount} open now</Text>
          </View>
        </View>
        {DINING.slice(0, 3).map((d) => (
          <View key={d.id} style={s.utilityLine}>
            <View style={[s.statusDot, { backgroundColor: isOpenNow(d.hours) === true ? t.ok : isOpenNow(d.hours) === false ? t.textFaint : t.borderStrong }]} />
            <Text style={s.utilityName} numberOfLines={1}>{d.name}</Text>
            <Text style={s.utilityDist}>{d.walk != null ? `${d.walk} min` : d.venue}</Text>
          </View>
        ))}
      </View>
    </Glass>
  );
}

function TileOrgs({ s, t, onOpen }) {
  return (
    <Glass s={s} t={t} radius={20} bleed={1} bleedCorner="bottomLeft" onPress={onOpen}
      style={{ width: NARROW, marginBottom: GAP }}>
      <View style={s.tileTall}>
        <Text style={s.tileKicker}>ORGS</Text>
        <View style={s.markStack}>
          {ORGS.slice(0, 4).map((o, i) => (
            <View key={o.id} style={[s.orgMark, { marginLeft: i === 0 ? 0 : -11, zIndex: 10 - i }]}>
              <Text style={s.orgMarkText}>{o.initials}</Text>
            </View>
          ))}
        </View>
        <Text style={s.tileSub}>{ORGS.length} to explore</Text>
      </View>
    </Glass>
  );
}

function TileStudy({ s, t, onOpen, width = HALF }) {
  return (
    <Glass s={s} t={t} radius={20} lift={0} bleed={0} onPress={onOpen}
      style={{ width, marginBottom: GAP }}>
      <View style={s.tileUtility}>
        <Text style={s.tileKicker}>STUDY SPACES</Text>
        {STUDY.map((x) => (
          <View key={x.id} style={{ marginTop: 9 }}>
            <Text style={s.utilityName} numberOfLines={1}>{x.name}</Text>
            <Text style={s.utilityFine}>{placeStatus(x)}</Text>
          </View>
        ))}
      </View>
    </Glass>
  );
}

function TileArts({ s, t, ev, onOpen }) {
  return (
    <Glass s={s} t={t} radius={20} onPress={onOpen} style={{ width: HALF, marginBottom: GAP }}>
      <View style={{ height: 148 }}>
        <Image source={{ uri: IMG.library }} style={StyleSheet.absoluteFill} resizeMode="cover" />
        <PhotoOverlay strength={0.7} />
        <View style={s.tileTallPhoto}>
          <Text style={s.tileKickerPhoto}>ARTS & CULTURE</Text>
          <Text style={s.artsTitlePhoto} numberOfLines={2}>{ev.title}</Text>
          <Text style={s.tileSubPhoto}>{ev.date} · {ev.time}</Text>
        </View>
      </View>
    </Glass>
  );
}

function TileResources({ s, t, onOpen }) {
  return (
    <Glass s={s} t={t} radius={20} lift={0} bleed={0} onPress={onOpen}
      style={{ width: GRID_W, marginBottom: GAP }}>
      <View style={s.resourceInner}>
        <View style={{ flex: 1 }}>
          <Text style={s.tileKicker}>GET HELP</Text>
          <Text style={s.resourceLine}>Tutoring, writing, counseling, IT</Text>
        </View>
        <Icon id="chevron" size={16} color={t.textFaint} strokeWidth={2.2} />
      </View>
    </Glass>
  );
}

/* Expanded view — section 12: the tile becomes the focus in
   place, rather than navigating away. */
/* Real detail for one dining location: full posted week hours and
   the real individual food concepts inside it, both from TTU
   Hospitality's own published data. The live backend lookup runs
   too, but only as a supplement for locations where we don't have
   published concepts — the real data leads, since it's verified. */
function DiningHallDetailSheet({ s, t, hall, onNavigate, onClose }) {
  const hasRealConcepts = hall.concepts && hall.concepts.length > 0;
  const detail = useLiveData(callGetDiningHallDetail, { hallName: `${hall.name} ${hall.venue}` }, 'vendors');
  const liveVendors = detail.data || [];
  const open = isOpenNow(hall.hours);

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={s.sheetBackdrop}>
        <BlurFill t={t} />
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={s.sheet}>
          <View style={s.sheetHandle} />
          <Text style={s.sheetTitle}>{hall.name}</Text>
          <Text style={s.rowMeta}>
            {metaLine(
              open === true ? 'Open now' : open === false ? 'Closed' : 'Hours vary',
              hall.venue && hall.venue !== hall.name ? hall.venue : null,
              hall.walk != null ? `${hall.walk} min walk` : null
            )}
          </Text>

          <ScrollView style={{ maxHeight: SCREEN_H * 0.45, marginTop: 16 }} showsVerticalScrollIndicator={false}>
            <Text style={[s.sectionLabel, { marginBottom: 8 }]}>HOURS</Text>
            {hoursByDay(hall.hours).map((row) => (
              <View key={row.day} style={s.utilityLine}>
                <Text style={[s.utilityName, row.isToday && { color: t.red, fontWeight: '700' }]}>{row.day}</Text>
                <Text style={s.utilityDist}>{row.text}</Text>
              </View>
            ))}

            <Text style={[s.sectionLabel, { marginTop: 18, marginBottom: 8 }]}>WHAT'S INSIDE</Text>
            {hasRealConcepts ? (
              hall.concepts.map((c, i) => <Row key={i} s={s} t={t} title={c} />)
            ) : detail.loading ? (
              <Text style={s.emptyBody}>Looking up what's inside…</Text>
            ) : liveVendors.length ? (
              liveVendors.map((v, i) => <Row key={i} s={s} t={t} title={v} />)
            ) : (
              <Text style={s.emptyBody}>This is a single-concept location — no separate stations inside.</Text>
            )}
          </ScrollView>

          {hall.buildingId ? (
            <Pressable style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 18 }]} onPress={onNavigate}>
              <Text style={s.primaryBtnText}>Navigate</Text>
            </Pressable>
          ) : null}
        </View>
      </View>
    </Modal>
  );
}

function CategoryModal({ s, t, kind, events, onClose }) {
  const { setOrgDetailId, goToBuilding, setLiveDetailEvent } = useApp();
  const menusData = useLiveData(callGetDiningMenus, {}, 'menus');
  const diningMenus = menusData.data || [];
  const [sportFilter, setSportFilter] = useState('Football');
  const [diningDetail, setDiningDetail] = useState(null);
  const sportsData = useLiveData(callGetSportsSchedule, { sport: sportFilter.toLowerCase() }, 'schedule');
  if (!kind) return null;

  const titles = {
    tonight: 'Tonight', sports: 'Athletics', dining: 'Dining',
    orgs: 'Organizations', study: 'Study Spaces', arts: 'Arts & Culture', resources: 'Get Help',
  };
  const tonight = (events || []).filter((e) => /today|tonight/i.test(e.date || ''));
  const arts = (events || []).filter((e) => /art|music|concert|theatre|gallery/i.test(`${e.title} ${e.desc}`));

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <SafeAreaView style={[s.categoryScreen, { backgroundColor: t.canvas }]}>
        <View style={s.categoryTopBar}>
          <Pressable onPress={onClose} hitSlop={12} style={s.categoryBack}>
            <Text style={s.categoryBackText}>‹</Text>
          </Pressable>
          <Text style={s.categoryHeaderTitle}>{titles[kind]}</Text>
          <View style={{ width: 32 }} />
        </View>

        <ScrollView contentContainerStyle={s.categoryContent} showsVerticalScrollIndicator={false}>

          {/* TONIGHT — a timeline, since the whole point is "in what order" */}
          {kind === 'tonight' && (
            tonight.length ? tonight.map((e, i) => (
              <View key={e.id} style={s.timelineRow}>
                <View style={s.timelineGutter}><Text style={s.timelineTime}>{e.time}</Text></View>
                <View style={[s.timelineRail, { backgroundColor: t.red, opacity: i === 0 ? 1 : 0.3 }]} />
                <View style={{ flex: 1 }}>
                  <Glass s={s} t={t} radius={16} bleed={i === 0 ? 1 : 0} onPress={() => setLiveDetailEvent(e)}>
                    <View style={s.timelineCard}>
                      <Text style={s.rowTitle}>{e.title}</Text>
                      <Text style={s.rowMeta}>{buildingById(e.buildingId)?.name}</Text>
                    </View>
                  </Glass>
                </View>
              </View>
            )) : (
              <Text style={s.emptyBody}>Nothing left tonight — check tomorrow in Discover.</Text>
            )
          )}

          {/* SPORTS — a scoreboard treatment, not a list row */}
          {kind === 'sports' && (
            <>
              {(() => {
                const game = nextGame();
                const last = lastGame();
                const show = game || last;
                if (!show) return null;
                return (
                  <Glass s={s} t={t} radius={22} lift={2} bleed={1} bleedCorner="topRight"
                    onPress={() => show.buildingId && goToBuilding(show.buildingId)}>
                    <View style={s.scoreboardInner}>
                      <Text style={s.tileKicker}>{game ? (game.homeAway === 'home' ? 'NEXT HOME GAME' : 'NEXT GAME') : 'LAST GAME'}</Text>
                      <View style={s.scoreboardRow}>
                        <View style={s.scoreboardSide}>
                          <Text style={s.scoreboardTeam}>TTU</Text>
                        </View>
                        <Text style={s.scoreboardVs}>{show.homeAway === 'home' ? 'VS' : 'AT'}</Text>
                        <View style={s.scoreboardSide}>
                          <Text style={s.scoreboardTeam} numberOfLines={2}>{show.opponent}</Text>
                        </View>
                      </View>
                      <Text style={s.nextMeta}>{game ? gameDateLabel(game.kickoff) : last.result}</Text>
                      <Text style={s.rowMeta}>{show.venue}</Text>
                    </View>
                  </Glass>
                );
              })()}

              {/* FULL SCHEDULE — real, live, per sport via Tavily.
                  Football uses the real, verified FOOTBALL_SCHEDULE
                  above — dated, cross-checked against live sports
                  data, and including real results for games already
                  played. Other sports fall back to live search,
                  which is honest but less certain, so they're shown
                  with the same caveat as any searched data. */}
              <SectionLabel s={s}>FULL SCHEDULE</SectionLabel>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
                {SPORTS_LIST.map((sp) => (
                  <Pill key={sp} s={s} t={t} label={sp} active={sportFilter === sp} onPress={() => setSportFilter(sp)} />
                ))}
              </ScrollView>
              {sportFilter === 'Football' ? (
                FOOTBALL_SCHEDULE.map((g, i) => {
                  const played = new Date(g.kickoff) <= new Date();
                  return (
                    <Row key={i} s={s} t={t}
                      title={`${g.homeAway === 'home' ? 'vs' : '@'} ${g.opponent}`}
                      meta={`${gameDateLabel(g.kickoff)} · ${g.venue}`}
                      note={played && g.result ? g.result : undefined} />
                  );
                })
              ) : sportsData.loading ? (
                <Text style={s.emptyBody}>Loading the {sportFilter.toLowerCase()} schedule…</Text>
              ) : sportsData.error ? (
                <Text style={s.emptyBody}>Couldn't load that schedule right now.</Text>
              ) : (sportsData.data || []).length ? (
                sportsData.data.map((g, i) => (
                  <Row key={i} s={s} t={t}
                    title={`${g.homeAway === 'home' ? 'vs' : g.homeAway === 'away' ? '@' : 'vs'} ${g.opponent}`}
                    meta={metaLine(g.date, g.time, g.venue)} />
                ))
              ) : (
                <Text style={s.emptyBody}>No {sportFilter.toLowerCase()} schedule found yet.</Text>
              )}
            </>
          )}

          {/* DINING — utility list, status-first, no bleed. Menu
              items are real (live via Tavily) where a matching
              dining hall name was found; unmatched halls just show
              status, no invented menu text. */}
          {kind === 'dining' && DINING.map((d) => {
            const menu = (diningMenus || []).find((m) =>
              m.hall && (d.name.toLowerCase().includes(m.hall.toLowerCase()) || m.hall.toLowerCase().includes(d.name.toLowerCase()))
            );
            return (
              <Row key={d.id} s={s} t={t} title={d.name}
                meta={metaLine(
                  placeStatus(d),
                  d.venue && d.venue !== d.name ? d.venue : null,
                  d.walk != null ? `${d.walk} min walk` : null
                )}
                note={menu && menu.items && menu.items.length ? menu.items.slice(0, 3).join(' · ') : undefined}
                onPress={() => setDiningDetail(d)}
                right={<View style={[s.statusDot, { backgroundColor: isOpenNow(d.hours) === true ? t.ok : isOpenNow(d.hours) === false ? t.textFaint : t.borderStrong, marginLeft: 10 }]} />} />
            );
          })}
          {diningDetail ? (
            <DiningHallDetailSheet s={s} t={t} hall={diningDetail}
              onNavigate={() => { goToBuilding(diningDetail.buildingId); setDiningDetail(null); }}
              onClose={() => setDiningDetail(null)} />
          ) : null}

          {/* ORGS — a directory grid of marks, not a vertical list */}
          {kind === 'orgs' && (
            <View style={s.orgDirectory}>
              {ORGS.map((o) => (
                <Pressable key={o.id} onPress={() => setOrgDetailId(o.id)} style={s.orgDirTile}>
                  <View style={s.orgDirMark}><Text style={s.orgDirMarkText}>{o.initials}</Text></View>
                  <Text style={s.orgDirName} numberOfLines={2}>{o.name}</Text>
                  <Text style={s.orgDirTags} numberOfLines={1}>{o.tags}</Text>
                </Pressable>
              ))}
            </View>
          )}

          {/* STUDY — availability-first utility, matches dining's register */}
          {kind === 'study' && STUDY.map((x) => (
            <Row key={x.id} s={s} t={t} title={x.name} meta={`${placeStatus(x)} · ${x.walk} min walk`}
              onPress={() => goToBuilding(x.buildingId)} />
          ))}

          {/* ARTS — editorial, one column, generous type */}
          {kind === 'arts' && (
            arts.length ? arts.map((e) => (
              <Pressable key={e.id} onPress={() => setLiveDetailEvent(e)} style={s.artsEditorialRow}>
                <Text style={s.artsEditorialTitle}>{e.title}</Text>
                <Text style={s.artsEditorialMeta}>{metaLine(e.date, e.time, buildingById(e.buildingId)?.name || e.room)}</Text>
              </Pressable>
            )) : <Text style={s.emptyBody}>Nothing under Arts & Culture right now.</Text>
          )}

          {/* RESOURCES — plain, calm, no decoration, matches its tile */}
          {kind === 'resources' && RESOURCES.map((r) => (
            <Row key={r.id} s={s} t={t} title={r.name}
              meta={metaLine(r.kind, r.buildingId ? buildingById(r.buildingId)?.name : null)}
              onPress={() => (r.url ? Linking.openURL(r.url) : goToBuilding(r.buildingId))} />
          ))}

        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}

function DiscoverScreen({ s, t }) {
  const {
    setDetailId, savedIds, toggleSave, setOrgDetailId, goToBuilding, setLiveDetailEvent,
    discoverCategory: expanded, setDiscoverCategory: setExpanded,
  } = useApp();
  const [query, setQuery] = useState('');

  // Real, live events — replaces the fabricated EVENTS array that
  // was cut earlier tonight. Cached server-side for a few hours,
  // so this isn't re-searching on every single screen visit.
  // Normalized into the app's internal event shape so DetailSheet,
  // Ask Red, and everything else that expects an id/buildingId/
  // category keeps working unchanged — the live function returns a
  // simpler {title, location, desc, sourceUrl} shape that doesn't
  // match that on its own.
  const liveEvents = useLiveData(callGetEvents, {}, 'events');
  const events = useMemo(() => (liveEvents.data || []).map((e, i) => ({
    id: `live-${i}`,
    title: e.title || 'Untitled event',
    org: e.org || 'Texas Tech',
    date: e.date || '',
    time: e.time || '',
    endTime: '',
    buildingId: matchBuildingName(e.location),
    room: e.location || '',
    category: 'Campus Events',
    official: false,
    live: false,
    desc: e.desc || '',
    sourceUrl: e.sourceUrl || null,
    img: e.img || IMG.rally,
  })), [liveEvents.data]);
  const tonightCount = events.filter((e) => /today|tonight/i.test(e.date || '')).length;
  const artsEvent = events.find((e) => /art|music|concert|theatre|gallery/i.test(`${e.title} ${e.desc}`));
  const venueImage = useLiveValue(callGetVenueImage, { query: 'Galaxy Stadium Texas Tech exterior' }, 'image');

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;
    return {
      events: events.filter((e) => (e.title || '').toLowerCase().includes(q)),
      orgs: ORGS.filter((o) => o.name.toLowerCase().includes(q)),
      places: BUILDINGS.filter((b) => b.name.toLowerCase().includes(q)),
    };
  }, [query, events]);

  return (
    <ScrollView style={s.screen} contentContainerStyle={s.screenContent} showsVerticalScrollIndicator={false}>
      <Text style={s.pageTitle}>Discover</Text>

      <View style={s.search}>
        <Text style={s.searchIcon}>⌕</Text>
        <TextInput style={s.searchInput} placeholder="Search events, places, organizations…"
          placeholderTextColor={t.textFaint} value={query} onChangeText={setQuery} />
      </View>

      {results ? (
        <View style={{ marginTop: 18 }}>
          {results.events.length ? (<><SectionLabel s={s}>EVENTS</SectionLabel>
            {results.events.map((e) => (
              <Row key={e.id} s={s} t={t} title={e.title}
                meta={metaLine(e.date, e.time, buildingById(e.buildingId)?.name || e.room)}
                onPress={() => setLiveDetailEvent(e)} />
            ))}</>) : null}
          {results.orgs.length ? (<><SectionLabel s={s}>ORGANIZATIONS</SectionLabel>
            {results.orgs.map((o) => <Row key={o.id} s={s} t={t} title={o.name} meta={o.tags} onPress={() => setOrgDetailId(o.id)} />)}</>) : null}
          {results.places.length ? (<><SectionLabel s={s}>PLACES</SectionLabel>
            {results.places.map((b) => <Row key={b.id} s={s} t={t} title={b.name} meta={metaLine(catLabel(b.kind), walkLabel(b))} onPress={() => goToBuilding(b.id)} />)}</>) : null}
          {!results.events.length && !results.orgs.length && !results.places.length ? (
            <Glass s={s} t={t}><View style={s.emptyInner}>
              <Text style={s.emptyTitle}>Nothing matched "{query}"</Text>
              <Text style={s.emptyBody}>Try a broader search, or ask Red.</Text>
            </View></Glass>
          ) : null}
        </View>
      ) : (
        <>
          <SectionLabel s={s}>FOR YOU</SectionLabel>
          {(() => {
            const feat = featuredEvent();
            if (!feat) return null;
            return (
              <TileFeatured s={s} t={t} ev={{ ...feat, img: venueImage.data || feat.img }} saved={savedIds.has(feat.id)}
                onToggleSave={() => toggleSave(feat.id)} onOpen={() => setDetailId(feat.id)} />
            );
          })()}

          <CategoryModal s={s} t={t} kind={expanded} events={events} onClose={() => setExpanded(null)} />

          <View style={s.gridRow}>
            <TileSports s={s} t={t} img={venueImage.data} onOpen={() => setExpanded(expanded === 'sports' ? null : 'sports')} />
            <TileTonight s={s} t={t} count={tonightCount} onOpen={() => setExpanded(expanded === 'tonight' ? null : 'tonight')} />
          </View>

          <View style={s.gridRow}>
            <TileOrgs s={s} t={t} onOpen={() => setExpanded(expanded === 'orgs' ? null : 'orgs')} />
            <TileDining s={s} t={t} onOpen={() => setExpanded(expanded === 'dining' ? null : 'dining')} />
          </View>

          {artsEvent ? (
            <View style={s.gridRow}>
              <TileStudy s={s} t={t} onOpen={() => setExpanded(expanded === 'study' ? null : 'study')} />
              <TileArts s={s} t={t} ev={artsEvent} onOpen={() => setExpanded(expanded === 'arts' ? null : 'arts')} />
            </View>
          ) : (
            <TileStudy s={s} t={t} width={GRID_W} onOpen={() => setExpanded(expanded === 'study' ? null : 'study')} />
          )}

          <TileResources s={s} t={t} onOpen={() => setExpanded(expanded === 'resources' ? null : 'resources')} />
        </>
      )}
    </ScrollView>
  );
}

/* ============================================================
   CAMPUS — map is the innovation, glass floats above it
   ============================================================ */

const DRAWER_MIN = 220;
const DRAWER_MAX = SCREEN_H * 0.68;

function CampusScreen({ s, t }) {
  const { selectedBuildingId, setSelectedBuildingId } = useApp();
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState(false);
  const [cat, setCat] = useState('All');
  const h = useRef(new Animated.Value(DRAWER_MIN)).current;
  const liveEvents = useLiveData(callGetEvents, {}, 'events');

  useEffect(() => {
    Animated.spring(h, { toValue: expanded ? DRAWER_MAX : DRAWER_MIN, useNativeDriver: false, damping: 20, stiffness: 130 }).start();
  }, [expanded]);

  // 213 buildings is far too many to scroll blind, so the list is
  // filtered by category and always sorted nearest-first.
  const list = useMemo(() => {
    let out = BUILDINGS;
    const q = query.trim().toLowerCase();
    if (q) out = out.filter((b) => b.name.toLowerCase().includes(q));
    else if (cat !== 'All') out = out.filter((b) => b.kind === cat);
    return [...out].sort((a, b) => a.walk - b.walk);
  }, [query, cat]);

  const selected = buildingById(selectedBuildingId);
  // Real live events, matched by building — was silently checking
  // the permanently-empty static EVENTS array before, so "Happening
  // now" could never actually show.
  const liveIds = new Set((liveEvents.data || []).map((e) => matchBuildingName(e.location)).filter(Boolean));

  // Only render pins for what's listed — 213 markers at once is
  // both unreadable and a real performance problem on device.
  const pins = useMemo(() => list.slice(0, 60), [list]);

  return (
    <View style={{ flex: 1 }}>
      <View style={StyleSheet.absoluteFill}>
        {MapView ? (
          <MapView style={StyleSheet.absoluteFill}
            initialRegion={{ ...CAMPUS_CENTER, latitudeDelta: 0.014, longitudeDelta: 0.014 }}
            customMapStyle={t.mode === 'dark' ? MAP_STYLE_DARK : MAP_STYLE_LIGHT}
            region={selected ? { latitude: selected.lat, longitude: selected.lng, latitudeDelta: 0.005, longitudeDelta: 0.005 } : undefined}>
            {pins.map((b) => (
              <Marker key={b.id} coordinate={{ latitude: b.lat, longitude: b.lng }}
                title={b.name} description={liveIds.has(b.id) ? 'Happening now' : catLabel(b.kind)}
                pinColor={b.id === selectedBuildingId ? t.red : undefined}
                onPress={() => setSelectedBuildingId(b.id)} />
            ))}
            {BUS_STOPS.map((stop) => {
              const b = buildingById(stop.buildingId);
              if (!b) return null;
              return (
                <Marker key={stop.id} coordinate={{ latitude: b.lat, longitude: b.lng }}
                  title={`🚌 ${stop.name}`} description={`Citibus ${stop.route} route`}
                  pinColor="#1E90FF" />
              );
            })}
          </MapView>
        ) : (
          <View style={[StyleSheet.absoluteFill, { backgroundColor: t.surfaceAlt, alignItems: 'center', justifyContent: 'center', padding: 40 }]}>
            <Text style={s.emptyTitle}>Map needs a real device</Text>
            <Text style={s.emptyBody}>react-native-maps can't render in a web preview. Open in Expo Go.</Text>
          </View>
        )}
      </View>

      <SafeAreaView pointerEvents="box-none" style={s.campusTop}>
        <View style={[s.search, s.campusSearch]}>
          <Text style={s.searchIcon}>⌕</Text>
          <TextInput style={s.searchInput} placeholder="Search buildings" placeholderTextColor={t.textFaint}
            value={query} onChangeText={setQuery} />
        </View>
      </SafeAreaView>

      <Animated.View style={[s.drawer, { height: h }]}>
        <Pressable onPress={() => setExpanded(!expanded)} style={s.drawerGrip}>
          <View style={s.drawerHandle} />
        </Pressable>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 210 }}>
          {selected ? (
            <Glass s={s} t={t} radius={18} lift={2} bleed={1} bleedCorner="bottomLeft" style={{ marginBottom: 14 }}>
              <View style={s.nextInner}>
                <Text style={s.sectionLabel}>SELECTED</Text>
                <Text style={s.nextTitle}>{selected.name}</Text>
                <Text style={s.nextMeta}>{metaLine(catLabel(selected.kind), walkLabel(selected))}</Text>
                {selected.hours ? (
                  <View style={{ marginTop: 12 }}>
                    <Text style={s.sectionLabel}>HOURS</Text>
                    {hoursByDay(selected.hours).map((row) => (
                      <View key={row.day} style={s.utilityLine}>
                        <Text style={[s.utilityName, row.isToday && { color: t.red, fontWeight: '700' }]}>{row.day}</Text>
                        <Text style={s.utilityDist}>{row.text}</Text>
                      </View>
                    ))}
                  </View>
                ) : null}
                <View style={{ flexDirection: 'row', marginTop: 12 }}>
                  <Pressable style={s.primaryBtn} onPress={() => openDirections(selected)}>
                    <Text style={s.primaryBtnText}>Directions</Text>
                  </Pressable>
                  <Pressable style={s.ghostBtn} onPress={() => setSelectedBuildingId(null)}>
                    <Text style={s.ghostBtnText}>Clear</Text>
                  </Pressable>
                </View>
              </View>
            </Glass>
          ) : null}

          {!query.trim() ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false}
              style={s.campusFilterScroll} contentContainerStyle={s.campusFilterRow}>
              {CAMPUS_CATS.map((c) => (
                <Pill key={c} s={s} t={t} label={catLabel(c)} active={cat === c} onPress={() => setCat(c)} />
              ))}
            </ScrollView>
          ) : null}

          <Text style={s.campusCount}>
            {list.length} {list.length === 1 ? 'place' : 'places'}
            {list.length > pins.length ? ` · showing ${pins.length} on map` : ''}
          </Text>

          {list.map((b) => (
            <Row key={b.id} s={s} t={t} title={b.name} meta={metaLine(catLabel(b.kind), walkLabel(b))}
              note={liveIds.has(b.id) ? 'Something happening now' : undefined}
              onPress={() => { setSelectedBuildingId(b.id); setExpanded(false); }} />
          ))}
          {!list.length ? (
            <Glass s={s} t={t}><View style={s.emptyInner}>
              <Text style={s.emptyTitle}>No match</Text>
            </View></Glass>
          ) : null}
        </ScrollView>
      </Animated.View>
    </View>
  );
}

/* ============================================================
   SCHEDULE — deliberately conventional (section 16)
   ============================================================ */

/* A real line tracking the current time, inserted at its actual
   chronological position in the list — not a pixel-math overlay
   guessing at row heights. */
/* ============================================================
   CLASS FORM — add or edit a real schedule entry
   ------------------------------------------------------------
   Times are validated against the same toMinutes() parser used
   everywhere else in the app, so "9:00 AM" format is enforced
   consistently rather than accepting free text that would silently
   fail to sort/display correctly downstream. Building is searched
   from the real 199-building list, not free text — so a class
   always points at a real, walkable location.
   ============================================================ */
const DAY_OPTIONS = ['M', 'T', 'W', 'Th', 'F', 'Sa', 'Su'];

function ClassForm({ s, t, existing, onClose }) {
  const { addClass, updateClass, removeClass } = useApp();
  const [title, setTitle] = useState(existing?.title || '');
  const [time, setTime] = useState(existing?.time || '');
  const [endTime, setEndTime] = useState(existing?.endTime || '');
  const [days, setDays] = useState(existing?.days || []);
  const [buildingQuery, setBuildingQuery] = useState('');
  const [buildingId, setBuildingId] = useState(existing?.buildingId || null);
  const [room, setRoom] = useState(existing?.place?.split(' ').slice(-1)[0] || '');

  const toggleDay = (d) => setDays((p) => (p.includes(d) ? p.filter((x) => x !== d) : [...p, d]));

  const buildingMatches = useMemo(() => {
    const q = buildingQuery.trim().toLowerCase();
    if (!q) return [];
    return BUILDINGS.filter((b) => b.name.toLowerCase().includes(q)).slice(0, 6);
  }, [buildingQuery]);

  const selectedBuilding = buildingId ? buildingById(buildingId) : null;
  const timeValid = toMinutes(time) !== null;
  const endValid = toMinutes(endTime) !== null;
  const canSave = title.trim() && timeValid && endValid && days.length > 0 && buildingId;

  const save = () => {
    const payload = {
      title: title.trim(), time, endTime, days, buildingId, type: 'class',
      place: `${selectedBuilding?.name || ''}${room ? ' ' + room : ''}`,
    };
    if (existing) updateClass(existing.id, payload);
    else addClass(payload);
    onClose();
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={s.sheetBackdrop}>
        <BlurFill t={t} />
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={s.sheet}>
          <View style={s.sheetHandle} />
          <Text style={s.sheetTitle}>{existing ? 'Edit Class' : 'Add a Class'}</Text>

          <ScrollView style={{ maxHeight: SCREEN_H * 0.55, marginTop: 16 }} showsVerticalScrollIndicator={false}>
            <TextInput
              style={s.signinInput} placeholder="Course (e.g. CS 1412)"
              placeholderTextColor={t.textFaint} value={title} onChangeText={setTitle}
            />

            <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
              <TextInput
                style={[s.signinInput, { flex: 1 }, !time && {}, time && !timeValid && { borderColor: t.red }]}
                placeholder="9:00 AM" placeholderTextColor={t.textFaint} value={time} onChangeText={setTime}
              />
              <TextInput
                style={[s.signinInput, { flex: 1 }, endTime && !endValid && { borderColor: t.red }]}
                placeholder="9:50 AM" placeholderTextColor={t.textFaint} value={endTime} onChangeText={setEndTime}
              />
            </View>
            {(time && !timeValid) || (endTime && !endValid) ? (
              <Text style={s.classFormError}>Use a format like "9:00 AM".</Text>
            ) : null}

            <Text style={[s.sectionLabel, { marginTop: 18, marginBottom: 10 }]}>DAYS</Text>
            <View style={s.pillWrap}>
              {DAY_OPTIONS.map((d) => (
                <Pill key={d} s={s} t={t} label={WEEK_DAY_LABELS[d]} active={days.includes(d)} onPress={() => toggleDay(d)} />
              ))}
            </View>

            <Text style={[s.sectionLabel, { marginTop: 18, marginBottom: 10 }]}>BUILDING</Text>
            {selectedBuilding ? (
              <Row s={s} t={t} title={selectedBuilding.name} meta={selectedBuilding.kind}
                onPress={() => { setBuildingId(null); setBuildingQuery(''); }}
                right={<Text style={s.classFormClear}>Change</Text>} />
            ) : (
              <>
                <TextInput
                  style={s.signinInput} placeholder="Search buildings…"
                  placeholderTextColor={t.textFaint} value={buildingQuery} onChangeText={setBuildingQuery}
                />
                {buildingMatches.map((b) => (
                  <Row key={b.id} s={s} t={t} title={b.name} meta={catLabel(b.kind)}
                    onPress={() => { setBuildingId(b.id); setBuildingQuery(''); }} />
                ))}
              </>
            )}

            <TextInput
              style={[s.signinInput, { marginTop: 10 }]} placeholder="Room (optional)"
              placeholderTextColor={t.textFaint} value={room} onChangeText={setRoom}
            />
          </ScrollView>

          <Pressable
            style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 18, opacity: canSave ? 1 : 0.5 }]}
            disabled={!canSave} onPress={save}
          >
            <Text style={s.primaryBtnText}>{existing ? 'Save Changes' : 'Add Class'}</Text>
          </Pressable>

          {existing ? (
            <Pressable
              style={[s.ghostBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0 }]}
              onPress={() => { removeClass(existing.id); onClose(); }}
            >
              <Text style={[s.ghostBtnText, { color: t.red }]}>Remove Class</Text>
            </Pressable>
          ) : null}
        </View>
      </View>
    </Modal>
  );
}

function ManageScheduleSheet({ s, t, onClose }) {
  const { scheduleItems, addClass } = useApp();
  const [editing, setEditing] = useState(null); // null | 'new' | item
  const classes = scheduleItems.filter((i) => i.type === 'class')
    .sort((a, b) => toMinutes(a.time) - toMinutes(b.time));

  return (
    <>
      <Modal visible transparent animationType="slide" onRequestClose={onClose}>
        <View style={s.sheetBackdrop}>
          <BlurFill t={t} />
          <Pressable style={{ flex: 1 }} onPress={onClose} />
          <View style={s.sheet}>
            <View style={s.sheetHandle} />
            <Text style={s.sheetTitle}>Manage Schedule</Text>
            <Text style={s.sheetSub}>Dropped a class, or added one? Update it here.</Text>

            <ScrollView style={{ maxHeight: SCREEN_H * 0.5, marginTop: 16 }} showsVerticalScrollIndicator={false}>
              {classes.length ? classes.map((c) => (
                <Row key={c.id} s={s} t={t} title={c.title}
                  meta={`${(c.days || []).join('/')} · ${c.time} · ${c.place}`}
                  onPress={() => setEditing(c)} />
              )) : (
                <Text style={s.emptyBody}>No classes added yet.</Text>
              )}

              <Pressable
                style={[s.ghostBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 8 }]}
                onPress={() => setEditing('new')}
              >
                <Text style={s.ghostBtnText}>+ Add a Class</Text>
              </Pressable>

              <ScanEntryPoint s={s} t={t} onConfirm={(items) => items.forEach((it) => addClass(it))} />
            </ScrollView>
          </View>
        </View>
      </Modal>
      {editing ? <ClassForm s={s} t={t} existing={editing === 'new' ? null : editing} onClose={() => setEditing(null)} /> : null}
    </>
  );
}

function NowMarker({ s, t }) {
  const now = new Date();
  const label = now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

  return (
    <View style={s.nowMarkerRow}>
      <View style={s.timelineGutter}>
        <Text style={[s.nowMarkerLabel, NUM]}>{label}</Text>
      </View>
      <View style={s.nowMarkerAxis}>
        <LiveDot color={t.red} size={5.5} />
      </View>
      <View style={s.nowMarkerLine} />
    </View>
  );
}

function ScheduleScreen({ s, t }) {
  const { scheduleItems, goToBuilding } = useApp();
  const [view, setView] = useState('Day');
  const [selectedWeekDay, setSelectedWeekDay] = useState(null);
  const now = new Date();
  const nowM = now.getHours() * 60 + now.getMinutes();
  const sorted = itemsOnDay(scheduleItems, todayCode()).sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
  const dateLabel = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

  // Real Monday-Sunday of the current week, with REAL per-day counts —
  // now that schedule items carry real day-of-week recurrence, every
  // day's bar reflects what's actually scheduled that day, not just
  // today with everything else zeroed out.
  const week = useMemo(() => {
    const FULL_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const todayIdx = (now.getDay() + 6) % 7; // Mon=0 .. Sun=6
    const monday = new Date(now);
    monday.setDate(now.getDate() - todayIdx);
    return WEEK_DAYS.map((code, i) => {
      const date = new Date(monday);
      date.setDate(monday.getDate() + i);
      return {
        code, d: code, n: String(date.getDate()), isToday: i === todayIdx,
        full: FULL_DAYS[i],
        c: itemsOnDay(scheduleItems, code).length,
      };
    });
  }, [scheduleItems]);

  return (
    <ScrollView style={s.screen} contentContainerStyle={s.screenContent} showsVerticalScrollIndicator={false}>
      <Text style={s.pageTitle}>Schedule</Text>
      <Text style={s.pageSub}>{dateLabel}</Text>


      <View style={s.segment}>
        {['Day', 'Week'].map((v) => (
          <Pressable key={v} onPress={() => setView(v)} style={[s.segmentItem, view === v && { backgroundColor: t.red }]}>
            <Text style={[s.segmentText, view === v && { color: t.onRed }]}>{v}</Text>
          </Pressable>
        ))}
      </View>

      {view === 'Day' ? (
        <View style={{ marginTop: 18 }}>
          {(() => {
            const nowIdx = sorted.findIndex((i) => (toMinutes(i.time) ?? 0) >= nowM);
            const insertAt = nowIdx === -1 ? sorted.length : nowIdx;
            const rows = [];
            sorted.forEach((i, idx) => {
              if (idx === insertAt) rows.push({ kind: 'now-marker', id: 'now-marker' });
              rows.push({ kind: 'item', ...i });
            });
            if (insertAt === sorted.length) rows.push({ kind: 'now-marker', id: 'now-marker' });

            const subjectColor = (title) => {
              const prefix = (title || '').split(' ')[0];
              const map = { MATH: '#3F8F5C', CS: '#3F6B9C', CARS: '#C17A2E', TSI: '#7B5FA6' };
              return map[prefix] || t.textFaint;
            };
            const subjectPrefix = (title) => (title || '').split(' ')[0];

            return rows.map((row) => {
              if (row.kind === 'now-marker') return <NowMarker key="now-marker" s={s} t={t} />;
              const i = row;
              const start = toMinutes(i.time) ?? 0;
              const past = start < nowM;
              const isNext = !past && sorted.find((x) => (toMinutes(x.time) ?? 0) >= nowM)?.id === i.id;
              const subj = subjectColor(i.title);
              return (
                <View key={i.id} style={s.timelineRow}>
                  <View style={s.timelineGutter}>
                    <Text style={[s.timelineTime, past && { opacity: 0.4 }]}>{i.time}</Text>
                  </View>
                  <View style={[s.timelineRail, { backgroundColor: past ? t.border : t.red, opacity: past ? 1 : isNext ? 1 : 0.35 }]} />
                  <View style={{ flex: 1, opacity: past ? 0.45 : 1 }}>
                    <Glass s={s} t={t} radius={16} lift={isNext ? 1 : 0}
                      ring={isNext ? t.red : undefined} onPress={() => goToBuilding(i.buildingId)}>
                      <View style={[s.timelineCard, { flexDirection: 'row' }]}>
                        <View style={[s.subjectAccent, { backgroundColor: subj }]} />
                        <View style={{ flex: 1 }}>
                          <View style={s.timelineCardTop}>
                            <View style={[s.kindTag, { backgroundColor: subj }]}>
                              <Text style={s.kindTagText}>{subjectPrefix(i.title)}</Text>
                            </View>
                            {isNext ? <Text style={s.nowTag}>NEXT</Text> : null}
                          </View>
                          <Text style={s.rowTitle}>{i.title}</Text>
                          <Text style={s.rowMeta}>{i.place}</Text>
                        </View>
                      </View>
                    </Glass>
                  </View>
                </View>
              );
            });
          })()}
          {!sorted.length ? (
            <Glass s={s} t={t}><View style={s.emptyInner}>
              <Text style={s.emptyTitle}>Nothing scheduled today</Text>
              <Text style={s.emptyBody}>Add a class from You → Manage Schedule.</Text>
            </View></Glass>
          ) : null}
        </View>
      ) : (
        <View style={{ marginTop: 18 }}>
          <View style={s.weekRow}>
            {week.map((d) => {
              const isSel = selectedWeekDay === d.code;
              return (
                <Pressable key={d.code} style={s.weekCol} onPress={() => setSelectedWeekDay(isSel ? null : d.code)}>
                  <Text style={[s.weekDay, isSel && { color: t.red, fontWeight: '800' }]}>{d.d}</Text>
                  {/* Bars sit inside a visible tappable surface so it
                      reads as a control, not a static chart — the
                      previous version gave no hint it could be tapped. */}
                  <View style={[s.weekTrack, isSel && { backgroundColor: t.rim, borderColor: t.red, borderWidth: 1 }]}>
                    <View style={[s.weekFill, {
                      height: Math.max(5, d.c * 14),
                      backgroundColor: isSel ? t.red : d.isToday ? t.red : t.borderStrong,
                      opacity: isSel || d.isToday ? 1 : 0.75,
                    }]} />
                  </View>
                  <Text style={[s.weekNum, (d.isToday || isSel) && { color: t.red, fontWeight: '800' }]}>{d.n}</Text>
                  {d.c > 0 ? <Text style={s.weekCount}>{d.c}</Text> : <Text style={s.weekCount}> </Text>}
                </Pressable>
              );
            })}
          </View>
          <Text style={s.weekCaption}>
            {selectedWeekDay ? 'Tap the same day again to close.' : 'Tap any day to see its classes.'}
          </Text>

          {/* Real weekly summary, computed from the actual schedule
              rather than shown as a static caption. */}
          {(() => {
            const totalClasses = week.reduce((sum, d) => sum + d.c, 0);
            if (!totalClasses) return null;
            const busiest = week.reduce((a, b) => (b.c > a.c ? b : a), week[0]);
            const totalMins = week.reduce((sum, d) => sum + itemsOnDay(scheduleItems, d.code)
              .reduce((m, i) => {
                const a = toMinutes(i.time), b = toMinutes(i.endTime);
                return m + (a != null && b != null && b > a ? b - a : 0);
              }, 0), 0);
            const hours = Math.round(totalMins / 6) / 10;
            return (
              <Glass s={s} t={t} lift={0} style={{ marginTop: 14 }}>
                <View style={s.weekSummaryInner}>
                  <Text style={s.weekSummaryLine}>
                    {totalClasses} {totalClasses === 1 ? 'class' : 'classes'} this week
                    {hours > 0 ? ` · ${hours} ${hours === 1 ? 'hour' : 'hours'} in class` : ''}
                  </Text>
                  {busiest.c > 0 ? (
                    <Text style={s.weekSummarySub}>Busiest day is {busiest.full}.</Text>
                  ) : null}
                </View>
              </Glass>
            );
          })()}

          {/* That day's real classes, revealed on tap — the chart was
              previously read-only, so seeing a busy day meant switching
              to Day view and changing the date manually. */}
          {selectedWeekDay ? (() => {
            const dayItems = itemsOnDay(scheduleItems, selectedWeekDay)
              .sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
            const dayName = week.find((d) => d.code === selectedWeekDay)?.full || '';
            return (
              <View style={{ marginTop: 16 }}>
                <SectionLabel s={s}>{dayName.toUpperCase()}</SectionLabel>
                {dayItems.length ? dayItems.map((i) => (
                  <Row key={i.id} s={s} t={t} title={i.title}
                    meta={metaLine(`${i.time}${i.endTime ? ` – ${i.endTime}` : ''}`, i.place)}
                    onPress={() => i.buildingId && goToBuilding(i.buildingId)} />
                )) : (
                  <Glass s={s} t={t} lift={0}><View style={s.emptyInner}>
                    <Text style={s.emptyBody}>Nothing scheduled {dayName}.</Text>
                  </View></Glass>
                )}
              </View>
            );
          })() : null}
        </View>
      )}
    </ScrollView>
  );
}

/* ============================================================
   YOU — personal control centre (section 17)
   ============================================================ */

function YouScreen({ s, t, dark, setDark }) {
  const {
    interests, setInterests, savedIds, setDetailId, quietDay, setQuietDay, setInfoSheet,
    userName, userMajor, userClassYear, isGuest, resetOnboarding,
  } = useApp();
  const [manageOpen, setManageOpen] = useState(false);
  const [signOutOpen, setSignOutOpen] = useState(false);
  const toggle = (i) => setInterests((p) => (p.includes(i) ? p.filter((x) => x !== i) : [...p, i]));
  const saved = allEvents().filter((e) => savedIds.has(e.id));

  const displayName = isGuest ? 'Guest' : userName.trim() || 'Red Raider';
  const initials = displayName.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || 'RR';
  const subtitle = isGuest ? 'Browsing as a guest' : [userMajor, userClassYear].filter(Boolean).join(' · ') || 'Texas Tech University';

  return (
    <ScrollView style={s.screen} contentContainerStyle={s.screenContent} showsVerticalScrollIndicator={false}>
      <Text style={s.pageTitle}>You</Text>

      <Glass s={s} t={t} radius={22} lift={2} bleed={1} bleedCorner="topRight">
        <View style={s.profileInner}>
          <Pressable onPress={() => setDark(!dark)} style={s.avatar}>
            <Text style={s.avatarText}>{initials}</Text>
          </Pressable>
          <View style={{ flex: 1, marginLeft: 14 }}>
            <Text style={s.profileName}>{displayName}</Text>
            <Text style={s.rowMeta}>{subtitle}</Text>
          </View>
          <Text style={s.avatarHint}>Tap for {dark ? 'light' : 'dark'}</Text>
        </View>
      </Glass>

      <SectionLabel s={s} action={saved.length ? 'Clear' : undefined}>SAVED</SectionLabel>
      {saved.length ? saved.map((e) => (
        <Row key={e.id} s={s} t={t} title={e.title}
          meta={metaLine(e.date, e.time, buildingById(e.buildingId)?.name || e.room)}
          onPress={() => setDetailId(e.id)} />
      )) : (
        <Glass s={s} t={t} lift={0}><View style={s.emptyInner}>
          <Text style={s.emptyBody}>Nothing saved yet. Tap the star on anything in Discover.</Text>
        </View></Glass>
      )}

      <SectionLabel s={s}>INTERESTS</SectionLabel>
      <View style={s.tagCloud}>
        {INTERESTS.map((i) => {
          const active = interests.includes(i);
          return (
            <Pressable key={i} onPress={() => toggle(i)} style={[s.tagChip, active && { backgroundColor: t.red, borderColor: t.red }]}>
              <View style={{ marginRight: 6 }}>
                <Icon id={i} size={15} color={active ? t.onRed : t.textMuted} strokeWidth={2} />
              </View>
              <Text style={[s.tagLabel, active && { color: t.onRed }]}>{i}</Text>
            </Pressable>
          );
        })}
      </View>

      <SectionLabel s={s}>PREFERENCES</SectionLabel>
      <Row s={s} t={t} title="Dark mode" meta={dark ? 'On' : 'Off'} onPress={() => setDark(!dark)}
        right={<View style={[s.toggle, dark && { backgroundColor: t.red, borderColor: t.red }]}>
          <View style={[s.toggleKnob, dark && { alignSelf: 'flex-end' }]} /></View>} />
      <Row s={s} t={t} title="Simulate a light day" meta="Demo control" onPress={() => setQuietDay(!quietDay)}
        right={<View style={[s.toggle, quietDay && { backgroundColor: t.red, borderColor: t.red }]}>
          <View style={[s.toggleKnob, quietDay && { alignSelf: 'flex-end' }]} /></View>} />

      <SectionLabel s={s}>SETTINGS</SectionLabel>
      <GroupedList s={s} t={t} items={[
        { title: 'Manage Schedule', meta: 'Add, edit, or drop a class', onPress: () => setManageOpen(true) },
        ...['Favorite places', 'Connected services', 'Notifications', 'Privacy & data']
          .map((x) => ({ title: x, onPress: () => setInfoSheet(x) })),
        {
          title: 'Help & feedback', meta: 'Tell us what to fix or add',
          onPress: () => Linking.openURL(
            `mailto:?subject=${encodeURIComponent('RaiderLoop feedback')}&body=${encodeURIComponent('What did you like? What was confusing or broken?\n\n')}`
          ),
        },
      ]} />

      <SectionLabel s={s}>CAMPUS RESOURCES</SectionLabel>
      <Text style={[s.rowMeta, { marginBottom: 10 }]}>Official TTU tools RaiderLoop doesn't try to replace.</Text>
      <GroupedList s={s} t={t} items={[
        { title: 'Raiderlink', meta: 'Registration, grades, financial aid', onPress: () => Linking.openURL('https://www.raiderlink.ttu.edu') },
        { title: 'RaiderCanvas', meta: 'Your courses and coursework', onPress: () => Linking.openURL('https://ttu.instructure.com') },
        { title: 'GET / Transact eAccounts', meta: 'Real RaiderCash & Dining Bucks balance', onPress: () => Linking.openURL('https://ttu-sp.transactcampus.com/eAccounts') },
        { title: 'Texas Tech Red Raiders App', meta: 'Live scores, stats & Red Raider Loyalty points', onPress: () => Linking.openURL('https://texastech.com/sports/2021/8/12/gameday-app') },
        /* Gates, parking, shuttles, bag policy — TTU Athletics keeps
           this current themselves, so we link rather than duplicate
           details that change game to game. */
        { title: 'Gameday in Raiderland', meta: 'Gates, parking, shuttles & stadium policies', onPress: () => Linking.openURL('https://texastech.com/sports/2026/7/15/gameday-in-raiderland') },
        /* Raider Depot is the real official campus bookstore (west
           side of the Student Union, 17th & Boston) — same operation
           handles textbooks and official apparel. */
        { title: 'Raider Depot', meta: 'Textbooks, course materials & official merch', onPress: () => Linking.openURL('https://www.depts.ttu.edu/bookstore/') },
      ]} />

      <Pressable style={{ alignItems: 'center', marginTop: 20 }} onPress={() => setSignOutOpen(true)}>
        <Text style={[s.signinGuestText, { color: t.red }]}>Sign Out</Text>
      </Pressable>
      <Text style={s.versionText}>RaiderLoop · 0.7.0</Text>

      {manageOpen ? <ManageScheduleSheet s={s} t={t} onClose={() => setManageOpen(false)} /> : null}
      {signOutOpen ? (
        <Modal visible transparent animationType="fade">
          <View style={s.conflictBackdrop}>
            <BlurFill t={t} />
            <Glass s={s} t={t} radius={20} lift={2} style={{ width: SCREEN_W - 48 }}>
              <View style={{ padding: 22 }}>
                <Text style={s.conflictTitle}>Sign out?</Text>
                <Text style={s.rowMeta}>This clears your profile, schedule, and saved events on this device, and takes you back through onboarding — including the tour.</Text>
                <Pressable style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginTop: 18, marginRight: 0 }]}
                  onPress={() => { setSignOutOpen(false); resetOnboarding(); }}>
                  <Text style={s.primaryBtnText}>Sign Out</Text>
                </Pressable>
                <Pressable style={[s.ghostBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0 }]}
                  onPress={() => setSignOutOpen(false)}>
                  <Text style={s.ghostBtnText}>Cancel</Text>
                </Pressable>
              </View>
            </Glass>
          </View>
        </Modal>
      ) : null}
    </ScrollView>
  );
}

/* ============================================================
   ASK RED — returns real RaiderLoop content (section 18)
   ============================================================ */

/* Real, live app data assembled fresh per question, not a static
   knowledge document. Deliberately compact — full building/org
   names only, no invented metadata — so Red can reference real
   things without the staleness risk of a big written-once file
   that goes wrong the moment something changes. */
function buildRedContext({ scheduleItems, weather, savedCount }) {
  const today = itemsOnDay(scheduleItems, todayCode()).sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
  const scheduleLines = today.length
    ? today.map((i) => `${i.time}-${i.endTime || ''} ${i.title} @ ${i.place}`).join('; ')
    : 'Nothing scheduled today.';

  const todaysEvents = EVENTS.filter((e) => e.date === 'Today')
    .map((e) => `${e.title} (${e.time}, ${buildingById(e.buildingId)?.name || e.place})`).join('; ');

  const weatherLine = weather.loading ? 'loading' : weather.error ? 'unavailable'
    : `${weather.temp}°F, ${weather.condition}`;

  return [
    `Today's real schedule: ${scheduleLines}`,
    `Real events happening today: ${todaysEvents || 'none listed'}`,
    `Current weather in Lubbock: ${weatherLine}`,
    `Saved events count: ${savedCount}`,
    `Real campus buildings (only these exist — never invent a building name): ${BUILDINGS.map((b) => b.name).join(', ')}`,
    `Real student organizations (only these exist — never invent one): ${ORGS.map((o) => o.name).join(', ')}`,
  ].join('\n\n');
}

function AskRed({ s, t, onClose }) {
  const {
    goToBuilding, setDetailId, savedIds, toggleSave, setOrgDetailId, setTab,
    pendingRedQuestion, setPendingRedQuestion, scheduleItems,
  } = useApp();
  const [input, setInput] = useState('');
  const [thread, setThread] = useState([]);
  const weather = useWeather();

  /* Dynamic intents are checked first and computed from real, live
     state — the schedule, today's actual events, real weather —
     rather than canned strings that can silently go stale or wrong
     the moment the underlying data changes. Static RED_REPLIES only
     covers things with no live state to compute from (dining spots,
     orgs, resources, small talk). */
  const dynamicReply = (low) => {
    if (/class|schedule|next up|where.*(my|i).*(go|be)/.test(low)) {
      const now = new Date();
      const nowM = now.getHours() * 60 + now.getMinutes();
      const sorted = itemsOnDay(scheduleItems, todayCode()).sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
      const next = sorted.find((i) => (toMinutes(i.time) ?? 0) >= nowM);
      if (!next) return { text: 'Nothing left on your schedule today.' };
      const b = buildingById(next.buildingId);
      return { text: `Your next class is ${next.title} in ${b?.name || next.place}, at ${next.time}.`, buildingId: next.buildingId };
    }
    // "What's happening tonight" used to be answered from the
    // global EVENTS array client-side. That array is intentionally
    // empty now (the fabricated placeholder events were cut, not
    // replaced with more placeholders) — leaving this check in
    // would make Ask Red confidently say "nothing tonight" instead
    // of falling through to the real backend, which can actually
    // search live for real current events via the Tavily tool.
    // Deliberately removed rather than left in pointing at nothing.
    if (/weather|rain|hot|cold|outside|jacket/.test(low)) {
      if (weather.loading) return { text: "Still loading today's weather — try again in a second." };
      if (weather.error) return { text: "I can't reach live weather right now." };
      return { text: `It's ${weather.temp}°F and ${weather.condition.toLowerCase()} in ${weather.city} right now.` };
    }
    if (/saved|favorite/.test(low)) {
      if (!savedIds.size) return { text: "You haven't saved anything yet — tap the star on an event in Discover." };
      return { text: `You have ${savedIds.size} saved event${savedIds.size > 1 ? 's' : ''}.`, openTab: 'you' };
    }
    return null;
  };

  /* Order matters here: the canned/dynamic paths are checked FIRST
     because they're instant and guaranteed accurate for the things
     they cover (computed directly from real state, no model in the
     loop to misread anything). Only questions that fall outside
     that coverage go to the real model — grounded in a live data
     snapshot, with a visible "thinking" state since this is a real
     network call with real latency, and a fallback to the static
     canned response if the call fails, so a dropped connection
     degrades gracefully instead of breaking the conversation. */
  const ask = async (text) => {
    const q = (text || input).trim();
    if (!q) return;
    const low = q.toLowerCase();
    setThread((p) => [...p, { role: 'u', text: q }]);
    setInput('');

    const dyn = dynamicReply(low);
    if (dyn) {
      setThread((p) => [...p, { role: 'r', hit: dyn }]);
      return;
    }

    const staticHit = RED_REPLIES.find((r) => r.match.some((m) => low.includes(m)));
    if (staticHit) {
      setThread((p) => [...p, { role: 'r', hit: staticHit }]);
      return;
    }

    const pendingId = `pending-${Date.now()}`;
    setThread((p) => [...p, { role: 'r', pending: true, id: pendingId }]);
    try {
      const context = buildRedContext({ scheduleItems, weather, savedCount: savedIds.size });
      const result = await callAskRed({ question: q, context });
      const replyText = (result && result.data && result.data.text || '').trim()
        || "I don't have verified information on that yet.";
      setThread((p) => p.map((m) => (m.id === pendingId ? { role: 'r', hit: { text: replyText } } : m)));
    } catch (err) {
      setThread((p) => p.map((m) => (m.id === pendingId
        ? { role: 'r', hit: { text: "I couldn't reach the server for that one — try again in a moment." } }
        : m)));
    }
  };

  useEffect(() => {
    if (pendingRedQuestion) {
      ask(pendingRedQuestion);
      setPendingRedQuestion(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={s.sheetBackdrop}>
        <BlurFill t={t} />
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={s.sheet}>
          <Bleed t={t} intensity={1} corner="topRight" />
          <View style={s.sheetHandle} />
          <Text style={s.sheetTitle}>Ask Red</Text>
          <Text style={s.sheetSub}>Anything about campus.</Text>

          <ScrollView style={{ maxHeight: SCREEN_H * 0.42, marginTop: 16 }} showsVerticalScrollIndicator={false}>
            {thread.length === 0 ? RED_SUGGESTIONS.map((q) => (
              <Glass key={q} s={s} t={t} radius={15} lift={0} onPress={() => ask(q)} style={{ marginBottom: 8 }}>
                <View style={s.suggestInner}><Text style={s.suggestText}>{q}</Text></View>
              </Glass>
            )) : thread.map((m, i) => m.role === 'u' ? (
              <View key={i} style={s.bubble}><Text style={s.bubbleText}>{m.text}</Text></View>
            ) : m.pending ? (
              <View key={i} style={{ marginBottom: 14, flexDirection: 'row', alignItems: 'center' }}>
                <ActivityIndicator size="small" color={t.red} />
                <Text style={[s.redText, { marginBottom: 0, marginLeft: 10 }]}>Thinking…</Text>
              </View>
            ) : (
              <View key={i} style={{ marginBottom: 14 }}>
                <Text style={s.redText}>{m.hit.text}</Text>
                {(m.hit.eventIds || []).map((id) => {
                  const e = eventById(id); if (!e) return null;
                  const sv = savedIds.has(e.id);
                  return (
                    <Glass key={id} s={s} t={t} radius={15} style={{ marginBottom: 8 }}>
                      <View style={s.redResult}>
                        <View style={{ flex: 1 }}>
                          <Text style={s.rowTitle}>{e.title}</Text>
                          <Text style={s.rowMeta}>{e.time} · {buildingById(e.buildingId)?.name}</Text>
                        </View>
                        <Pressable onPress={() => toggleSave(e.id)} hitSlop={10} style={{ marginRight: 14 }}>
                          <Icon id="starOutline" size={18} color={sv ? t.red : t.textFaint} strokeWidth={1.8} fill={sv ? t.red : 'none'} />
                        </Pressable>
                        <Pressable onPress={() => { onClose(); setDetailId(e.id); }} hitSlop={10}>
                          <Text style={s.redAction}>View</Text>
                        </Pressable>
                      </View>
                    </Glass>
                  );
                })}
                {(m.hit.buildingIds || []).map((id) => {
                  const b = buildingById(id); if (!b) return null;
                  return <Row key={id} s={s} t={t} title={b.name} meta={metaLine(catLabel(b.kind), walkLabel(b))}
                    onPress={() => { onClose(); goToBuilding(id); }} />;
                })}
                {(m.hit.orgIds || []).map((id) => {
                  const o = ORGS.find((x) => x.id === id); if (!o) return null;
                  return <Row key={id} s={s} t={t} title={o.name} meta={o.tags}
                    onPress={() => { onClose(); setOrgDetailId(id); }} />;
                })}
                {(m.hit.resourceIds || []).map((id) => {
                  const r = RESOURCES.find((x) => x.id === id); if (!r) return null;
                  return <Row key={id} s={s} t={t} title={r.name} meta={r.kind}
                    onPress={() => {
                      if (r.url) { Linking.openURL(r.url); return; }
                      onClose(); goToBuilding(r.buildingId);
                    }} />;
                })}
                {m.hit.buildingId ? (
                  <Row s={s} t={t} title={buildingById(m.hit.buildingId)?.name} meta="Take me there"
                    onPress={() => { onClose(); goToBuilding(m.hit.buildingId); }} />
                ) : null}
                {m.hit.openTab ? (
                  <Row s={s} t={t} title="View saved events" meta="Open in You"
                    onPress={() => { onClose(); setTab(m.hit.openTab); }} />
                ) : null}
              </View>
            ))}
          </ScrollView>

          <View style={s.askRow}>
            <TextInput style={s.askInput} placeholder="Ask anything…" placeholderTextColor={t.textFaint}
              value={input} onChangeText={setInput} onSubmitEditing={() => ask()} returnKeyType="send" />
            <Pressable style={s.askSend} onPress={() => ask()}><Text style={s.askSendText}>↑</Text></Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

/* ============================================================
   THE EVENT — one object, five contexts (section 14)
   ============================================================ */

function DetailSheet({ s, t }) {
  const { detailId, setDetailId, savedIds, toggleSave, addToSchedule, scheduleItems, goToBuilding, liveDetailEvent, setLiveDetailEvent } = useApp();
  const ev = liveDetailEvent || eventById(detailId);
  if (!ev) return null;
  const b = buildingById(ev.buildingId);
  const saved = savedIds.has(ev.id);
  const added = scheduleItems.some((i) => i.id === `sch-${ev.id}`);
  const close = () => { setDetailId(null); setLiveDetailEvent(null); };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={close}>
      <View style={s.sheetBackdrop}>
        <BlurFill t={t} />
        <Pressable style={{ flex: 1 }} onPress={close} />
        <View style={s.sheet}>
          <Bleed t={t} intensity={ev.featured ? 2 : 1} corner="topRight" />
          <View style={s.sheetHandle} />
          <View style={s.detailMetaRow}>
            <Text style={s.detailOrg}>{ev.org}</Text>
            {ev.official ? <Text style={s.detailOfficial}>· Official</Text> : null}
          </View>
          <Text style={s.detailTitle}>{ev.title}</Text>
          <Text style={s.rowMeta}>{ev.date} · {ev.time} – {ev.endTime}</Text>
          <Text style={s.rowMeta}>{b?.name || ev.room}</Text>
          <Text style={s.detailBody}>{ev.desc}</Text>
          <View style={s.detailActions}>
            <Pressable style={added ? s.ghostBtn : s.primaryBtn} onPress={() => !added && addToSchedule(ev)}>
              <Text style={added ? s.ghostBtnText : s.primaryBtnText}>{added ? 'On your schedule' : 'Add to Schedule'}</Text>
            </Pressable>
            <Pressable style={s.ghostBtn} onPress={() => toggleSave(ev.id)}>
              <Text style={s.ghostBtnText}>{saved ? 'Saved' : 'Save'}</Text>
            </Pressable>
            {ev.buildingId ? (
              <Pressable style={s.ghostBtn} onPress={() => goToBuilding(ev.buildingId)}>
                <Text style={s.ghostBtnText}>Navigate</Text>
              </Pressable>
            ) : null}
            {ev.sourceUrl ? (
              <Pressable style={s.ghostBtn} onPress={() => Linking.openURL(ev.sourceUrl)}>
                <Text style={s.ghostBtnText}>Read More</Text>
              </Pressable>
            ) : null}
          </View>
        </View>
      </View>
    </Modal>
  );
}

function OrgDetail({ s, t }) {
  const { orgDetailId, setOrgDetailId, followedOrgIds, toggleFollow, setDetailId } = useApp();
  const org = ORGS.find((o) => o.id === orgDetailId);
  if (!org) return null;
  const following = followedOrgIds.has(org.id);
  const related = EVENTS.filter((e) => e.org === org.name);
  const close = () => setOrgDetailId(null);

  return (
    <Modal visible transparent animationType="slide" onRequestClose={close}>
      <View style={s.sheetBackdrop}>
        <BlurFill t={t} />
        <Pressable style={{ flex: 1 }} onPress={close} />
        <View style={s.sheet}>
          <Bleed t={t} intensity={1} corner="topRight" />
          <View style={s.sheetHandle} />
          <View style={s.orgHeadRow}>
            <View style={s.orgHeadMark}><Text style={s.orgHeadMarkText}>{org.initials}</Text></View>
            <View style={{ flex: 1, marginLeft: 14 }}>
              <Text style={s.detailTitle}>{org.name}</Text>
              <Text style={s.rowMeta}>{org.tags}</Text>
            </View>
          </View>
          <Text style={s.detailBody}>{org.reason}</Text>

          <Pressable
            style={following ? s.ghostBtn : s.primaryBtn}
            onPress={() => toggleFollow(org.id)}
          >
            <Text style={following ? s.ghostBtnText : s.primaryBtnText}>
              {following ? 'Following' : 'Follow'}
            </Text>
          </Pressable>

          {related.length ? (
            <>
              <SectionLabel s={s}>UPCOMING FROM THIS ORG</SectionLabel>
              {related.map((e) => (
                <Row key={e.id} s={s} t={t} title={e.title}
                  meta={metaLine(e.date, e.time, buildingById(e.buildingId)?.name || e.room)}
                  onPress={() => { close(); setDetailId(e.id); }} />
              ))}
            </>
          ) : (
            <Text style={[s.rowMeta, { marginTop: 16 }]}>No upcoming events from this org right now.</Text>
          )}
        </View>
      </View>
    </Modal>
  );
}

/* A generic, honest stand-in for settings that don't have a real
   backing implementation in this prototype yet. Tapping produces
   real feedback — a sheet with a plain description — rather than
   silence, which is worse than admitting a feature isn't built. */
function InfoSheet({ s, t }) {
  const { infoSheet, setInfoSheet } = useApp();
  const COPY = {
    'Favorite places': 'Places you star in Campus will collect here, so you can jump straight to them without searching.',
    'Connected services': 'This is where you\'d link a calendar or campus account so RaiderLoop can read your real schedule instead of the seeded one in this prototype.',
    'Notifications': "You'll get a real device notification 15 minutes before each class today, and before any saved event happening today. If you don't see them, check that notifications are allowed for RaiderLoop in your phone's system settings — the app can't override a denied permission from here.",
    'Privacy & data': 'What RaiderLoop uses and why, in plain language, plus a way to delete your data.',
    'Scan a schedule screenshot': "Reading a schedule photo automatically needs a small backend that can understand the image — not wired up yet. For now, add your classes with the form below; it takes about the same time either way.",
  };
  if (!infoSheet) return null;
  return (
    <Modal visible transparent animationType="fade" onRequestClose={() => setInfoSheet(null)}>
      <View style={s.conflictBackdrop}>
        <BlurFill t={t} />
        <Glass s={s} t={t} radius={20} lift={2} style={{ width: SCREEN_W - 48 }}>
          <View style={{ padding: 22 }}>
            <Text style={s.conflictTitle}>{infoSheet}</Text>
            <Text style={s.rowMeta}>{COPY[infoSheet] || 'Not built out in this prototype yet.'}</Text>
            <Pressable style={[s.ghostBtn, { alignSelf: 'stretch', alignItems: 'center', marginTop: 16, marginRight: 0 }]}
              onPress={() => setInfoSheet(null)}>
              <Text style={s.ghostBtnText}>Close</Text>
            </Pressable>
          </View>
        </Glass>
      </View>
    </Modal>
  );
}

function ConflictPrompt({ s, t }) {
  const { conflict, setConflict, addToSchedule } = useApp();
  if (!conflict) return null;
  return (
    <Modal visible transparent animationType="fade">
      <View style={s.conflictBackdrop}>
        <BlurFill t={t} />
        <Glass s={s} t={t} radius={20} lift={2} style={{ width: SCREEN_W - 48 }}>
          <View style={{ padding: 22 }}>
            <Text style={s.conflictTitle}>Schedule conflict</Text>
            <Text style={s.rowMeta}>
              "{conflict.incoming.title}" overlaps "{conflict.existing.title}" at {conflict.existing.time}.
            </Text>
            <Pressable style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginTop: 18, marginRight: 0 }]}
              onPress={() => { addToSchedule(conflict.incoming, { force: true }); setConflict(null); }}>
              <Text style={s.primaryBtnText}>Add anyway</Text>
            </Pressable>
            <Pressable style={[s.ghostBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0 }]}
              onPress={() => setConflict(null)}>
              <Text style={s.ghostBtnText}>Cancel</Text>
            </Pressable>
          </View>
        </Glass>
      </View>
    </Modal>
  );
}

/* ============================================================
   ONBOARDING — five screens, one flow
   ------------------------------------------------------------
   Sign In is honest in code even though it looks real on screen:
   any non-empty eRaider username/password proceeds. There's no
   backend to check against, so nothing is actually verified.
   Real eRaider SSO is a TTU IT integration well beyond a
   prototype — this is the visual shape of it, not the substance.

   Guest is a genuine fast path, not a shortcut through the same
   forms: it skips profile + interests entirely and drops straight
   into Home with a generic identity.
   ============================================================ */

function OnboardShell({ s, t, children, step }) {
  const fade = useRef(new Animated.Value(0)).current;
  const slide = useRef(new Animated.Value(14)).current;

  useEffect(() => {
    fade.setValue(0);
    slide.setValue(14);
    Animated.parallel([
      Animated.timing(fade, { toValue: 1, duration: 380, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      Animated.timing(slide, { toValue: 0, duration: 380, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
    ]).start();
  }, [step]);

  return (
    <View style={[s.screen, { padding: 26, justifyContent: 'center' }]}>
      <View style={s.onboardProgress}>
        {['signin', 'welcome', 'profile', 'interests', 'schedule', 'confirm'].map((k) => (
          <View key={k} style={[s.onboardDot, k === step && s.onboardDotActive]} />
        ))}
      </View>
      <Animated.View style={{ opacity: fade, transform: [{ translateY: slide }] }}>
        {children}
      </Animated.View>
    </View>
  );
}

function SignInScreen({ s, t }) {
  const { setOnboardStep, setIsGuest, setOnboarded } = useApp();
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const canSignIn = user.trim().length > 0 && pass.length > 0;
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(Animated.timing(pulse, {
      toValue: 1, duration: 2400, easing: Easing.out(Easing.quad), useNativeDriver: true,
    }));
    loop.start();
    return () => loop.stop();
  }, []);
  const ringScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.7] });
  const ringOpacity = pulse.interpolate({ inputRange: [0, 0.15, 1], outputRange: [0.45, 0.35, 0] });

  return (
    <OnboardShell s={s} t={t} step="signin">
      <View style={{ alignItems: 'center', marginBottom: 34 }}>
        <View style={{ width: 60, height: 60, alignItems: 'center', justifyContent: 'center' }}>
          <Animated.View style={{
            position: 'absolute', width: 60, height: 60, borderRadius: 30, backgroundColor: t.red,
            transform: [{ scale: ringScale }], opacity: ringOpacity,
          }} />
          <View style={s.signinMark}>
            <Text style={{ fontSize: 26, fontWeight: '800', color: t.onRed, letterSpacing: -0.5 }}>R</Text>
          </View>
        </View>
        <Text style={[s.brandBig, { marginTop: 16, marginBottom: 0 }]}>RAIDER<Text style={{ color: t.red }}>LOOP</Text></Text>
      </View>

      <Text style={s.onboardTitle}>Sign in with eRaider</Text>
      <Text style={s.onboardSub}>Use your Texas Tech eRaider account.</Text>

      <View style={{ marginTop: 24 }}>
        <TextInput
          style={s.signinInput}
          placeholder="eRaider username"
          placeholderTextColor={t.textFaint}
          autoCapitalize="none"
          value={user}
          onChangeText={setUser}
        />
        <TextInput
          style={[s.signinInput, { marginTop: 10 }]}
          placeholder="Password"
          placeholderTextColor={t.textFaint}
          secureTextEntry
          value={pass}
          onChangeText={setPass}
        />
      </View>

      <Pressable
        style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 18, opacity: canSignIn ? 1 : 0.5 }]}
        disabled={!canSignIn}
        onPress={() => setOnboardStep('welcome')}
      >
        <Text style={s.primaryBtnText}>Sign in with eRaider</Text>
      </Pressable>

      <Pressable
        style={{ alignItems: 'center', marginTop: 16 }}
        onPress={() => { setIsGuest(true); setOnboarded(true); }}
      >
        <Text style={s.signinGuestText}>Continue as Guest</Text>
      </Pressable>
    </OnboardShell>
  );
}

function WelcomeScreen({ s, t }) {
  const { setOnboardStep } = useApp();
  return (
    <View style={{ flex: 1 }}>
      <Image source={{ uri: IMG.library }} style={StyleSheet.absoluteFill} resizeMode="cover" />
      <PhotoOverlay strength={0.86} />
      <OnboardShell s={s} t={t} step="welcome">
        <View style={{ alignItems: 'center' }}>
          <Text style={[s.brandBig, { color: '#FFFFFF' }]}>RAIDER<Text style={{ color: t.red }}>LOOP</Text></Text>
          <Text style={[s.onboardTitle, { textAlign: 'center', marginTop: 18, color: '#FFFFFF' }]}>Everything happening at Texas Tech, in one loop.</Text>
          <Text style={[s.onboardSub, { textAlign: 'center', color: 'rgba(255,255,255,0.82)' }]}>Your schedule, campus, and what's going on today — all in one place.</Text>
        </View>
        <Pressable
          style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 30 }]}
          onPress={() => setOnboardStep('profile')}
        >
          <Text style={s.primaryBtnText}>Get Started</Text>
        </Pressable>
      </OnboardShell>
    </View>
  );
}

/* Real Texas Tech undergraduate majors, pulled from ttu.edu's own
   "Undergraduate Majors" directory and college pages — not a
   generic guessed list. Concentrations/degree-type suffixes
   (B.S., B.A., specific tracks) are collapsed to the base major
   name for a usable picker; the underlying programs are real. */
const MAJORS = [
  'Accounting',
  'Advertising',
  'Agribusiness',
  'Agricultural Communications',
  'Agricultural Education',
  'Agricultural and Applied Economics',
  'Animal Science',
  'Anthropology',
  'Apparel Design and Manufacturing',
  'Applied Leadership',
  'Applied Personal Finance',
  'Architecture',
  'Art',
  'Arts Media and Technology',
  'Arts and Sciences Multidisciplinary Studies',
  'Cell and Molecular Biology',
  'Chemical Engineering',
  'Chemistry',
  'Civil Engineering',
  'Commercial Music',
  'Communication Studies',
  'Computer Engineering',
  'Computer Science',
  'Computing Applications',
  'Conservation Law Enforcement',
  'Construction Engineering',
  'Counseling and Addiction Recovery Sciences',
  'Creative Media Industries',
  'Criminology',
  'Early Childhood Education',
  'Economics',
  'Economics and Mathematics',
  'Education',
  'Electrical Engineering',
  'Energy Commerce',
  'English',
  'Event Management',
  'General Business',
  'General Studies',
  'Geography and the Environment',
  'Geosciences',
  'Global Studies',
  'History',
  'Honors Sciences and the Humanities',
  'Human Development and Family Sciences',
  'Human Resources Development',
  'Human Sciences',
  'Human-Centered Artificial Intelligence',
  'Industrial Engineering',
  'Information Technology',
  'Interdisciplinary Studies',
  'Interior Design',
  'International Economics',
  'Journalism',
  'Kinesiology',
  'Landscape Architecture',
  'Languages and Cultures',
  'Leadership Studies',
  'Legal Studies',
  'Management',
  'Marketing',
  'Mathematics',
  'Mechanical Engineering',
  'Media Strategies',
  'Microbiology',
  'Multidisciplinary Science',
  'Music',
  'Natural Resources Management',
  'Nursing',
  'Nutrition',
  'Nutritional Sciences and Dietetics',
  'Organizational Leadership',
  'Personal Financial Planning',
  'Petroleum Engineering',
  'Philosophy',
  'Physics',
  'Plant and Soil Science',
  'Political Science',
  'Psychological Sciences',
  'Psychology',
  'Public Relations and Strategic Communication Management',
  'Renewable Energy',
  'Restaurant, Hotel, and Institutional Management',
  'Retail Management',
  'Social Work',
  'Sociology',
  'Spanish',
  'Sport Management',
  'Supply Chain Management',
  'Theatre Arts',
  'Visual Studies',
  'Wildlife Biology',
  'Wind Energy',
  'Women\'s and Gender Studies',
  'Writing, Design, and Technical Communication',
  'Zoology'
];

const CLASS_YEARS = ['Freshman', 'Sophomore', 'Junior', 'Senior', 'Grad'];

/* Searchable picker over the real MAJORS list, replacing free text.
   Same reasoning as the building search in ClassForm: a real list
   beats typing, since it can't produce a major that doesn't exist
   and doesn't rely on the student typing TTU's exact program name. */
function MajorPicker({ s, t, value, onSelect, onClose }) {
  const [query, setQuery] = useState('');
  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return MAJORS;
    return MAJORS.filter((m) => m.toLowerCase().includes(q));
  }, [query]);

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={s.sheetBackdrop}>
        <BlurFill t={t} />
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={s.sheet}>
          <View style={s.sheetHandle} />
          <Text style={s.sheetTitle}>Choose Your Major</Text>
          <TextInput
            style={[s.signinInput, { marginTop: 16 }]}
            placeholder="Search majors…"
            placeholderTextColor={t.textFaint}
            value={query}
            onChangeText={setQuery}
            autoFocus
          />
          <ScrollView style={{ maxHeight: SCREEN_H * 0.5, marginTop: 12 }} showsVerticalScrollIndicator={false}>
            {matches.map((m) => (
              <Row key={m} s={s} t={t} title={m}
                right={value === m ? <Icon id="chevron" size={16} color={t.red} strokeWidth={2.2} /> : undefined}
                onPress={() => { onSelect(m); onClose(); }} />
            ))}
            {!matches.length ? <Text style={s.emptyBody}>No major matches "{query}".</Text> : null}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

function ProfileScreen({ s, t }) {
  const { setOnboardStep, userName, setUserName, userMajor, setUserMajor, userClassYear, setUserClassYear } = useApp();
  const [pickerOpen, setPickerOpen] = useState(false);
  const canContinue = userName.trim().length > 0;

  return (
    <>
      <OnboardShell s={s} t={t} step="profile">
      <Text style={s.onboardTitle}>Tell us about you</Text>
      <Text style={s.onboardSub}>This is what shows on your profile.</Text>

      <View style={{ marginTop: 22 }}>
        <TextInput
          style={s.signinInput}
          placeholder="Full name"
          placeholderTextColor={t.textFaint}
          value={userName}
          onChangeText={setUserName}
        />
        <Pressable style={[s.signinInput, { marginTop: 10, justifyContent: 'center' }]} onPress={() => setPickerOpen(true)}>
          <Text style={{ fontSize: 15, color: userMajor ? t.text : t.textFaint }}>
            {userMajor || 'Choose your major'}
          </Text>
        </Pressable>
      </View>

      <Text style={[s.sectionLabel, { marginTop: 20, marginBottom: 10 }]}>CLASS YEAR</Text>
      <View style={s.pillWrap}>
        {CLASS_YEARS.map((y) => (
          <Pill key={y} s={s} t={t} label={y} active={userClassYear === y} onPress={() => setUserClassYear(y)} />
        ))}
      </View>

      <Pressable
        style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 22, opacity: canContinue ? 1 : 0.5 }]}
        disabled={!canContinue}
        onPress={() => setOnboardStep('interests')}
      >
        <Text style={s.primaryBtnText}>Continue</Text>
      </Pressable>
      </OnboardShell>
      {pickerOpen ? (
        <MajorPicker s={s} t={t} value={userMajor} onSelect={setUserMajor} onClose={() => setPickerOpen(false)} />
      ) : null}
    </>
  );
}

function InterestsScreen({ s, t }) {
  const { setOnboardStep, interests, setInterests } = useApp();
  const toggle = (i) => setInterests((p) => (p.includes(i) ? p.filter((x) => x !== i) : [...p, i]));

  return (
    <OnboardShell s={s} t={t} step="interests">
      <Text style={s.onboardTitle}>What are you into?</Text>
      <Text style={s.onboardSub}>This shapes what RaiderLoop shows you.</Text>
      <View style={[s.tagCloud, { marginTop: 22 }]}>
        {INTERESTS.map((i) => {
          const active = interests.includes(i);
          return (
            <Pressable key={i} onPress={() => toggle(i)} style={[s.tagChip, active && { backgroundColor: t.red, borderColor: t.red }]}>
              <View style={{ marginRight: 6 }}>
                <Icon id={i} size={15} color={active ? t.onRed : t.textMuted} strokeWidth={2} />
              </View>
              <Text style={[s.tagLabel, active && { color: t.onRed }]}>{i}</Text>
            </Pressable>
          );
        })}
      </View>
      <Pressable
        style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 22 }]}
        onPress={() => setOnboardStep('schedule')}
      >
        <Text style={s.primaryBtnText}>{interests.length ? `Continue with ${interests.length}` : 'Skip for now'}</Text>
      </Pressable>
    </OnboardShell>
  );
}

/* Starts genuinely empty — not pre-filled with the seeded demo
   classes — so completing onboarding for real (versus Guest mode,
   which keeps the seed) produces an honest schedule: whatever the
   person actually enters, or nothing if they skip. */
function ScheduleSetupScreen({ s, t }) {
  const { setOnboardStep, replaceSchedule } = useApp();
  const [draft, setDraft] = useState([]);
  const [editing, setEditing] = useState(null);

  const finish = () => { replaceSchedule(draft); setOnboardStep('confirm'); };

  return (
    <>
      <OnboardShell s={s} t={t} step="schedule">
        <Text style={s.onboardTitle}>Add your classes</Text>
        <Text style={s.onboardSub}>Real building, real days — this is what powers Next Up and Schedule.</Text>

        <View style={{ marginTop: 18 }}>
          {draft.map((c) => (
            <Row key={c.id} s={s} t={t} title={c.title}
              meta={`${(c.days || []).join('/')} · ${c.time} · ${c.place}`}
              onPress={() => setEditing(c)} />
          ))}
          <Pressable
            style={[s.ghostBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0 }]}
            onPress={() => setEditing('new')}
          >
            <Text style={s.ghostBtnText}>+ Add a Class</Text>
          </Pressable>

          <ScanEntryPoint s={s} t={t} onConfirm={(items) => setDraft((p) => [...p, ...items])} />
        </View>

        <Pressable
          style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 18 }]}
          onPress={finish}
        >
          <Text style={s.primaryBtnText}>{draft.length ? `Continue with ${draft.length}` : 'Skip for now'}</Text>
        </Pressable>
      </OnboardShell>

      {editing ? (
        <ClassFormDraft
          s={s} t={t}
          existing={editing === 'new' ? null : editing}
          onSave={(item) => {
            setDraft((p) => (editing === 'new' ? [...p, item] : p.map((x) => (x.id === editing.id ? item : x))));
            setEditing(null);
          }}
          onRemove={() => { setDraft((p) => p.filter((x) => x.id !== editing.id)); setEditing(null); }}
          onClose={() => setEditing(null)}
        />
      ) : null}
    </>
  );
}

/* A local, draft-only twin of ClassForm — onboarding hasn't
   created a real schedule item yet (no context to save into), so
   this builds the object in place and hands it back via onSave
   rather than writing through addClass/updateClass directly. */
function ClassFormDraft({ s, t, existing, onSave, onRemove, onClose }) {
  const [title, setTitle] = useState(existing?.title || '');
  const [time, setTime] = useState(existing?.time || '');
  const [endTime, setEndTime] = useState(existing?.endTime || '');
  const [days, setDays] = useState(existing?.days || []);
  const [buildingQuery, setBuildingQuery] = useState('');
  const [buildingId, setBuildingId] = useState(existing?.buildingId || null);
  const [room, setRoom] = useState(existing?.place?.split(' ').slice(-1)[0] || '');

  const toggleDay = (d) => setDays((p) => (p.includes(d) ? p.filter((x) => x !== d) : [...p, d]));
  const buildingMatches = useMemo(() => {
    const q = buildingQuery.trim().toLowerCase();
    if (!q) return [];
    return BUILDINGS.filter((b) => b.name.toLowerCase().includes(q)).slice(0, 6);
  }, [buildingQuery]);
  const selectedBuilding = buildingId ? buildingById(buildingId) : null;
  const timeValid = toMinutes(time) !== null;
  const endValid = toMinutes(endTime) !== null;
  const canSave = title.trim() && timeValid && endValid && days.length > 0 && buildingId;

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={s.sheetBackdrop}>
        <BlurFill t={t} />
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={s.sheet}>
          <View style={s.sheetHandle} />
          <Text style={s.sheetTitle}>{existing ? 'Edit Class' : 'Add a Class'}</Text>

          <ScrollView style={{ maxHeight: SCREEN_H * 0.5, marginTop: 16 }} showsVerticalScrollIndicator={false}>
            <TextInput style={s.signinInput} placeholder="Course (e.g. CS 1412)"
              placeholderTextColor={t.textFaint} value={title} onChangeText={setTitle} />
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
              <TextInput style={[s.signinInput, { flex: 1 }, time && !timeValid && { borderColor: t.red }]}
                placeholder="9:00 AM" placeholderTextColor={t.textFaint} value={time} onChangeText={setTime} />
              <TextInput style={[s.signinInput, { flex: 1 }, endTime && !endValid && { borderColor: t.red }]}
                placeholder="9:50 AM" placeholderTextColor={t.textFaint} value={endTime} onChangeText={setEndTime} />
            </View>
            {(time && !timeValid) || (endTime && !endValid) ? (
              <Text style={s.classFormError}>Use a format like "9:00 AM".</Text>
            ) : null}
            <Text style={[s.sectionLabel, { marginTop: 18, marginBottom: 10 }]}>DAYS</Text>
            <View style={s.pillWrap}>
              {DAY_OPTIONS.map((d) => (
                <Pill key={d} s={s} t={t} label={WEEK_DAY_LABELS[d]} active={days.includes(d)} onPress={() => toggleDay(d)} />
              ))}
            </View>
            <Text style={[s.sectionLabel, { marginTop: 18, marginBottom: 10 }]}>BUILDING</Text>
            {selectedBuilding ? (
              <Row s={s} t={t} title={selectedBuilding.name} meta={selectedBuilding.kind}
                onPress={() => { setBuildingId(null); setBuildingQuery(''); }}
                right={<Text style={s.classFormClear}>Change</Text>} />
            ) : (
              <>
                <TextInput style={s.signinInput} placeholder="Search buildings…"
                  placeholderTextColor={t.textFaint} value={buildingQuery} onChangeText={setBuildingQuery} />
                {buildingMatches.map((b) => (
                  <Row key={b.id} s={s} t={t} title={b.name} meta={catLabel(b.kind)}
                    onPress={() => { setBuildingId(b.id); setBuildingQuery(''); }} />
                ))}
              </>
            )}
            <TextInput style={[s.signinInput, { marginTop: 10 }]} placeholder="Room (optional)"
              placeholderTextColor={t.textFaint} value={room} onChangeText={setRoom} />
          </ScrollView>

          <Pressable
            style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 18, opacity: canSave ? 1 : 0.5 }]}
            disabled={!canSave}
            onPress={() => onSave({
              id: existing?.id || `cls-${Date.now()}`, title: title.trim(), time, endTime, days, buildingId, type: 'class',
              place: `${selectedBuilding?.name || ''}${room ? ' ' + room : ''}`,
            })}
          >
            <Text style={s.primaryBtnText}>{existing ? 'Save Changes' : 'Add Class'}</Text>
          </Pressable>
          {existing ? (
            <Pressable style={[s.ghostBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0 }]} onPress={onRemove}>
              <Text style={[s.ghostBtnText, { color: t.red }]}>Remove Class</Text>
            </Pressable>
          ) : null}
        </View>
      </View>
    </Modal>
  );
}

/* Matches the free-text building name a vision model read off a
   screenshot against the real 199-building list. Exact match first,
   then substring either direction, then word-overlap as a last
   resort. Returns null rather than guessing wildly — a null match
   just means the review screen shows "no building matched" and lets
   the student pick manually, which is safer than silently attaching
   the wrong location to a class. */
function matchBuildingName(rawName) {
  if (!rawName) return null;
  const q = rawName.toLowerCase().trim();
  let hit = BUILDINGS.find((b) => b.name.toLowerCase() === q);
  if (hit) return hit.id;
  hit = BUILDINGS.find((b) => b.name.toLowerCase().includes(q) || q.includes(b.name.toLowerCase()));
  if (hit) return hit.id;
  const qWords = q.split(/\s+/).filter((w) => w.length > 2);
  let best = null, bestScore = 0;
  for (const b of BUILDINGS) {
    const bWords = b.name.toLowerCase().split(/\s+/);
    const score = qWords.filter((w) => bWords.some((bw) => bw.includes(w) || w.includes(bw))).length;
    if (score > bestScore) { bestScore = score; best = b; }
  }
  return bestScore > 0 ? best.id : null;
}

/* Every scanned class must be reviewed and confirmed before it's
   saved anywhere — a vision model can misread a screenshot, and
   silently trusting it would violate the same honesty rule as
   everything else built tonight. Editing a row re-uses
   ClassFormDraft, the same validated form manual entry uses. */
function ScanReviewSheet({ s, t, rawClasses, onConfirm, onClose }) {
  const [items, setItems] = useState(() => rawClasses.map((c, i) => ({
    id: `scan-${i}`,
    title: c.title || '',
    time: c.time || '',
    endTime: c.endTime || '',
    days: Array.isArray(c.days) ? c.days : [],
    buildingId: matchBuildingName(c.building),
    buildingRaw: c.building || '',
  })));
  const [editing, setEditing] = useState(null);

  const remove = (id) => setItems((p) => p.filter((x) => x.id !== id));
  const isValid = (i) => i.title && toMinutes(i.time) !== null && toMinutes(i.endTime) !== null && i.days.length && i.buildingId;
  /* Scanned classes carry only a buildingId, but every other part
     of the app displays a class's location from a `place` string —
     the manual ClassForm builds one, the scan path never did, so
     scanned classes rendered as "undefined". Built here, at the
     single point where scanned items are finalized, so both
     onboarding and Manage Schedule get the fix rather than only one. */
  const validItems = items.filter(isValid).map((i) => ({
    ...i,
    place: `${buildingById(i.buildingId)?.name || ''}${i.room ? ' ' + i.room : ''}`.trim(),
    type: 'class',
  }));

  return (
    <>
      <Modal visible transparent animationType="slide" onRequestClose={onClose}>
        <View style={s.sheetBackdrop}>
          <BlurFill t={t} />
          <Pressable style={{ flex: 1 }} onPress={onClose} />
          <View style={s.sheet}>
            <View style={s.sheetHandle} />
            <Text style={s.sheetTitle}>Review Scanned Classes</Text>
            <Text style={s.sheetSub}>Check these before adding — scanning can misread a screenshot.</Text>

            <ScrollView style={{ maxHeight: SCREEN_H * 0.5, marginTop: 16 }} showsVerticalScrollIndicator={false}>
              {items.length ? items.map((i) => {
                const b = i.buildingId ? buildingById(i.buildingId) : null;
                const ok = isValid(i);
                return (
                  <Row key={i.id} s={s} t={t}
                    title={i.title || '(no title read)'}
                    meta={`${i.days.join('/') || 'no days'} · ${i.time || '?'}-${i.endTime || '?'} · ${b ? b.name : i.buildingRaw ? `"${i.buildingRaw}" — no match, tap to fix` : 'no building'}`}
                    note={!ok ? 'Tap to fix before adding' : undefined}
                    onPress={() => setEditing(i)}
                    right={<Pressable onPress={() => remove(i.id)} hitSlop={10}><Text style={s.classFormClear}>Remove</Text></Pressable>}
                  />
                );
              }) : <Text style={s.emptyBody}>Nothing was read from that image.</Text>}
            </ScrollView>

            <Pressable
              style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 18, opacity: validItems.length ? 1 : 0.5 }]}
              disabled={!validItems.length}
              onPress={() => onConfirm(validItems)}
            >
              <Text style={s.primaryBtnText}>Add {validItems.length} {validItems.length === 1 ? 'Class' : 'Classes'}</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
      {editing ? (
        <ClassFormDraft
          s={s} t={t} existing={editing}
          onSave={(item) => { setItems((p) => p.map((x) => (x.id === editing.id ? { ...item, id: editing.id, buildingRaw: '' } : x))); setEditing(null); }}
          onRemove={() => { remove(editing.id); setEditing(null); }}
          onClose={() => setEditing(null)}
        />
      ) : null}
    </>
  );
}

/* The real, working entry point for screenshot scanning — picks an
   image, sends it to the real parseSchedule backend, and opens the
   review sheet on success. Every failure mode (no picker installed,
   permission denied, cancelled, backend error, nothing readable)
   gets its own honest message rather than a silent failure or a
   generic error. */
/* Screenshots are virtually always PNG, but the image picker's
   reported mimeType is sometimes empty or wrong depending on
   platform/OS version. Rather than trust that field (or silently
   fall back to a hardcoded default that could mismatch the real
   file), this reads the actual magic bytes at the start of the
   base64 payload — the one thing that can't lie about what the
   file actually is. A media-type mismatch reaching the vision API
   is a very plausible cause of "couldn't read that image" failures
   that otherwise look mysterious. */
function sniffImageMediaType(base64) {
  const head = (base64 || '').slice(0, 16);
  if (head.startsWith('iVBORw0KGgo')) return 'image/png';
  if (head.startsWith('/9j/')) return 'image/jpeg';
  if (head.startsWith('R0lGOD')) return 'image/gif';
  if (head.startsWith('UklGR')) return 'image/webp';
  return null;
}

function ScanEntryPoint({ s, t, onConfirm }) {
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState(null);
  const [review, setReview] = useState(null);

  const start = async () => {
    setError(null);
    if (!ImagePicker) { setError("Image scanning isn't available in this build yet."); return; }
    setScanning(true);
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) { setError('Permission to access photos was denied.'); setScanning(false); return; }
      const result = await ImagePicker.launchImageLibraryAsync({
        base64: true, quality: 0.7, mediaTypes: ImagePicker.MediaTypeOptions.Images,
      });
      if (result.canceled) { setScanning(false); return; }
      const asset = result.assets[0];
      const mediaType = sniffImageMediaType(asset.base64) || asset.mimeType || 'image/jpeg';
      const res = await callParseSchedule({ imageBase64: asset.base64, mediaType });
      const classes = (res && res.data && res.data.classes) || [];
      setScanning(false);
      if (!classes.length) { setError("Couldn't read any classes from that image — try a clearer screenshot."); return; }
      setReview(classes);
    } catch (e) {
      setScanning(false);
      // Surface the REAL error rather than a generic message —
      // otherwise a genuine backend/network problem is impossible
      // to tell apart from "the image was just unreadable."
      console.error('parseSchedule failed:', e);
      const detail = (e && (e.message || e.details || e.code)) || 'unknown error';
      setError(`Couldn't read that image: ${detail}`);
    }
  };

  return (
    <>
      <Pressable style={{ alignItems: 'center', marginTop: 16 }} onPress={start} disabled={scanning}>
        {scanning ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <ActivityIndicator size="small" color={t.red} />
            <Text style={s.signinGuestText}>Reading your schedule…</Text>
          </View>
        ) : (
          <Text style={s.signinGuestText}>Or scan a schedule screenshot instead</Text>
        )}
      </Pressable>
      {error ? <Text style={[s.classFormError, { textAlign: 'center', marginTop: 8 }]}>{error}</Text> : null}
      {review ? (
        <ScanReviewSheet
          s={s} t={t} rawClasses={review}
          onConfirm={(items) => { setReview(null); onConfirm(items); }}
          onClose={() => setReview(null)}
        />
      ) : null}
    </>
  );
}

function ConfirmScreen({ s, t }) {
  const { setOnboarded, setOnboardStep, userName, userMajor, userClassYear, interests } = useApp();
  const first = userName.trim().split(' ')[0] || 'Red Raider';

  return (
    <OnboardShell s={s} t={t} step="confirm">
      <View style={{ alignItems: 'center' }}>
        <View style={s.signinMark}>
          {Svg ? (
            <Svg width={26} height={26} viewBox="0 0 24 24">
              <Path d="M5 13l4 4L19 7" stroke={t.onRed} strokeWidth="2.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
            </Svg>
          ) : null}
        </View>
        <Text style={[s.onboardTitle, { textAlign: 'center', marginTop: 16 }]}>You're in the loop, {first}.</Text>
        <Text style={[s.onboardSub, { textAlign: 'center' }]}>
          {[userMajor, userClassYear].filter(Boolean).join(' · ') || 'Profile saved'}
        </Text>
        {interests.length ? (
          <View style={[s.pillWrap, { marginTop: 14, justifyContent: 'center' }]}>
            {interests.map((i) => (
              <View key={i} style={s.confirmChip}><Text style={s.confirmChipText}>{i}</Text></View>
            ))}
          </View>
        ) : null}
      </View>
      <Pressable
        style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 26 }]}
        onPress={() => setOnboardStep('tour')}
      >
        <Text style={s.primaryBtnText}>Enter RaiderLoop</Text>
      </Pressable>
    </OnboardShell>
  );
}

const TOUR_STEPS = [
  { id: 'home', title: 'Home', desc: 'Your next class, real weather, and real Texas Tech news — one glance, every morning.' },
  { id: 'discover', title: 'Discover', desc: 'Real events, dining, orgs, and athletics — search or browse the grid.' },
  { id: 'campus', title: 'Campus', desc: 'A real map of 199 campus buildings, with real walking directions.' },
  { id: 'schedule', title: 'Schedule', desc: 'Your real classes, day or week view, with a live tracker for right now.' },
  { id: 'you', title: 'You', desc: 'Your profile, saved events, interests, and settings.' },
];

/* A quick, one-time walkthrough after onboarding — mainly for
   someone trying this without you narrating over their shoulder.
   Doesn't gate anything; skippable at any point. */
function TourScreen({ s, t }) {
  const { setOnboarded } = useApp();
  const [i, setI] = useState(0);
  const step = TOUR_STEPS[i];
  const isLast = i === TOUR_STEPS.length - 1;

  return (
    <View style={[s.screen, { padding: 26, justifyContent: 'center' }]}>
      <View style={s.onboardProgress}>
        {TOUR_STEPS.map((ts, idx) => (
          <View key={ts.id} style={[s.onboardDot, idx === i && s.onboardDotActive]} />
        ))}
      </View>
      <View style={{ alignItems: 'center' }}>
        <View style={s.signinMark}>
          <TabGlyph t={t} id={step.id} active />
        </View>
        <Text style={[s.onboardTitle, { textAlign: 'center', marginTop: 18 }]}>{step.title}</Text>
        <Text style={[s.onboardSub, { textAlign: 'center' }]}>{step.desc}</Text>
      </View>
      <Pressable
        style={[s.primaryBtn, { alignSelf: 'stretch', alignItems: 'center', marginRight: 0, marginTop: 30 }]}
        onPress={() => (isLast ? setOnboarded(true) : setI(i + 1))}
      >
        <Text style={s.primaryBtnText}>{isLast ? 'Get Started' : 'Next'}</Text>
      </Pressable>
      {!isLast ? (
        <Pressable style={{ alignItems: 'center', marginTop: 14 }} onPress={() => setOnboarded(true)}>
          <Text style={s.signinGuestText}>Skip tour</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

function Onboarding({ s, t }) {
  const { onboardStep } = useApp();
  if (onboardStep === 'welcome') return <WelcomeScreen s={s} t={t} />;
  if (onboardStep === 'profile') return <ProfileScreen s={s} t={t} />;
  if (onboardStep === 'interests') return <InterestsScreen s={s} t={t} />;
  if (onboardStep === 'schedule') return <ScheduleSetupScreen s={s} t={t} />;
  if (onboardStep === 'confirm') return <ConfirmScreen s={s} t={t} />;
  if (onboardStep === 'tour') return <TourScreen s={s} t={t} />;
  return <SignInScreen s={s} t={t} />;
}

/* ============================================================
   SHELL — structural navigation stays predictable (section 19)
   ============================================================ */

const TABS = [
  { id: 'home', label: 'Home' },
  { id: 'discover', label: 'Discover' },
  { id: 'campus', label: 'Campus' },
  { id: 'schedule', label: 'Schedule' },
  { id: 'you', label: 'You' },
];

/* Ask Red should feel active across every screen, per the
   feedback — a soft pulsing ring rather than a static pill. */
function AskRedFab({ s, t, onPress }) {
  const pulse = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(Animated.timing(pulse, {
      toValue: 1, duration: 2200, easing: Easing.out(Easing.quad), useNativeDriver: true,
    }));
    loop.start();
    return () => loop.stop();
  }, []);
  const ringScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.55] });
  const ringOpacity = pulse.interpolate({ inputRange: [0, 0.15, 1], outputRange: [0.5, 0.4, 0] });

  return (
    <View style={s.redFabWrap} pointerEvents="box-none">
      <Animated.View style={[s.redFabRing, { transform: [{ scale: ringScale }], opacity: ringOpacity }]} />
      <Pressable style={s.redFab} onPress={onPress}>
        <View style={s.redFabDot} />
        <Text style={s.redFabText}>Ask Red</Text>
      </Pressable>
    </View>
  );
}

function Shell({ s, t, dark, setDark }) {
  const { tab, setTab, onboarded, detailId, conflict, redOpen, setRedOpen, orgDetailId, infoSheet, hydrated, liveDetailEvent, scheduleItems, savedIds } = useApp();
  useScheduleNotifications(scheduleItems, savedIds);

  if (!hydrated) {
    return (
      <SafeAreaView style={[s.root, { backgroundColor: t.canvas, alignItems: 'center', justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color={t.red} />
      </SafeAreaView>
    );
  }
  if (!onboarded) {
    return <SafeAreaView style={[s.root, { backgroundColor: t.canvas }]}><Onboarding s={s} t={t} /></SafeAreaView>;
  }
  return (
    <SafeAreaView style={[s.root, { backgroundColor: t.canvas }]}>
      <StatusBar barStyle={dark ? 'light-content' : 'dark-content'} />
      <View style={{ flex: 1 }}>
        {tab === 'home' && <HomeScreen s={s} t={t} />}
        {tab === 'discover' && <DiscoverScreen s={s} t={t} />}
        {tab === 'campus' && <CampusScreen s={s} t={t} />}
        {tab === 'schedule' && <ScheduleScreen s={s} t={t} />}
        {tab === 'you' && <YouScreen s={s} t={t} dark={dark} setDark={setDark} />}
      </View>

      <AskRedFab s={s} t={t} onPress={() => setRedOpen(true)} />

      <View style={s.navWrap}>
        <View style={s.nav}>
          <BlurFill t={t} style={s.navBlurFill} />
          {TABS.map((x) => {
            const active = tab === x.id;
            return (
              <Pressable key={x.id} style={s.navItem} onPress={() => setTab(x.id)}>
                <TabGlyph t={t} id={x.id} active={active} />
                <Text style={[s.navLabel, active && { color: t.red, fontWeight: '700' }]}>{x.label}</Text>
              </Pressable>
            );
          })}
        </View>
      </View>

      {redOpen ? <AskRed s={s} t={t} onClose={() => setRedOpen(false)} /> : null}
      {detailId || liveDetailEvent ? <DetailSheet s={s} t={t} /> : null}
      {orgDetailId ? <OrgDetail s={s} t={t} /> : null}
      {infoSheet ? <InfoSheet s={s} t={t} /> : null}
      {conflict ? <ConflictPrompt s={s} t={t} /> : null}
    </SafeAreaView>
  );
}

/* ============================================================
   ERROR BOUNDARY
   ------------------------------------------------------------
   Without this, any single unexpected render error anywhere in
   the app — one bad screen, one bad piece of data — takes the
   whole thing to a white screen with no way back short of force-
   quitting. This catches it, shows a plain explanation instead
   of a crash, and lets the person try again without restarting
   the app entirely. Cheap insurance, worth having before this is
   ever in front of someone who isn't you.
   ============================================================ */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(error, info) {
    console.error('RaiderLoop crashed:', error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <SafeAreaView style={{ flex: 1, backgroundColor: '#121011', alignItems: 'center', justifyContent: 'center', padding: 32 }}>
          <Text style={{ fontSize: 20, fontWeight: '700', color: '#F6F2F0', marginBottom: 10, textAlign: 'center' }}>
            Something went wrong
          </Text>
          <Text style={{ fontSize: 14, color: '#9B918C', textAlign: 'center', marginBottom: 22, lineHeight: 20 }}>
            RaiderLoop hit an unexpected error. This usually clears up on retry.
          </Text>
          <Pressable
            style={{ backgroundColor: '#CC0000', borderRadius: 12, paddingVertical: 13, paddingHorizontal: 26 }}
            onPress={() => this.setState({ hasError: false })}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: '700', fontSize: 14.5 }}>Try Again</Text>
          </Pressable>
        </SafeAreaView>
      );
    }
    return this.props.children;
  }
}

export default function Index() {
  const [dark, setDark] = useState(true); // dark is now the default theme
  const t = dark ? darkTheme : lightTheme;
  const s = useMemo(() => makeStyles(t), [t]);
  return (
    <ErrorBoundary>
      <AppProvider><Shell s={s} t={t} dark={dark} setDark={setDark} /></AppProvider>
    </ErrorBoundary>
  );
}

/* ============================================================
   STYLES
   ============================================================ */

function makeStyles(t) {
  return StyleSheet.create({
    root: { flex: 1, paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0 },
    screen: { flex: 1 },
    /* Bottom clearance math, since this caused real overlap on device:
       the nav bar is ~84px tall on iOS (26 safe-area + ~54 row + 4),
       and the Ask Red FAB sits at bottom:104 with a ~48px body plus
       its glow ring, so its top edge lands near 160px. Content needs
       to clear THAT, not just the nav bar — 168 left only ~8px of
       breathing room, which read as an overlap. */
    screenContent: { paddingHorizontal: PAD, paddingTop: 10, paddingBottom: 210 },

    /* Shared by Campus's selected-building card and Schedule's
       next-fixture card — not Home anymore, but still real users. */
    nextInner: { padding: 20 },
    nextTitle: { fontSize: 21, fontWeight: '700', color: t.text, letterSpacing: -0.4 },
    nextMeta: { fontSize: 14, color: t.textMuted, marginTop: 5 },

    /* HOME — greeting */
    greetRow: { flexDirection: 'row', alignItems: 'flex-start' },
    greetTitle: { fontSize: 22, fontWeight: '700', color: t.text, letterSpacing: -0.4 },
    greetDate: { fontSize: 13.5, color: t.textMuted, marginTop: 3 },
    greetWeatherRow: { flexDirection: 'row', alignItems: 'center', marginTop: 8, gap: 6 },
    greetWeatherText: { fontSize: 13, color: t.textMuted, fontWeight: '500', ...NUM },
    bellBtn: {
      width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center',
      backgroundColor: t.surface, borderWidth: 0.5, borderColor: t.border,
    },

    /* HOME — Next Up, dark glass */
    nextDarkInner: { padding: 20 },
    nextDarkKicker: { fontSize: 11, fontWeight: '800', letterSpacing: 1.3, color: t.red },
    nextDarkTitle: { fontSize: 20, fontWeight: '700', color: t.text, marginTop: 8, letterSpacing: -0.3, lineHeight: 25 },
    nextDarkLocRow: { flexDirection: 'row', alignItems: 'center', marginTop: 10, gap: 6 },
    nextDarkLocText: { fontSize: 13.5, color: t.textMuted, ...NUM },
    nextDarkCountdown: { fontSize: 13, color: t.textFaint, marginTop: 8 },
    nextDarkDivider: { height: 1, backgroundColor: t.border, marginTop: 18, marginBottom: 4 },
    nextDarkActions: { flexDirection: 'row', paddingTop: 12 },
    nextDarkAction: { flexDirection: 'row', alignItems: 'center', gap: 7, marginRight: 26 },
    nextDarkActionText: { fontSize: 13, fontWeight: '600', color: t.text },

    /* IN THE LOOP — hero + compact list */
    newsHeroBody: { padding: 16 },
    newsHeadline: { fontSize: 17, fontWeight: '700', color: t.text, lineHeight: 22, letterSpacing: -0.3 },
    newsSourceOfficial: { fontSize: 12, fontWeight: '700', color: t.red, marginTop: 6 },
    newsSourceText: { fontSize: 12, fontWeight: '600', color: t.textMuted, marginTop: 6 },
    newsExcerpt: { fontSize: 13.5, color: t.textMuted, marginTop: 6, lineHeight: 19 },
    newsRow: { flexDirection: 'row', alignItems: 'center', padding: 12 },
    newsRowThumb: { width: 56, height: 56, borderRadius: 12, marginRight: 12 },
    newsRowTitle: { fontSize: 14, fontWeight: '600', color: t.text, lineHeight: 18 },


    timeChip: {
      width: 52, height: 52, borderRadius: 13, backgroundColor: t.surfaceAlt,
      alignItems: 'center', justifyContent: 'center', marginRight: 14,
      borderWidth: 1, borderColor: t.border,
    },
    timeChipTime: { fontSize: 12.5, fontWeight: '800', color: t.text, letterSpacing: -0.2 },

    updateInner: { padding: 18 },
    updateTitle: { fontSize: 15, fontWeight: '700', color: t.text },
    updateBody: { fontSize: 13.5, color: t.textMuted, marginTop: 5, lineHeight: 19 },
    updateSource: { fontSize: 11, color: t.textFaint, marginTop: 10, fontWeight: '600', letterSpacing: 0.3 },

    /* SHARED */
    sectionHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 28, marginBottom: 11 },
    sectionLabel: { fontSize: 10.5, fontWeight: '700', letterSpacing: 1.5, color: t.textFaint },
    sectionAction: { fontSize: 13, color: t.red, fontWeight: '600' },
    pageTitle: { fontSize: 30, fontWeight: '700', color: t.text, letterSpacing: -0.8, marginBottom: 4 },
    pageSub: { fontSize: 14.5, color: t.textMuted, marginBottom: 18 },
    brandBig: { fontSize: 17, fontWeight: '800', letterSpacing: 2, color: t.text, marginBottom: 30 },

    rowInner: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16 },
    groupedList: { borderRadius: 18, backgroundColor: t.surface, overflow: 'hidden', borderWidth: 0.5, borderColor: t.border },
    groupedRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16 },
    groupedRowDivider: { borderBottomWidth: 0.5, borderBottomColor: t.border },
    rowTitle: { fontSize: 15, fontWeight: '600', color: t.text },
    rowMeta: { fontSize: 13, color: t.textMuted, marginTop: 3, lineHeight: 18 },
    rowNote: { fontSize: 12, color: t.red, marginTop: 5, fontWeight: '600' },

    search: { flexDirection: 'row', alignItems: 'center', backgroundColor: t.surfaceAlt, borderRadius: 15, borderWidth: 1, borderColor: t.border, paddingHorizontal: 14, height: 48 },
    searchIcon: { fontSize: 17, color: t.textFaint, marginRight: 9 },
    searchInput: { flex: 1, fontSize: 15, color: t.text, padding: 0 },
    pill: { borderRadius: 999, borderWidth: 1, borderColor: t.borderStrong, backgroundColor: t.surface, paddingHorizontal: 15, paddingVertical: 8, marginRight: 8, marginBottom: 8 },
    pillText: { fontSize: 13, color: t.text, fontWeight: '600' },
    pillWrap: { flexDirection: 'row', flexWrap: 'wrap' },

    /* GRID */
    gridRow: { flexDirection: 'row', justifyContent: 'space-between' },
    tileKicker: { fontSize: 9.5, fontWeight: '800', letterSpacing: 1.4, color: t.textFaint },
    tileIconRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
    tileSub: { fontSize: 12, color: t.textMuted, marginTop: 6 },
    tileTall: { padding: 16, minHeight: 138, justifyContent: 'space-between' },
    tileUtility: { padding: 16, minHeight: 138 },

    featInner: { padding: 20, minHeight: 200, justifyContent: 'flex-end' },
    featTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
    featEyebrow: { fontSize: 10.5, fontWeight: '800', letterSpacing: 1.3, color: t.red },
    featEyebrowPhoto: { fontSize: 10.5, fontWeight: '800', letterSpacing: 1.3, color: '#FFFFFF' },
    featTitle: { fontSize: 28, fontWeight: '700', color: t.text, letterSpacing: -0.9, marginTop: 18, lineHeight: 32 },
    featTitlePhoto: { fontSize: 26, fontWeight: '800', color: '#FFFFFF', letterSpacing: -0.7, marginTop: 10, lineHeight: 30 },
    featMeta: { fontSize: 14, color: t.textMuted, marginTop: 6 },
    featMetaPhoto: { fontSize: 13.5, color: 'rgba(255,255,255,0.85)', marginTop: 5 },
    featTag: { alignSelf: 'flex-start', marginTop: 14, backgroundColor: t.red, borderRadius: 6, paddingHorizontal: 9, paddingVertical: 4 },
    featTagText: { color: t.onRed, fontSize: 9, fontWeight: '800', letterSpacing: 1.1 },
    liveBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: t.red, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 },
    liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#FFFFFF', marginRight: 6 },
    liveBadgeText: { color: '#FFFFFF', fontSize: 9.5, fontWeight: '800', letterSpacing: 1 },

    tileTallPhoto: { flex: 1, padding: 15, justifyContent: 'flex-end' },
    tileKickerPhoto: { fontSize: 9.5, fontWeight: '800', letterSpacing: 1.4, color: 'rgba(255,255,255,0.75)' },
    tileSubPhoto: { fontSize: 12, color: 'rgba(255,255,255,0.85)', marginTop: 6 },
    sportsUsPhoto: { fontSize: 20, fontWeight: '800', color: '#FFFFFF', letterSpacing: -0.4 },
    sportsVsPhoto: { fontSize: 11, color: 'rgba(255,255,255,0.6)', marginHorizontal: 7, fontWeight: '600' },
    sportsThemPhoto: { fontSize: 15, fontWeight: '600', color: '#FFFFFF', letterSpacing: -0.2, flexShrink: 1 },
    artsTitlePhoto: { fontSize: 16, fontWeight: '700', color: '#FFFFFF', marginTop: 8, letterSpacing: -0.3, lineHeight: 20 },
    diningThumb: { width: 40, height: 40, borderRadius: 10 },

    bigNumber: { fontSize: 46, fontWeight: '300', color: t.text, letterSpacing: -2.5, marginTop: 4, ...NUM },
    sportsRow: { flexDirection: 'row', alignItems: 'baseline', marginTop: 8, flexWrap: 'wrap' },
    sportsUs: { fontSize: 22, fontWeight: '800', color: t.red, letterSpacing: -0.5 },
    sportsVs: { fontSize: 12, color: t.textFaint, marginHorizontal: 8, fontWeight: '600' },
    sportsThem: { fontSize: 17, fontWeight: '600', color: t.text, letterSpacing: -0.3, flexShrink: 1 },
    sportsNote: { fontSize: 11.5, color: t.red, fontWeight: '700', marginTop: 6 },

    utilityHead: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
    utilityCount: { fontSize: 10.5, fontWeight: '700', color: t.ok, marginTop: 2 },
    utilityLine: { flexDirection: 'row', alignItems: 'center', marginBottom: 9 },
    statusDot: { width: 6, height: 6, borderRadius: 3, marginRight: 9 },
    utilityName: { flex: 1, fontSize: 13, color: t.text, fontWeight: '500' },
    utilityDist: { fontSize: 11.5, color: t.textFaint, marginLeft: 8 },
    utilityFine: { fontSize: 11.5, color: t.textMuted, marginTop: 2 },

    markStack: { flexDirection: 'row', alignItems: 'center', marginTop: 12 },
    orgMark: {
      width: 32, height: 32, borderRadius: 16, backgroundColor: t.surfaceAlt,
      borderWidth: 1.5, borderColor: t.surface, alignItems: 'center', justifyContent: 'center',
    },
    orgMarkText: { fontSize: 10.5, fontWeight: '800', color: t.textMuted },
    artsTitle: { fontSize: 16, fontWeight: '700', color: t.text, marginTop: 10, letterSpacing: -0.3, lineHeight: 20 },

    /* SCHEDULE: now-marker + kind tags */
    nowMarkerRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 6 },
    nowMarkerLabel: { fontSize: 10.5, fontWeight: '800', color: t.red, letterSpacing: 0.3, ...NUM },
    nowMarkerAxis: { width: 14.5, alignItems: 'center', justifyContent: 'center' },
    nowMarkerLine: { flex: 1, height: 1.5, backgroundColor: t.red, opacity: 0.5 },
    timelineCardTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
    kindTag: { borderRadius: 5, paddingHorizontal: 7, paddingVertical: 3, marginRight: 8 },
    kindTagText: { fontSize: 8.5, fontWeight: '800', color: '#FFFFFF', letterSpacing: 0.8 },


    resourceInner: { flexDirection: 'row', alignItems: 'center', padding: 18 },
    resourceLine: { fontSize: 14, color: t.text, fontWeight: '600', marginTop: 5 },

    expandHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 6, marginBottom: 12 },
    expandTitle: { fontSize: 19, fontWeight: '700', color: t.text, letterSpacing: -0.4 },
    expandClose: { fontSize: 13, color: t.red, fontWeight: '600' },

    /* CATEGORY MODAL — a real full-screen destination */
    categoryScreen: { flex: 1 },
    categoryTopBar: {
      flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
      paddingHorizontal: 12, paddingTop: Platform.OS === 'android' ? 10 : 4, paddingBottom: 10,
      borderBottomWidth: 1, borderBottomColor: t.border,
    },
    categoryBack: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
    categoryBackText: { fontSize: 28, color: t.text, fontWeight: '300', marginTop: -3 },
    categoryHeaderTitle: { fontSize: 17, fontWeight: '700', color: t.text, letterSpacing: -0.3 },
    /* Category screens are full-screen modals so they clear the nav
       bar, but 60px left content pinned against the bottom edge with
       nowhere to scroll past. */
    categoryContent: { padding: PAD, paddingBottom: 120 },

    /* Sports — scoreboard */
    scoreboardInner: { padding: 22 },
    scoreboardRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 14, marginBottom: 14 },
    scoreboardSide: { flex: 1, alignItems: 'center' },
    scoreboardTeam: { fontSize: 19, fontWeight: '800', color: t.text, letterSpacing: -0.4, textAlign: 'center' },
    scoreboardVs: { fontSize: 12, fontWeight: '700', color: t.textFaint, marginHorizontal: 14 },
    noticeTag: { alignSelf: 'flex-start', marginTop: 14, backgroundColor: t.red, borderRadius: 6, paddingHorizontal: 9, paddingVertical: 4 },
    noticeTagText: { color: t.onRed, fontSize: 9, fontWeight: '800', letterSpacing: 1.1 },

    /* Orgs — a directory grid */
    orgDirectory: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
    orgDirTile: { width: HALF, marginBottom: 20, alignItems: 'flex-start' },
    orgDirMark: { width: 46, height: 46, borderRadius: 23, backgroundColor: t.surfaceAlt, borderWidth: 1, borderColor: t.borderStrong, alignItems: 'center', justifyContent: 'center', marginBottom: 9 },
    orgDirMarkText: { fontSize: 13, fontWeight: '800', color: t.textMuted },
    orgDirName: { fontSize: 13.5, fontWeight: '600', color: t.text, lineHeight: 17 },
    orgDirTags: { fontSize: 11.5, color: t.textFaint, marginTop: 3 },

    /* Arts — editorial */
    artsEditorialRow: { paddingVertical: 18, borderBottomWidth: 1, borderBottomColor: t.border },
    artsEditorialTitle: { fontSize: 20, fontWeight: '700', color: t.text, letterSpacing: -0.4, lineHeight: 25 },
    artsEditorialMeta: { fontSize: 13, color: t.textMuted, marginTop: 6 },

    /* CAMPUS */
    campusFilterScroll: { marginHorizontal: -18, marginBottom: 4 },
    campusFilterRow: { paddingHorizontal: 18 },
    campusCount: { fontSize: 11.5, color: t.textFaint, fontWeight: '600', marginBottom: 10, marginTop: 2 },
    campusTop: { position: 'absolute', top: 0, left: 0, right: 0 },
    campusSearch: { margin: 16, backgroundColor: t.surface, shadowColor: t.shadow, shadowOpacity: 0.16, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 7 },
    drawer: {
      position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: t.canvas,
      borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 18,
      shadowColor: t.shadow, shadowOpacity: 0.22, shadowRadius: 20, shadowOffset: { width: 0, height: -6 }, elevation: 12,
    },
    drawerGrip: { paddingVertical: 12, alignItems: 'center' },
    drawerHandle: { width: 42, height: 4.5, borderRadius: 3, backgroundColor: t.borderStrong },

    /* SCHEDULE */
    segment: { flexDirection: 'row', backgroundColor: t.surfaceAlt, borderRadius: 13, padding: 4, borderWidth: 1, borderColor: t.border },
    segmentItem: { flex: 1, paddingVertical: 9, borderRadius: 10, alignItems: 'center' },
    segmentText: { fontSize: 13.5, fontWeight: '600', color: t.textMuted },
    timelineRow: { flexDirection: 'row', alignItems: 'stretch', marginBottom: 10 },
    timelineGutter: { width: 66, paddingTop: 15 },
    timelineTime: { fontSize: 12, fontWeight: '700', color: t.textMuted, ...NUM },
    timelineRail: { width: 2.5, borderRadius: 2, marginRight: 12 },
    timelineCard: { padding: 14, paddingLeft: 0 },
    subjectAccent: { width: 4, alignSelf: 'stretch', marginLeft: 0, marginRight: 12, borderRadius: 2 },
    nowTag: { fontSize: 9, fontWeight: '800', letterSpacing: 1.2, color: t.red, marginBottom: 5 },
    weekRow: { flexDirection: 'row', justifyContent: 'space-between' },
    weekCol: { alignItems: 'center', flex: 1, paddingVertical: 6 },
    weekDay: { fontSize: 10, fontWeight: '800', color: t.textFaint, marginBottom: 8 },
    /* A 7px bar is far too small to tap reliably, and a bare bar
       reads as a static chart. The track is a real surface with
       padding, a rounded background, and a hit area wide enough to
       actually press — that's what makes it obviously interactive. */
    weekTrack: {
      height: 76, width: 34, justifyContent: 'flex-end', alignItems: 'center',
      backgroundColor: t.rim, borderRadius: 10, paddingBottom: 6,
      borderWidth: 1, borderColor: 'transparent',
    },
    weekFill: { width: 7, borderRadius: 4 },
    weekNum: { fontSize: 12.5, fontWeight: '600', color: t.textMuted, marginTop: 8 },
    weekCount: { fontSize: 10.5, fontWeight: '700', color: t.textFaint, marginTop: 2, minHeight: 14 },
    weekCaption: { fontSize: 12, color: t.textFaint, textAlign: 'center', marginTop: 14 },
    weekSummaryInner: { padding: 16 },
    weekSummaryLine: { fontSize: 15, fontWeight: '700', color: t.text },
    weekSummarySub: { fontSize: 13, color: t.textMuted, marginTop: 4 },

    /* YOU */
    profileInner: { flexDirection: 'row', alignItems: 'center', padding: 20 },
    avatar: { width: 54, height: 54, borderRadius: 27, backgroundColor: t.red, alignItems: 'center', justifyContent: 'center' },
    avatarText: { color: t.onRed, fontSize: 18, fontWeight: '700', letterSpacing: 0.5 },
    avatarHint: { fontSize: 10.5, color: t.textFaint, fontWeight: '600' },
    tagCloud: { flexDirection: 'row', flexWrap: 'wrap' },
    tagChip: {
      flexDirection: 'row', alignItems: 'center', borderRadius: 999, borderWidth: 1, borderColor: t.borderStrong,
      backgroundColor: t.surface, paddingHorizontal: 14, paddingVertical: 9, marginRight: 8, marginBottom: 8,
    },
    tagLabel: { fontSize: 13, color: t.text, fontWeight: '600' },
    profileName: { fontSize: 19, fontWeight: '700', color: t.text, letterSpacing: -0.3 },
    toggle: { width: 46, height: 27, borderRadius: 999, backgroundColor: t.surfaceAlt, borderWidth: 1, borderColor: t.borderStrong, padding: 3, justifyContent: 'center' },
    toggleKnob: { width: 19, height: 19, borderRadius: 10, backgroundColor: '#FFFFFF' },
    versionText: { fontSize: 12, color: t.textFaint, textAlign: 'center', marginTop: 30 },

    /* BUTTONS */
    primaryBtn: { backgroundColor: t.red, borderRadius: 12, paddingVertical: 11, paddingHorizontal: 18, marginRight: 8, marginTop: 8 },
    primaryBtnText: { color: t.onRed, fontWeight: '700', fontSize: 13.5 },
    ghostBtn: { borderRadius: 12, borderWidth: 1, borderColor: t.borderStrong, paddingVertical: 11, paddingHorizontal: 18, marginRight: 8, marginTop: 8 },
    ghostBtnText: { color: t.text, fontWeight: '600', fontSize: 13.5 },

    /* SHEETS */
    sheetBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.18)' },
    sheet: { backgroundColor: t.canvas, borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 22, paddingBottom: Platform.OS === 'ios' ? 34 : 22, overflow: 'hidden' },
    sheetHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: t.borderStrong, alignSelf: 'center', marginBottom: 18 },
    sheetTitle: { fontSize: 22, fontWeight: '700', color: t.text, letterSpacing: -0.4 },
    sheetSub: { fontSize: 13.5, color: t.textMuted, marginTop: 4 },
    detailMetaRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
    orgHeadRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
    orgHeadMark: { width: 50, height: 50, borderRadius: 25, backgroundColor: t.surfaceAlt, borderWidth: 1, borderColor: t.borderStrong, alignItems: 'center', justifyContent: 'center' },
    orgHeadMarkText: { fontSize: 15, fontWeight: '800', color: t.textMuted },
    detailOrg: { fontSize: 11.5, fontWeight: '700', color: t.textMuted, letterSpacing: 0.3 },
    detailOfficial: { fontSize: 11.5, fontWeight: '700', color: t.red, marginLeft: 4 },
    detailTitle: { fontSize: 24, fontWeight: '700', color: t.text, letterSpacing: -0.6, marginBottom: 8 },
    detailBody: { fontSize: 14.5, color: t.textMuted, lineHeight: 21, marginTop: 14 },
    detailActions: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 },

    suggestInner: { padding: 14 },
    suggestText: { fontSize: 14.5, color: t.text },
    bubble: { alignSelf: 'flex-end', backgroundColor: t.red, borderRadius: 16, paddingHorizontal: 15, paddingVertical: 10, marginBottom: 12, maxWidth: '85%' },
    bubbleText: { color: t.onRed, fontSize: 14.5 },
    redText: { fontSize: 15, color: t.text, marginBottom: 10, lineHeight: 21 },
    redResult: { flexDirection: 'row', alignItems: 'center', paddingVertical: 13, paddingHorizontal: 15 },
    redAction: { fontSize: 13, fontWeight: '700', color: t.red },
    askRow: { flexDirection: 'row', alignItems: 'center', marginTop: 14 },
    askInput: { flex: 1, backgroundColor: t.surface, borderRadius: 15, borderWidth: 1, borderColor: t.borderStrong, paddingHorizontal: 16, height: 48, fontSize: 15, color: t.text, marginRight: 9 },
    askSend: { width: 48, height: 48, borderRadius: 24, backgroundColor: t.red, alignItems: 'center', justifyContent: 'center' },
    askSendText: { color: t.onRed, fontSize: 20, fontWeight: '700' },

    /* MISC */
    emptyInner: { padding: 24, alignItems: 'center' },
    emptyTitle: { fontSize: 15, fontWeight: '600', color: t.text, textAlign: 'center' },
    emptyBody: { fontSize: 13.5, color: t.textMuted, marginTop: 6, textAlign: 'center', lineHeight: 19 },
    conflictBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.22)', alignItems: 'center', justifyContent: 'center' },
    conflictTitle: { fontSize: 18, fontWeight: '700', color: t.text, marginBottom: 8 },
    onboardTitle: { fontSize: 27, fontWeight: '700', color: t.text, letterSpacing: -0.6 },
    onboardSub: { fontSize: 15, color: t.textMuted, marginTop: 8, lineHeight: 21 },
    onboardProgress: { flexDirection: 'row', justifyContent: 'center', gap: 7, marginBottom: 28 },
    onboardDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: t.borderStrong },
    onboardDotActive: { backgroundColor: t.red, width: 20 },

    signinMark: {
      width: 60, height: 60, borderRadius: 30, backgroundColor: t.red,
      alignItems: 'center', justifyContent: 'center',
      shadowColor: t.red, shadowOpacity: 0.35, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 6,
    },
    signinInput: {
      backgroundColor: t.surface, borderRadius: 14, borderWidth: 0.5, borderColor: t.borderStrong,
      paddingHorizontal: 16, height: 50, fontSize: 15, color: t.text,
    },
    signinGuestText: { fontSize: 13.5, color: t.textMuted, fontWeight: '600', textDecorationLine: 'underline' },
    classFormError: { fontSize: 12, color: t.red, marginTop: 6, fontWeight: '600' },
    classFormClear: { fontSize: 13, color: t.red, fontWeight: '700' },

    confirmChip: { backgroundColor: t.surfaceAlt, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 6, marginRight: 7, marginBottom: 7 },
    confirmChipText: { fontSize: 12, color: t.text, fontWeight: '600' },

    /* ASK RED FAB + NAV */
    redFabWrap: { position: 'absolute', bottom: 104, right: 20, alignItems: 'center', justifyContent: 'center' },
    redFabRing: {
      position: 'absolute', width: 120, height: 52, borderRadius: 26,
      backgroundColor: t.red,
    },
    redFab: {
      flexDirection: 'row', alignItems: 'center',
      backgroundColor: t.red, paddingHorizontal: 18, paddingVertical: 12, borderRadius: 999,
      shadowColor: t.red, shadowOpacity: 0.4, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 9,
    },
    redFabDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: t.onRed, marginRight: 8 },
    redFabText: { color: t.onRed, fontWeight: '700', fontSize: 13.5 },

    navWrap: { paddingHorizontal: 14, paddingBottom: Platform.OS === 'ios' ? 26 : 14, paddingTop: 4 },
    nav: {
      flexDirection: 'row', backgroundColor: t.mode === 'dark' ? 'rgba(29,26,27,0.72)' : 'rgba(255,255,255,0.72)',
      borderRadius: 24, borderWidth: 1, borderColor: t.border, overflow: 'hidden',
      paddingTop: 10, paddingBottom: 10,
      shadowColor: t.shadow, shadowOpacity: t.shadowOpacity * 1.6, shadowRadius: 18, shadowOffset: { width: 0, height: 8 }, elevation: 10,
    },
    navBlurFill: { ...StyleSheet.absoluteFillObject },
    navItem: { flex: 1, alignItems: 'center' },
    navLabel: { fontSize: 9.5, color: t.textFaint, marginTop: 4, fontWeight: '600' },
  });
}
